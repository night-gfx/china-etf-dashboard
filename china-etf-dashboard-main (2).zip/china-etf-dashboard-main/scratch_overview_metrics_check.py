﻿import asyncio
import json
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="msedge", headless=True)
        page = await browser.new_page(viewport={"width": 1600, "height": 1200})
        errors = []
        page.on("pageerror", lambda e: errors.append(e.stack))
        await page.goto("http://127.0.0.1:8050/", wait_until="domcontentloaded")
        await page.locator("#overview-drawdown canvas").first.wait_for(timeout=90000)
        await page.locator("#overview-annual .ag-row").first.wait_for(timeout=90000)
        for label in ["1J", "3J", "1J", "Max", "1J"]:
            async with page.expect_response(lambda r: "_dash-update-component" in r.url and r.request.method == "POST" and 'overview-range' in (r.request.post_data or '')):
                await page.locator("#overview-range").get_by_text(label, exact=True).click()
            await page.wait_for_timeout(250)
            result = await page.evaluate('''() => ['overview-chart','overview-drawdown'].map(id => {
                const e=document.getElementById(id);
                return {series:e._lastSpec.series.length, legends:e.querySelectorAll('.tv-legend-row').length,
                        values:e._lastSpec.series.map(s=>s.data.length)};
            })''')
            assert all(r["series"] == r["legends"] == 7 and min(r["values"]) > 200 for r in result), (label, result)
        assert await page.locator("#overview-annual-metric").input_value() == "Return p.a."
        await page.locator("#overview-annual-metric").click()
        await page.get_by_role("option", name="Sharpe Ratio", exact=True).click()
        await page.wait_for_timeout(800)
        cell = page.locator('#overview-annual .ag-center-cols-container .ag-cell').first
        assert '%' not in await cell.inner_text()
        await page.screenshot(path="scratch_overview_metrics.png", full_page=True)
        styles = await page.evaluate('''() => ['.section-title','.stat-label','#overview-metrics .ag-cell','#overview-annual .ag-header-cell-text'].map(s=>{const c=getComputedStyle(document.querySelector(s));return {font:c.fontFamily,size:c.fontSize};})''')
        assert [s['size'] for s in styles] == ['20px','14px','14px','14px'], styles
        assert all('Arial' in s['font'] for s in styles), styles
        assert not errors, errors
        print(json.dumps({"range_switches": "passed", "series_per_chart": 7, "annual_dropdown": "passed", "typography": styles, "errors": errors}))
        await browser.close()


asyncio.run(main())

