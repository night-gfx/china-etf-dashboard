import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1500, "height": 1400})
        errors = []
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
        page.on("pageerror", lambda exc: errors.append(str(exc)))
        await page.goto("http://127.0.0.1:8050/", wait_until="load", timeout=60000)
        await page.wait_for_timeout(10000)
        print("ERRORS:", errors)
        await page.screenshot(path="scratch_overview.png", full_page=True)
        await browser.close()

asyncio.run(main())
