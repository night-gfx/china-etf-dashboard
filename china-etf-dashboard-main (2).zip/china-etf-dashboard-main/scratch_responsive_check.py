import asyncio
import json
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="msedge", headless=True)
        page = await browser.new_page(viewport={"width": 1600, "height": 1100})
        errors = []
        page.on("pageerror", lambda e: errors.append(e.stack))
        await page.goto("http://127.0.0.1:8050/", wait_until="domcontentloaded")
        await page.locator("#overview-drawdown canvas").first.wait_for(timeout=90000)
        results = []
        for width in [2560, 1920, 1600, 1280, 1067, 800, 390]:
            await page.set_viewport_size({"width": width, "height": 1100})
            await page.wait_for_timeout(350)
            result = await page.evaluate('''() => {
                const perf=document.getElementById('overview-chart').getBoundingClientRect();
                const dd=document.getElementById('overview-drawdown').getBoundingClientRect();
                const cards=[...document.querySelectorAll('.overview-asset-grid > *')].map(e=>e.getBoundingClientRect());
                return {width:innerWidth, overflow:document.documentElement.scrollWidth>innerWidth+1,
                    content:document.querySelector('.page-content').clientWidth,
                    chartWidth:perf.width,chartHeight:perf.height,columns:Math.abs(perf.top-dd.top)<2?2:1,
                    tiles:cards.filter(r=>Math.abs(r.top-cards[0].top)<2).length,
                    chartCanvas:document.querySelector('#overview-chart canvas').getBoundingClientRect().width};
            }''')
            if result['overflow']:
                print(await page.evaluate("""() => ({scroll:document.documentElement.scrollWidth,els:[...document.querySelectorAll('body *')].filter(e=>{if(e.getBoundingClientRect().right<=391)return false;for(let p=e.parentElement;p;p=p.parentElement){if(['hidden','auto','scroll','clip'].includes(getComputedStyle(p).overflowX))return false;}return true;}).map(e=>({tag:e.tagName,id:e.id,c:String(e.className),r:e.getBoundingClientRect().right})).slice(0,20)})"""))
            assert not result['overflow'], result
            assert result['chartWidth'] <= result['content']+1, result
            assert result['chartCanvas'] > 0, result
            if width <=1280: assert result['columns']==1, result
            if width >=1600: assert result['columns']==2, result
            results.append(result)
            if width in [1920,390]:
                await page.screenshot(path=f'scratch_responsive_{width}.png',full_page=True)
        await page.locator('#mobile-nav-toggle').click()
        await page.wait_for_timeout(350)
        assert await page.locator('#app-navbar').evaluate('e=>e.getBoundingClientRect().left>=0')
        await page.locator('#app-navbar a[href="/aktien"]').click()
        await page.wait_for_url('**/aktien')
        await page.wait_for_timeout(350)
        assert await page.locator('#app-navbar').evaluate('e=>e.getBoundingClientRect().right<=1')
        assert not errors, errors
        print(json.dumps({'widths':results,'mobile_navigation':'passed','errors':errors}))
        await browser.close()


asyncio.run(main())
