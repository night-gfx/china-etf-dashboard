import asyncio
import json
from datetime import date, timedelta
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="msedge", headless=True)
        page = await browser.new_page(viewport={"width": 1500, "height": 1100})
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        await page.goto("http://127.0.0.1:8050/", wait_until="domcontentloaded")
        await page.locator("#overview-chart canvas").first.wait_for(timeout=90000)
        assert await page.locator(".brand-title").inner_text() == "Market Dashboard"
        assert await page.locator("#brand-avatar, .brand-sub").count() == 0
        assert await page.locator("#overview-chart").evaluate("el => el._lastSpec.rebaseVisible")
        await page.locator('#app-navbar a[href="/aktien"]').click()
        await page.wait_for_url("**/aktien")
        await page.locator(".equity-category-link").first.wait_for()
        assert await page.locator(".equity-subpage-link:visible").count() == 3
        assert await page.locator("#page-content details, .equity-back-link").count() == 0
        text = await page.locator("#page-content").inner_text()
        assert "öffnen" not in text and "Unterseiten anzeigen" not in text and "Aktienmärkte nach" not in text
        await page.screenshot(path="scratch_equities_updated.png", full_page=True)
        await page.go_back()
        await page.locator("#overview-chart canvas").first.wait_for(timeout=90000)
        # Exercise the real renderer and library with deterministic daily values.
        await page.evaluate('''() => {
            const original = window.LightweightCharts;
            window.testCharts = [];
            window.LightweightCharts = {...original, createChart: (...args) => {
                const chart = original.createChart(...args);
                const add = chart.addLineSeries.bind(chart);
                chart.testSeries = [];
                chart.addLineSeries = (...options) => {
                    const series = add(...options);
                    chart.testSeries.push(series);
                    return series;
                };
                window.testCharts.push(chart);
                return chart;
            }};
            const data = Array.from({length: 100}, (_, i) => ({time: new Date(Date.UTC(2020, 0, i+1)).toISOString().slice(0,10), value: 50+i*2}));
            window.fixture = {height: 300, rebaseVisible: true, series: [
                {name: 'A', color: '#ff0000', data},
                {name: 'B', color: '#0000ff', data: data.filter((_, i) => i % 2 === 0)}
            ]};
            for (const [id, enabled] of [['rebase-test', true], ['plain-test', false]]) {
                const el = document.createElement('div'); el.id=id; el.style.width='900px'; document.body.appendChild(el);
                window.renderTVChart(id, {...fixture, rebaseVisible: enabled});
            }
        }''')
        for start, end in [(21, 65), (40, 85), (0, 99), (21, 65)]:
            await page.evaluate("([a,b]) => testCharts.forEach(c => c.timeScale().setVisibleRange({from:fixture.series[0].data[a].time,to:fixture.series[0].data[b].time}))", [start, end])
            await page.wait_for_timeout(150)
            result = await page.evaluate('''() => {
                const key = t => typeof t === 'string' ? t : `${t.year}-${String(t.month).padStart(2,'0')}-${String(t.day).padStart(2,'0')}`;
                const c = testCharts[0], r = c.timeScale().getVisibleRange();
                return {
                    bases: c.testSeries.map(s => s.data().find(d => key(d.time) >= key(r.from)).value),
                    plain: testCharts[1].testSeries[0].data()[21].value,
                    original: fixture.series[0].data[21].value,
                    from: key(r.from)
                };
            }''')
            assert all(abs(value - 100) < 1e-9 for value in result["bases"]), result
            assert result["plain"] == result["original"] == 92, result
            assert result["from"] == (date(2020, 1, 1) + timedelta(days=start)).isoformat(), result
        assert not errors, errors
        print(json.dumps({"navigation": "passed", "zoom_pan_reset": "passed", "missing_dates": "passed", "non_indexed_unchanged": "passed", "errors": errors}))
        await browser.close()


asyncio.run(main())
