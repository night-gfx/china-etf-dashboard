import asyncio
import json
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="msedge", headless=True)
        page = await browser.new_page(viewport={"width": 1600, "height": 1200})
        errors = []
        page.on("pageerror", lambda e: (errors.append(e.stack), print(e.stack, flush=True)))
        async def instrument(route):
            response = await route.fetch()
            prefix = '''const realLC = window.LightweightCharts;
            window.LightweightCharts = {...realLC, createChart: (container, options) => {
                const chart = realLC.createChart(container, options);
                container._testChart = chart;
                return chart;
            }};'''
            await route.fulfill(response=response, body=prefix + await response.text())
        await page.route("**/assets/tv-chart.js*", instrument)
        await page.goto("http://127.0.0.1:8050/", wait_until="domcontentloaded")
        await page.locator("#overview-drawdown canvas").first.wait_for(timeout=90000)
        await page.locator("#overview-annual .ag-row").first.wait_for()
        async def check_sync():
            await page.wait_for_timeout(200)
            ranges = await page.evaluate("['overview-chart','overview-drawdown'].map(id=>document.getElementById(id)._testChart.timeScale().getVisibleLogicalRange())")
            assert abs(ranges[0]['from']-ranges[1]['from']) < .01, ranges
            assert abs(ranges[0]['to']-ranges[1]['to']) < .01, ranges
        for label in ['1J','3J','Max','1J']:
            async with page.expect_response(lambda r: '_dash-update-component' in r.url and 'overview-range' in (r.request.post_data or '')):
                await page.locator('#overview-range').get_by_text(label, exact=True).click()
            expected = {'1J':'1','3J':'3','Max':'max'}[label]
            await page.wait_for_function("key=>['overview-chart','overview-drawdown'].every(id=>document.getElementById(id)._lastSpec.syncKey===key)", arg=expected)
            await check_sync()
        for chart_id in ['overview-chart','overview-drawdown']:
            await page.evaluate("id=>document.getElementById(id)._testChart.timeScale().setVisibleLogicalRange({from:40,to:180})", chart_id)
            await check_sync()
            await page.evaluate("id=>document.getElementById(id)._testChart.timeScale().fitContent()", chart_id)
            await check_sync()
        await page.locator('#overview-annual-metric').click()
        await page.get_by_role('option', name='Sortino Ratio', exact=True).click()
        await page.wait_for_timeout(600)
        alignment = await page.evaluate('''() => ['overview-metrics','overview-annual'].map(id=>
            [...document.querySelectorAll('#'+id+' .ag-pinned-left-cols-container .ag-row')].map(e=>e.getBoundingClientRect().top))''')
        assert len(alignment[0])==len(alignment[1])==7, alignment
        assert all(abs(a-b)<1 for a,b in zip(*alignment)), alignment
        await page.screenshot(path='scratch_overview_aligned.png', full_page=True)
        await page.get_by_role('button', name='KI Zusammenfassung', exact=True).click()
        await page.wait_for_function("document.querySelectorAll('.overview-ai-summaries .section-card').length === 7 || document.querySelector('#overview-ai-result [role=alert]')", timeout=110000)
        count = await page.locator('.overview-ai-summaries .section-card').count()
        print(json.dumps({'sync_both_directions':'passed','row_alignment':'passed','ai_categories':count,'ai_status':(await page.locator('#overview-ai-result').inner_text())[:250], 'errors':errors}, ensure_ascii=False))
        assert not errors, errors
        assert count == 7, 'AI response did not contain seven summaries'
        await browser.close()


asyncio.run(main())
