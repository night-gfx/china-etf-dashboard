import asyncio
from playwright.async_api import async_playwright

PAGES = [
    ("sp500-sectors", "/sp500-sectors"),
    ("commodities", "/commodities"),
    ("china-markets", "/china-markets"),
    ("laender", "/laender"),
    ("asset-allocation", "/asset-allocation"),
]

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        for name, path in PAGES:
            page = await browser.new_page(viewport={"width": 1500, "height": 1400})
            errors = []
            page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
            page.on("pageerror", lambda exc: errors.append(str(exc)))
            await page.goto(f"http://127.0.0.1:8050{path}", wait_until="load", timeout=60000)
            await page.wait_for_timeout(9000)
            print(f"--- {name} ---")
            print("ERRORS:", errors)
            await page.screenshot(path=f"scratch_page_{name}.png", full_page=True)
            await page.close()
        await browser.close()

asyncio.run(main())
