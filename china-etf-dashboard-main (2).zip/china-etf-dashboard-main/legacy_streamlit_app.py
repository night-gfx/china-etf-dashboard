from __future__ import annotations
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf


from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path

import pandas as pd
import streamlit as st


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf


from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


from pathlib import Path
import pandas as pd
import streamlit as st

# Load the enhanced v10 core only; no page switch is executed.


from pathlib import Path
from urllib.parse import quote, unquote
import html

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf

# Load the stable v9 implementation without executing its top-level page switch.


from pathlib import Path
import math

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf

from src.data import download_adjusted_close, detect_currency, convert_to_eur

# Stable definitions, metadata and cached resolvers from v5.
# This is a normal executable app; no regex/source patching is used.


from pathlib import Path
import math
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.data import load_registry, resolve_oldest_available_for_index, resolve_selected_rows
from src.metrics import cagr, max_drawdown, sortino, tracking_error_and_ir
from src.tax import effective_german_equity_etf_tax_rate, transform_frame

ROOT = Path(__file__).resolve().parent
TECH_PATH = ROOT / "data_tech_etfs.csv"

st.set_page_config(page_title="China ETF Dashboard", page_icon="📈", layout="wide", initial_sidebar_state="collapsed")

DEFAULTS = {
    "after_tax": True, "base_rate": 0.25, "soli": 0.055, "teilfreistellung": 0.30,
    "page": "Market ETFs vergleichen", "market_focus": None, "tech_focus": None,
    "market_corr_pair": None, "tech_corr_pair": None,
}
for k,v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

st.markdown("""
<style>
.block-container{max-width:1620px;padding-top:1.1rem;padding-bottom:3rem}
html,body,p,label,h1,h2,h3,h4,h5,h6,[data-testid="stAppViewContainer"]{color:#111827!important}
[data-testid="stCaptionContainer"] p{color:#374151!important}
[data-testid="stDataFrame"] *{color:#111827!important}
[data-testid="stPlotlyChart"]{border:1px solid #e5e7eb;border-radius:.8rem;padding:.3rem;background:#fff}
.tree-card{border:1px solid #e5e7eb;border-radius:.75rem;padding:.7rem .85rem;margin:.25rem 0 .6rem 0;background:#fff}
.tree-title{font-weight:750;font-size:.98rem;line-height:1.25}
.tree-bullets{font-size:.84rem;line-height:1.45;color:#111827;margin-top:.35rem}
.swatch{display:inline-block;width:.75rem;height:.75rem;border-radius:50%;margin-right:.45rem;vertical-align:middle}
.branch-line{height:22px;border-left:2px solid #d1d5db;margin-left:50%}
.branch-head{text-align:center;font-weight:750;margin:.1rem 0 .4rem 0}
.statusbox{padding-top:.15rem}
</style>
""", unsafe_allow_html=True)

SHARE_CLASS_ORDER = ["A-Shares","B-Shares","H-Shares","Red Chips","P-Chips","Auslandslistings / ADRs"]
INDEX_SHARE_CLASSES = {
    "MSCI China All Shares Stock Connect Select": set(SHARE_CLASS_ORDER),
    "S&P China 500": set(SHARE_CLASS_ORDER),
    "FTSE China 30/18 Capped": set(SHARE_CLASS_ORDER),
    "MSCI China": set(SHARE_CLASS_ORDER),
    "MSCI China ex A Shares": {"B-Shares","H-Shares","Red Chips","P-Chips","Auslandslistings / ADRs"},
    "Dow Jones China Offshore 50": {"H-Shares","Red Chips","P-Chips","Auslandslistings / ADRs"},
    "FTSE China 50": {"H-Shares","Red Chips","P-Chips"},
    "CSI Overseas China Internet": {"H-Shares","P-Chips","Auslandslistings / ADRs"},
    "MSCI China A": {"A-Shares"},
    "CSI A 500": {"A-Shares"},
    "MSCI China A Inclusion": {"A-Shares"},
    "CSI 300": {"A-Shares"},
    "S&P China A 300": {"A-Shares"},
    "SSE Science and Technology Innovation Board 50": {"A-Shares"},
    "ChiNext 50 Capped": {"A-Shares"},
}
INDEX_SCOPE = {
    "MSCI China All Shares Stock Connect Select":"All Shares","S&P China 500":"All Shares",
    "FTSE China 30/18 Capped":"All Shares","MSCI China":"All Shares",
    "MSCI China ex A Shares":"Offshore","Dow Jones China Offshore 50":"Offshore",
    "FTSE China 50":"Offshore","CSI Overseas China Internet":"Offshore",
    "MSCI China A":"Onshore","CSI A 500":"Onshore","MSCI China A Inclusion":"Onshore",
    "CSI 300":"Onshore","S&P China A 300":"Onshore",
    "SSE Science and Technology Innovation Board 50":"Onshore","ChiNext 50 Capped":"Onshore",
}
INDEX_INFO = {
    "MSCI China All Shares Stock Connect Select":{"url":"https://www.msci.com/indexes/index/732716/msci-china-all-shares-stock-connect-select-index","members":"576","segment":"Breit; Large & Mid Cap","weight":"Free-Float-Marktkapitalisierung","rebalance":"4× p.a.","special":"A-Shares nur Stock-Connect-fähig; zusätzlich B/H/Red/P und Foreign Listings."},
    "S&P China 500":{"url":"https://www.spglobal.com/spdji/en/indices/equity/sp-china-500","members":"500","segment":"Breit; Large & Mid Cap","weight":"Float-adjusted Market Cap","rebalance":"2× p.a.","special":"Sektor-repräsentatives China-Universum mit Onshore und Offshore."},
    "FTSE China 30/18 Capped":{"url":"https://www.lseg.com/en/ftse-russell","members":"variabel","segment":"Breit; Large & Mid Cap","weight":"Free-Float Market Cap; 30/18-Capping","rebalance":"4× p.a.","special":"Konzentrationsbegrenzung nach 30/18-Logik."},
    "MSCI China":{"url":"https://www.msci.com/indexes/index/302400/msci-china-index","members":"576","segment":"Breit; Large & Mid Cap","weight":"Free-Float-Marktkapitalisierung","rebalance":"4× p.a.","special":"A/B/H-Shares, Red/P Chips und Foreign Listings; A-Shares mit Inclusion Factor."},
    "MSCI China ex A Shares":{"url":"https://www.msci.com/","members":"variabel","segment":"Breit Offshore; Large & Mid Cap","weight":"Free-Float-Marktkapitalisierung","rebalance":"4× p.a.","special":"China ohne inländische A-Shares."},
    "Dow Jones China Offshore 50":{"url":"https://www.spglobal.com/spdji/tc/documents/methodologies/methodology-dj-china.pdf","members":"50","segment":"Offshore Large Cap","weight":"Float-adjusted Market Cap; 10%-Cap","rebalance":"4× p.a.","special":"50 große geeignete chinesische Offshore-Unternehmen."},
    "FTSE China 50":{"url":"https://www.lseg.com/content/dam/ftse-russell/en_us/documents/ground-rules/ftse-china-50-index-english-ground-rules.pdf","members":"50","segment":"Hongkong Large Cap","weight":"Free-Float Market Cap","rebalance":"4× p.a.","special":"50 große und liquide China-Unternehmen an der HKEX."},
    "CSI Overseas China Internet":{"url":"https://www.csindex.com.cn/","members":"≈ 30–50","segment":"Offshore Internet / Tech","weight":"Free-Float Market Cap","rebalance":"2× p.a.","special":"China-basierte Internetunternehmen mit primärer Notierung außerhalb Mainland China."},
    "MSCI China A":{"url":"https://www.msci.com/","members":"variabel","segment":"Breit Onshore; Large & Mid Cap","weight":"Free-Float-Marktkapitalisierung","rebalance":"4× p.a.","special":"Breites inländisches A-Share-Universum."},
    "CSI A 500":{"url":"https://www.csindex.com.cn/","members":"500","segment":"Breit Onshore; Mid/Large","weight":"Free-Float Market Cap","rebalance":"2× p.a.","special":"Breitere Branchenabdeckung als CSI 300."},
    "MSCI China A Inclusion":{"url":"https://www.msci.com/","members":"≈ 400","segment":"Onshore; Stock-Connect A-Shares","weight":"Free-Float mit Inclusion Factor","rebalance":"4× p.a.","special":"Spiegelt die MSCI-Einbeziehung von A-Shares wider."},
    "CSI 300":{"url":"https://www.csindex.com.cn/","members":"300","segment":"Onshore Large & Mid Cap","weight":"Free-Float Market Cap","rebalance":"2× p.a.","special":"300 große und liquide A-Shares aus Shanghai und Shenzhen."},
    "S&P China A 300":{"url":"https://www.spglobal.com/spdji/","members":"300","segment":"Onshore Large & Mid Cap","weight":"Float-adjusted Market Cap","rebalance":"2× p.a.","special":"300 liquide A-Shares als Mainland-China-Benchmark."},
    "SSE Science and Technology Innovation Board 50":{"url":"https://english.sse.com.cn/indices/indices/list/indexmethods/c/000688_000688hbooken_EN.pdf","members":"50","segment":"Onshore Tech; STAR Market","weight":"Market Cap & Liquidität","rebalance":"4× p.a.","special":"Technologie-/Innovationsfokus auf dem STAR Market."},
    "ChiNext 50 Capped":{"url":"http://www.cnindex.com.cn/en/module/pdf-detail.html?pdf=/docs/gz_399673_e.pdf&name=ChiNext%2050","members":"50","segment":"Onshore Growth / Tech","weight":"Free-Float Market Cap; Capped","rebalance":"4× p.a.","special":"Führende Wachstums-/Innovationsunternehmen des ChiNext-Markts."},
}
PALETTE=["#2563eb","#dc2626","#059669","#7c3aed","#ea580c","#0891b2","#be123c","#4f46e5","#65a30d","#a16207","#0f766e","#9333ea","#c2410c","#0369a1","#4d7c0f"]
MARKET_PROXY_BY_SIGNATURE={
    frozenset(SHARE_CLASS_ORDER):"MSCI China All Shares Stock Connect Select",
    frozenset({"B-Shares","H-Shares","Red Chips","P-Chips","Auslandslistings / ADRs"}):"MSCI China ex A Shares",
    frozenset({"H-Shares","Red Chips","P-Chips","Auslandslistings / ADRs"}):"Dow Jones China Offshore 50",
    frozenset({"H-Shares","Red Chips","P-Chips"}):"FTSE China 50",
    frozenset({"A-Shares"}):"MSCI China A Inclusion",
}

@st.cache_data(ttl=12*60*60, show_spinner=False)
def registry_cached():
    return load_registry()

@st.cache_data(ttl=12*60*60, show_spinner=False)
def tech_registry_cached():
    df=pd.read_csv(TECH_PATH, parse_dates=["inception"])
    df["label"]=df["etf_name"]+" ("+df["index_name"]+")"
    return df.sort_values(["universe","inception","etf_name"]).reset_index(drop=True)

@st.cache_data(ttl=6*60*60, show_spinner=False)
def resolve_index_cached(index_name):
    return resolve_oldest_available_for_index(index_name, registry_cached())

@st.cache_data(ttl=6*60*60, show_spinner=False)
def resolve_rows_cached(index_name, names):
    reg=registry_cached()
    sub=reg[(reg["index_name"]==index_name)&(reg["etf_name"].isin(names))]
    return resolve_selected_rows([r for _,r in sub.iterrows()])

@st.cache_data(ttl=6*60*60, show_spinner=False)
def resolve_tech_cached(names):
    reg=tech_registry_cached()
    sub=reg[reg["etf_name"].isin(names)]
    return resolve_selected_rows([r for _,r in sub.iterrows()])

def fmt_date(v):
    return "–" if v is None or pd.isna(v) else pd.Timestamp(v).strftime("%d.%m.%Y")

def share_text(name):
    return ", ".join(x for x in SHARE_CLASS_ORDER if x in INDEX_SHARE_CLASSES.get(name,set()))

def effective_tax():
    return effective_german_equity_etf_tax_rate(st.session_state.base_rate,st.session_state.soli,st.session_state.teilfreistellung)

def common_frame(series):
    raw=pd.DataFrame(series).sort_index()
    return transform_frame(raw, after_tax=st.session_state.after_tax, effective_tax_rate=effective_tax(), common_start=True)

def daily_returns(s):
    return s.dropna().pct_change(fill_method=None).dropna()

def vol(s):
    r=daily_returns(s)
    return r.std(ddof=1)*math.sqrt(252) if len(r)>1 else np.nan

def sharpe0(s):
    r=daily_returns(s)
    if len(r)<2 or r.std(ddof=1)==0:return np.nan
    return r.mean()/r.std(ddof=1)*math.sqrt(252)

def yearly_sharpe_matrix(frame, display):
    years=sorted({int(y) for c in frame.columns for y in frame[c].dropna().index.year})
    rows=[]
    for col in frame.columns:
        row={"":display.get(col,col)}
        s=frame[col].dropna()
        for y in years:
            sy=s[s.index.year==y]
            row[str(y)]=sharpe0(sy) if len(sy)>2 else np.nan
        rows.append(row)
    return pd.DataFrame(rows).set_index("")

def total_stats(frame, display, benchmark_by_col=None):
    rows=[]
    for col in frame.columns:
        s=frame[col].dropna()
        if len(s)<2:continue
        cg=cagr(s); dd=max_drawdown(s)
        row={"":display.get(col,col),"CAGR p.a.":cg,"Volatilität p.a.":vol(s),"Sharpe Ratio":sharpe0(s),
             "Max. Drawdown":dd,"Sortino":sortino(s,0.0),"Calmar":cg/abs(dd) if dd and not np.isnan(dd) else np.nan}
        if benchmark_by_col and col in benchmark_by_col:
            b=benchmark_by_col[col]
            te,ir,_=tracking_error_and_ir(s,b)
            row["Tracking Error p.a."]=te; row["Information Ratio p.a."]=ir
        rows.append(row)
    return pd.DataFrame(rows).set_index("") if rows else pd.DataFrame()

def style_heat(df, focus=None):
    pct={"CAGR p.a.","Volatilität p.a.","Max. Drawdown","Tracking Error p.a."}
    nums={"Sharpe Ratio","Sortino","Calmar","Information Ratio p.a."}
    fmts={c:(lambda x: "–" if pd.isna(x) else f"{x:.2%}") for c in df.columns if c in pct}
    fmts.update({c:(lambda x: "–" if pd.isna(x) else f"{x:.2f}") for c in df.columns if c in nums or str(c).isdigit()})
    sty=df.style.format(fmts,na_rep="–").set_properties(**{"color":"#111827","background-color":"#ffffff"})
    numeric=df.select_dtypes(include="number").columns.tolist()
    if numeric:
        sty=sty.background_gradient(cmap="RdYlGn",subset=numeric,axis=0)
    if focus is not None and focus in df.index:
        sty=sty.apply(lambda row:["font-weight:800;border-top:2px solid #111827;border-bottom:2px solid #111827" if row.name==focus else "" for _ in row],axis=1)
    return sty

def base_layout(showlegend=False):
    return dict(showlegend=showlegend,hovermode="x unified",dragmode="zoom",height=520,plot_bgcolor="white",paper_bgcolor="white",
                font=dict(color="#111827"),margin=dict(l=50,r=18,t=18,b=45),
                xaxis=dict(showgrid=False,zeroline=False,autorange=True))

def line_fig(frame, colors, focus=None, dd=False, benchmark_map=None):
    fig=go.Figure()
    for col in frame.columns:
        if col.startswith("__BENCH__"):continue
        s=frame[col].dropna()
        y=(s/s.cummax()-1)*100 if dd else s
        width=4 if col==focus else 1.8
        fig.add_trace(go.Scatter(x=y.index,y=y,mode="lines",name=col,line=dict(width=width,color=colors.get(col)),customdata=[col]*len(y),
                                 hovertemplate=("%{x|%d.%m.%Y}<br><b>%{y:.2f}%</b><extra></extra>" if dd else "%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra></extra>")))
        if benchmark_map and col in benchmark_map and benchmark_map[col] in frame.columns:
            b=frame[benchmark_map[col]].dropna()
            by=(b/b.cummax()-1)*100 if dd else b
            fig.add_trace(go.Scatter(x=by.index,y=by,mode="lines",name="Market Proxy",line=dict(width=2,color=colors.get(col),dash="dash"),
                                     hovertemplate=("%{x|%d.%m.%Y}<br><b>%{y:.2f}%</b><extra>Market Proxy</extra>" if dd else "%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra>Market Proxy</extra>")))
    yaxis=dict(showgrid=False,zeroline=False,autorange=True,type="linear" if dd else "log",title="Drawdown in %" if dd else "Indexiert (log)")
    fig.update_layout(**base_layout(False),yaxis=yaxis)
    return fig

def correlation_fig(frame, display, focus=None):
    rets=frame.pct_change(fill_method=None).dropna()
    corr=rets.corr()
    names=[display.get(c,c) for c in corr.columns]
    z=corr.values
    fig=go.Figure(go.Heatmap(z=z,x=names,y=names,zmin=-1,zmax=1,colorscale="RdYlGn",zmid=0,
                             text=np.round(z,2),texttemplate="%{text:.2f}",customdata=np.array([[f"{corr.index[i]}|||{corr.columns[j]}" for j in range(len(corr.columns))] for i in range(len(corr.index))],dtype=object),
                             hovertemplate="%{y} ↔ %{x}<br><b>%{z:.3f}</b><extra></extra>"))
    fig.update_layout(height=560,margin=dict(l=30,r=15,t=15,b=30),plot_bgcolor="white",paper_bgcolor="white",font=dict(color="#111827"))
    return fig

def rolling_corr_fig(frame,a,b,display):
    pair=frame[[a,b]].pct_change(fill_method=None).dropna()
    rolling=pair[a].rolling(252,min_periods=126).corr(pair[b])
    fig=go.Figure(go.Scatter(x=rolling.index,y=rolling,mode="lines",line=dict(width=2.2),hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.3f}</b><extra></extra>"))
    fig.update_layout(**base_layout(False),yaxis=dict(title=f"{display.get(a,a)} ↔ {display.get(b,b)}",showgrid=False,zeroline=True,range=[-1,1]))
    return fig

def update_focus_from_plot(event, label_map, state_key):
    try:
        pts=event.selection.points
        if pts:
            cd=pts[0].get("customdata")
            if cd in label_map:
                st.session_state[state_key]=label_map[cd]
    except Exception:
        pass

def update_focus_from_table(event, df, state_key):
    try:
        rows=event.selection.rows
        if rows:
            st.session_state[state_key]=df.index[rows[0]]
    except Exception:
        pass


st.markdown(
    """
    <style>
    div[data-testid="stButton"] > button {
      justify-content: flex-start !important;
      text-align: left !important;
      background: #ffffff !important;
      color: #111827 !important;
      border-color: #d1d5db !important;
    }
    div[data-testid="stButton"] > button:hover {
      background: #f8fafc !important;
      border-color: #9ca3af !important;
    }
    div[data-testid="stButton"] > button p {
      width: 100% !important;
      text-align: left !important;
    }
    div[data-testid="stButton"] > button[kind="primary"] p,
    button[data-testid="stBaseButton-primary"] p {
      font-weight: 800 !important;
    }
    div[data-testid="stButton"] > button[kind="secondary"] p,
    button[data-testid="stBaseButton-secondary"] p {
      font-weight: 400 !important;
    }
    div[data-testid="stButton"] > button[kind="primary"],
    button[data-testid="stBaseButton-primary"] {
      background: #ffffff !important;
      color: #111827 !important;
      border-color: #6b7280 !important;
    }
    [data-testid="stDataFrame"] * { color:#111827 !important; }
    </style>
    """,
    unsafe_allow_html=True,
)

# No legend and no multi-series unified hover box.
def base_layout(showlegend=False):
    return dict(
        showlegend=False,
        hovermode="closest",
        clickmode="event+select",
        dragmode="zoom",
        height=520,
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(color="#111827"),
        margin=dict(l=50, r=18, t=18, b=45),
        xaxis=dict(showgrid=False, zeroline=False, autorange=True),
    )


def line_fig(frame, colors, focus=None, dd=False, benchmark_map=None):
    fig = go.Figure()
    for col in frame.columns:
        if col.startswith("__BENCH__"):
            continue
        s = frame[col].dropna()
        y = (s / s.cummax() - 1) * 100 if dd else s
        width = 4.5 if col == focus else 1.8
        fig.add_trace(
            go.Scatter(
                x=y.index,
                y=y,
                mode="lines+markers",
                name=col,
                line=dict(width=width, color=colors.get(col)),
                marker=dict(size=8, opacity=0.01),
                selected=dict(marker=dict(opacity=0.01)),
                unselected=dict(marker=dict(opacity=0.01)),
                customdata=[col] * len(y),
                hovertemplate=(
                    "%{x|%d.%m.%Y}<br><b>%{y:.2f}%</b><extra></extra>"
                    if dd else
                    "%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra></extra>"
                ),
            )
        )
        if benchmark_map and col in benchmark_map and benchmark_map[col] in frame.columns:
            b = frame[benchmark_map[col]].dropna()
            by = (b / b.cummax() - 1) * 100 if dd else b
            fig.add_trace(
                go.Scatter(
                    x=by.index,
                    y=by,
                    mode="lines",
                    name="Market Proxy",
                    line=dict(width=2, color=colors.get(col), dash="dash"),
                    hovertemplate=(
                        "%{x|%d.%m.%Y}<br><b>%{y:.2f}%</b><extra>Market Proxy</extra>"
                        if dd else
                        "%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra>Market Proxy</extra>"
                    ),
                )
            )
    layout = base_layout(False)
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        autorange=True,
        type="linear" if dd else "log",
        title="Drawdown in %" if dd else "Indexiert (log)",
    )
    fig.update_layout(**layout)
    return fig


def style_heat(df, focus=None):
    pct_cols = {
        "CAGR p.a.", "Volatilität p.a.", "Max. Drawdown",
        "Tracking Error p.a."
    }
    ratio_cols = {
        "Sharpe Ratio", "Sortino", "Calmar", "Information Ratio p.a."
    }
    formats = {
        c: (lambda x: "–" if pd.isna(x) else f"{x:.2%}")
        for c in df.columns if c in pct_cols
    }
    formats.update({
        c: (lambda x: "–" if pd.isna(x) else f"{x:.2f}")
        for c in df.columns if c in ratio_cols or str(c).isdigit()
    })
    sty = df.style.format(formats, na_rep="–").set_properties(
        **{"color": "#111827", "background-color": "#ffffff"}
    )
    for column in df.select_dtypes(include="number").columns:
        values = pd.to_numeric(df[column], errors="coerce")
        valid = values.dropna()
        if valid.empty:
            continue
        lo, hi = float(valid.min()), float(valid.max())

        def paint(v):
            if pd.isna(v):
                return "color:#111827;background-color:#fff"
            p = .5 if hi == lo else (float(v) - lo) / (hi - lo)
            if p <= .5:
                w, a, b = p * 2, (248, 190, 190), (255, 244, 176)
            else:
                w, a, b = (p - .5) * 2, (255, 244, 176), (183, 229, 190)
            rgb = tuple(round(x + (y - x) * w) for x, y in zip(a, b))
            return f"background-color:rgb{rgb};color:#111827"

        sty = sty.map(paint, subset=[column])
    if focus is not None and focus in df.index:
        sty = sty.apply(
            lambda row: [
                "font-weight:800;border-top:2px solid #111827;border-bottom:2px solid #111827"
                if row.name == focus else ""
                for _ in row
            ],
            axis=1,
        )
    return sty


def compact_height(n, row=35, base=40, maximum=420):
    return min(maximum, base + max(1, n) * row)


def color_dot(i):
    return ["🔵", "🔴", "🟢", "🟣", "🟠", "🟦", "🟥", "🟩", "🟪", "🟧"][i % 10]


def _cache(name):
    if name not in st.session_state:
        st.session_state[name] = {}
    return st.session_state[name]


def session_index(name):
    cache = _cache("v9_index_data")
    if name not in cache:
        try:
            cache[name] = (resolve_index_cached(name), None)
        except Exception as exc:
            cache[name] = (None, str(exc))
    return cache[name]


def session_tech(name):
    cache = _cache("v9_tech_data")
    if name not in cache:
        cache[name] = resolve_tech_cached((name,))
    return cache[name]


def session_etf(index_name, etf_name):
    cache = _cache("v9_etf_data")
    key = (index_name, etf_name)
    if key not in cache:
        cache[key] = resolve_rows_cached(index_name, (etf_name,))
    return cache[key]


def status_text(host, done, total, label="Marktdaten geladen"):
    pct = 100 if total == 0 else round(done / total * 100)
    host.markdown(f"**{label} — {pct} %**")


def ensure_selected(key, items):
    if key not in st.session_state:
        st.session_state[key] = items.copy()
    st.session_state[key] = [x for x in st.session_state[key] if x in items]
    return st.session_state[key]


def toggle_selected(key, item, items):
    selected = list(ensure_selected(key, items))
    if item in selected:
        selected.remove(item)
    else:
        selected.append(item)
    st.session_state[key] = selected
    st.rerun()


def toggle_category(key, items):
    selected = ensure_selected(key, items)
    st.session_state[key] = [] if len(selected) == len(items) else items.copy()
    st.rerun()


def toggle_focus(name, focus_key):
    st.session_state[focus_key] = (
        None if st.session_state.get(focus_key) == name else name
    )


def handle_plot_focus(event, display, focus_key, widget_key):
    try:
        points = event.selection.points
    except Exception:
        return
    state_key = f"{widget_key}_point_signature"
    if not points:
        return
    point = points[0]
    if not isinstance(point, dict):
        return
    col = point.get("customdata")
    if col not in display:
        return
    signature = (col, point.get("point_index"), str(point.get("x")))
    if st.session_state.get(state_key) == signature:
        return
    st.session_state[state_key] = signature
    toggle_focus(display[col], focus_key)
    st.rerun()


def handle_table_focus(event, df, focus_key, widget_key):
    try:
        cells = event.selection.cells
    except Exception:
        return
    if not cells:
        return
    cell = cells[0]
    if isinstance(cell, dict):
        row_idx = cell.get("row")
        column = cell.get("column")
    elif isinstance(cell, (list, tuple)) and len(cell) >= 2:
        row_idx, column = cell[0], cell[1]
    else:
        return
    if row_idx is None or not 0 <= int(row_idx) < len(df):
        return
    signature = (int(row_idx), str(column))
    state_key = f"{widget_key}_cell_signature"
    if st.session_state.get(state_key) == signature:
        return
    st.session_state[state_key] = signature
    toggle_focus(df.index[int(row_idx)], focus_key)
    st.rerun()


registry = registry_cached()
index_order = (
    registry[["index_order", "index_name"]]
    .drop_duplicates()
    .sort_values("index_order")["index_name"]
    .tolist()
)
INDEX_COLOR = {name: PALETTE[i % len(PALETTE)] for i, name in enumerate(index_order)}
INDEX_DOT = {name: color_dot(i) for i, name in enumerate(index_order)}


def index_details(name):
    info = INDEX_INFO[name]
    st.markdown(
        f"• **Aktienklassen:** {share_text(name)}  \n"
        f"• **Segment:** {info['segment']}  \n"
        f"• **Mitglieder:** {info['members']}  \n"
        f"• **Gewichtung:** {info['weight']}  \n"
        f"• **Rebalancing:** {info['rebalance']}  \n"
        f"• **Besonderheit:** {info['special']}"
    )


def market_category(title, items, key):
    selected = ensure_selected(key, items)
    all_active = len(selected) == len(items)
    header, bulk = st.columns([.90, .10], vertical_alignment="center")
    with header:
        expander = st.expander(title, expanded=False)
    with bulk:
        if st.button(
            "Alle",
            key=f"bulk_{key}",
            type="primary" if all_active else "secondary",
            help="Gesamte Kategorie auswählen/abwählen",
            use_container_width=True,
        ):
            toggle_category(key, items)

    dialog = None
    with expander:
        for name in items:
            active = name in selected
            with st.container(border=True):
                label = f"{INDEX_DOT[name]}  {name}"
                if st.button(
                    label,
                    key=f"sel_{key}_{name}",
                    type="primary" if active else "secondary",
                    use_container_width=True,
                ):
                    toggle_selected(key, name, items)
                index_details(name)
                left, right = st.columns(2, gap="small")
                with left:
                    st.link_button(
                        "Methodology",
                        INDEX_INFO[name]["url"],
                        use_container_width=True,
                    )
                with right:
                    if st.button(
                        "ETF-Vergleich",
                        key=f"etf_{key}_{name}",
                        use_container_width=True,
                    ):
                        dialog = name
    return list(ensure_selected(key, items)), dialog


def market_tree():
    all_shares = [x for x in index_order if INDEX_SCOPE[x] == "All Shares"]
    onshore = [x for x in index_order if INDEX_SCOPE[x] == "Onshore"]
    offshore = [x for x in index_order if INDEX_SCOPE[x] == "Offshore"]

    selected = []
    dialog = None
    s, d = market_category("All Shares", all_shares, "m_all")
    selected += s
    dialog = dialog or d

    left, right = st.columns(2, gap="large")
    with left:
        s, d = market_category("Onshore", onshore, "m_on")
        selected += s
        dialog = dialog or d
    with right:
        s, d = market_category("Offshore", offshore, "m_off")
        selected += s
        dialog = dialog or d
    return selected, dialog


def render_outputs(resolved, key_prefix, focus_key, benchmark_map=None, benchmark_series=None):
    if not resolved:
        st.info("Keine verfügbaren Serien.")
        return

    series = {x.label: x.series_eur for x in resolved}
    display = {
        x.label: (x.index_name if key_prefix == "market" else x.etf_name)
        for x in resolved
    }
    colors = {
        x.label: (
            INDEX_COLOR.get(x.index_name, PALETTE[i % len(PALETTE)])
            if key_prefix == "market"
            else PALETTE[i % len(PALETTE)]
        )
        for i, x in enumerate(resolved)
    }

    if benchmark_map and benchmark_series:
        for _, benchmark_col in benchmark_map.items():
            if benchmark_col in benchmark_series:
                series[benchmark_col] = benchmark_series[benchmark_col]

    frame = common_frame(series)
    if frame.empty:
        st.error("Kein gemeinsamer Datenzeitraum.")
        return

    focus = st.session_state.get(focus_key)
    focus_col = next((c for c, n in display.items() if n == focus), None)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        key = f"{key_prefix}_perf"
        event = st.plotly_chart(
            line_fig(frame, colors, focus_col, False, benchmark_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key=key,
            on_select="rerun",
            selection_mode="points",
        )
        handle_plot_focus(event, display, focus_key, key)

    with c2:
        st.markdown("#### Drawdown")
        key = f"{key_prefix}_dd"
        event = st.plotly_chart(
            line_fig(frame, colors, focus_col, True, benchmark_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key=key,
            on_select="rerun",
            selection_mode="points",
        )
        handle_plot_focus(event, display, focus_key, key)

    corr_cols = [c for c in frame.columns if not c.startswith("__BENCH__")]
    corr_frame = frame[corr_cols]
    pair_key = f"{key_prefix}_corr_pair"
    pair = st.session_state.get(pair_key)
    if (
        not pair
        or any(x not in corr_frame.columns for x in pair)
        or pair[0] == pair[1]
    ):
        pair = (corr_cols[0], corr_cols[1]) if len(corr_cols) >= 2 else None

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        event = st.plotly_chart(
            correlation_fig(corr_frame, display, focus_col),
            width="stretch",
            config={"displaylogo": False},
            key=f"{key_prefix}_corr",
            on_select="rerun",
            selection_mode="points",
        )
        try:
            points = event.selection.points
            if points:
                custom = points[0].get("customdata")
                if custom and "|||" in custom:
                    selected_pair = tuple(custom.split("|||", 1))
                    if selected_pair[0] != selected_pair[1]:
                        st.session_state[pair_key] = selected_pair
        except Exception:
            pass

    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation")
        pair = st.session_state.get(pair_key) or pair
        if pair:
            st.plotly_chart(
                rolling_corr_fig(corr_frame, pair[0], pair[1], display),
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key=f"{key_prefix}_roll",
            )
        else:
            st.info("Mindestens zwei Serien erforderlich.")

    annual = yearly_sharpe_matrix(corr_frame, display)
    benchmark_stats = {}
    if benchmark_map:
        benchmark_stats = {
            label: frame[benchmark_col]
            for label, benchmark_col in benchmark_map.items()
            if label in corr_frame.columns and benchmark_col in frame.columns
        }
    total = total_stats(
        corr_frame,
        display,
        benchmark_stats if benchmark_map else None,
    )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Jahresperformance (Sharpe Ratio)")
        key = f"{key_prefix}_annual"
        event = st.dataframe(
            style_heat(annual, focus),
            width="stretch",
            height=compact_height(len(annual)),
            on_select="rerun",
            selection_mode="single-cell",
            key=key,
        )
        handle_table_focus(event, annual, focus_key, key)

    with c2:
        st.markdown("#### Gesamtperformance")
        key = f"{key_prefix}_total"
        event = st.dataframe(
            style_heat(total, focus),
            width="stretch",
            height=compact_height(len(total)),
            on_select="rerun",
            selection_mode="single-cell",
            key=key,
        )
        handle_table_focus(event, total, focus_key, key)


@st.dialog("ETFs des Index", width="large")
def etf_dialog(index_name):
    sub = registry[registry["index_name"] == index_name].sort_values("inception").copy()
    if sub.empty:
        st.info("Keine ETFs hinterlegt.")
        return

    top, status_col = st.columns([.68, .32])
    with top:
        st.markdown(f"### {index_name}")
    status = status_col.empty()
    progress = status_col.progress(0)

    table = sub.copy()
    table["Auflage"] = table["inception"].map(fmt_date)
    table["Mitglieder"] = INDEX_INFO[index_name]["members"]
    table["JustETF"] = table["isin"].map(
        lambda x: f"https://www.justetf.com/de/etf-profile.html?isin={x}"
    )
    show = table[
        ["etf_name", "isin", "Auflage", "Mitglieder", "ter", "distribution", "JustETF"]
    ].rename(
        columns={
            "etf_name": "ETF",
            "isin": "ISIN",
            "ter": "TER",
            "distribution": "Ertragsverwendung",
        }
    )
    st.dataframe(
        show.style.set_properties(
            **{"color": "#111827", "background-color": "#fff"}
        ).format({"TER": "{:.2f}%"}),
        width="stretch",
        height=compact_height(len(show)),
        hide_index=True,
        column_config={
            "JustETF": st.column_config.LinkColumn("Link", display_text="Öffnen")
        },
    )

    cache = _cache("v9_etf_data")
    names = sub["etf_name"].tolist()
    resolved, warnings = [], []
    done = sum((index_name, name) in cache for name in names)
    status_text(status, done, len(names), "ETF-Daten geladen")
    progress.progress(100 if not names else round(done / len(names) * 100))

    for name in names:
        if (index_name, name) not in cache:
            session_etf(index_name, name)
            done += 1
            status_text(status, done, len(names), "ETF-Daten geladen")
            progress.progress(round(done / len(names) * 100))
        rows, row_warnings = cache[(index_name, name)]
        resolved += rows
        warnings += row_warnings

    for warning in warnings:
        st.warning(warning)
    if resolved:
        render_outputs(
            resolved,
            f"dlg_{abs(hash(index_name))}",
            f"dlg_focus_{abs(hash(index_name))}",
        )


def parse_share_classes(value):
    result = []
    for item in [x.strip() for x in str(value).split(",") if x.strip()]:
        result.append(
            "Auslandslistings / ADRs"
            if item in {"ADRs", "Foreign listings", "Auslandslistings"}
            else item
        )
    return frozenset(result)


def tech_category(title, rows, key, offset=0):
    items = rows["etf_name"].tolist()
    selected = ensure_selected(key, items)
    all_active = len(selected) == len(items)

    header, bulk = st.columns([.90, .10], vertical_alignment="center")
    with header:
        expander = st.expander(title, expanded=False)
    with bulk:
        if st.button(
            "Alle",
            key=f"tech_bulk_{key}",
            type="primary" if all_active else "secondary",
            help="Gesamte Kategorie auswählen/abwählen",
            use_container_width=True,
        ):
            toggle_category(key, items)

    with expander:
        for j, (_, row) in enumerate(rows.iterrows()):
            name = row["etf_name"]
            active = name in selected
            proxy = MARKET_PROXY_BY_SIGNATURE.get(
                parse_share_classes(row["share_classes"]), "–"
            )
            with st.container(border=True):
                if st.button(
                    f"{color_dot(offset + j)}  {name}",
                    key=f"tech_{key}_{name}",
                    type="primary" if active else "secondary",
                    use_container_width=True,
                ):
                    toggle_selected(key, name, items)
                st.markdown(
                    f"• **Index:** {row['index_name']}  \n"
                    f"• **Aktienklassen:** {row['share_classes']}  \n"
                    f"• **Mitglieder:** {row['members']}  \n"
                    f"• **Market Proxy (Benchmark für IR/TE):** {proxy}  \n"
                    f"• **TER:** {row['ter']:.2f}%"
                )
                st.link_button(
                    "ETF / Methodology",
                    row["source_url"],
                    use_container_width=True,
                )
    return list(ensure_selected(key, items))


def render_tech(status_host):
    tech = tech_registry_cached().copy()
    selected = []

    all_rows = tech[tech["universe"] == "All Shares"]
    if not all_rows.empty:
        selected += tech_category("All Shares", all_rows, "t_all", 0)

    left, right = st.columns(2, gap="large")
    on_rows = tech[tech["universe"] == "Onshore"]
    off_rows = tech[tech["universe"] == "Offshore"]
    with left:
        if not on_rows.empty:
            selected += tech_category("Onshore", on_rows, "t_on", len(all_rows))
    with right:
        if not off_rows.empty:
            selected += tech_category(
                "Offshore",
                off_rows,
                "t_off",
                len(all_rows) + len(on_rows),
            )

    if not selected:
        st.info("Tech-ETFs auswählen.")
        return

    cache = _cache("v9_tech_data")
    status = status_host.empty()
    progress = status_host.progress(0)
    done = sum(name in cache for name in selected)
    status_text(status, done, len(selected))
    progress.progress(round(done / len(selected) * 100))

    for name in selected:
        if name not in cache:
            session_tech(name)
            done += 1
            status_text(status, done, len(selected))
            progress.progress(round(done / len(selected) * 100))

    resolved, warnings = [], []
    for name in selected:
        items, item_warnings = cache[name]
        resolved += items
        warnings += item_warnings

    for warning in warnings:
        st.warning(warning)
    if not resolved:
        return

    meta = tech.set_index("etf_name")
    benchmark_map, benchmark_series = {}, {}
    for item in resolved:
        if item.etf_name not in meta.index:
            continue
        proxy = MARKET_PROXY_BY_SIGNATURE.get(
            parse_share_classes(meta.loc[item.etf_name, "share_classes"])
        )
        if not proxy:
            continue
        benchmark, error = session_index(proxy)
        if benchmark is None:
            continue
        benchmark_col = f"__BENCH__{item.label}"
        benchmark_map[item.label] = benchmark_col
        benchmark_series[benchmark_col] = benchmark.series_eur

    render_outputs(
        resolved,
        "tech",
        "tech_focus",
        benchmark_map,
        benchmark_series,
    )


# ---------- Asset Allocation Backtesting ----------

@st.cache_data(ttl=60 * 60, show_spinner=False)
def yahoo_search(query):
    query = str(query or "").strip()
    if not query:
        return []
    results = []
    try:
        search = yf.Search(query, max_results=10)
        for item in (getattr(search, "quotes", None) or []):
            symbol = str(item.get("symbol") or "").strip()
            if not symbol:
                continue
            quote_type = str(item.get("quoteType") or item.get("typeDisp") or "")
            if quote_type.upper() not in {
                "EQUITY", "ETF", "MUTUALFUND", "INDEX", "CRYPTOCURRENCY"
            }:
                continue
            name = (
                item.get("longname")
                or item.get("shortname")
                or item.get("name")
                or symbol
            )
            exchange = item.get("exchange") or item.get("exchDisp") or ""
            results.append(
                {
                    "symbol": symbol,
                    "name": str(name),
                    "exchange": str(exchange),
                    "type": quote_type,
                }
            )
    except Exception:
        pass

    if not results:
        results.append(
            {"symbol": query.upper(), "name": query, "exchange": "", "type": "Direkteingabe"}
        )
    seen = set()
    unique = []
    for item in results:
        if item["symbol"] in seen:
            continue
        seen.add(item["symbol"])
        unique.append(item)
    return unique[:10]


@st.cache_data(ttl=6 * 60 * 60, show_spinner=False)
def asset_series_eur(symbol):
    prices = download_adjusted_close(symbol, start="2000-01-01")
    if len(prices) < 30:
        raise RuntimeError(f"{symbol}: zu wenig Kursdaten")
    currency = detect_currency(symbol, "EUR")
    eur, detected = convert_to_eur(prices, currency)
    if len(eur) < 30:
        raise RuntimeError(f"{symbol}: zu wenig EUR-Daten")
    return eur.rename(symbol), detected


def _aa_assets():
    if "aa_assets" not in st.session_state:
        st.session_state.aa_assets = []
    return st.session_state.aa_assets


def add_asset(result):
    assets = _aa_assets()
    if any(x["symbol"] == result["symbol"] for x in assets):
        return
    assets.append(
        {
            "symbol": result["symbol"],
            "name": result["name"],
            "weight": 0.0,
        }
    )
    equal = 100.0 / len(assets)
    for asset in assets:
        asset["weight"] = equal


def remove_asset(symbol):
    assets = _aa_assets()
    st.session_state.aa_assets = [x for x in assets if x["symbol"] != symbol]
    assets = st.session_state.aa_assets
    if assets:
        equal = 100.0 / len(assets)
        for asset in assets:
            asset["weight"] = equal


def rebalance_key(date, frequency):
    if frequency == "Monatlich":
        return (date.year, date.month)
    if frequency == "Quartalsweise":
        return (date.year, (date.month - 1) // 3)
    if frequency == "Halbjährlich":
        return (date.year, (date.month - 1) // 6)
    if frequency == "Jährlich":
        return (date.year,)
    return None


def backtest_portfolio(prices, weights, frequency):
    returns = prices.pct_change(fill_method=None).fillna(0.0)
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.sum()
    values = weights.copy()
    output = []
    last_key = None

    for date, row in returns.iterrows():
        key = rebalance_key(pd.Timestamp(date), frequency)
        if (
            frequency != "Kein Rebalancing"
            and key != last_key
            and len(output) > 0
        ):
            total = float(values.sum())
            values = total * weights
        values = values * (1.0 + row.to_numpy(dtype=float))
        output.append(float(values.sum()))
        last_key = key

    return pd.Series(output, index=returns.index, name="Portfolio") * 100.0


def backtest_metrics(series):
    series = series.dropna()
    if len(series) < 2:
        return {}
    returns = series.pct_change(fill_method=None).dropna()
    cg = cagr(series)
    vola = returns.std(ddof=1) * math.sqrt(252) if len(returns) > 1 else np.nan
    shp = (
        returns.mean() / returns.std(ddof=1) * math.sqrt(252)
        if len(returns) > 1 and returns.std(ddof=1) != 0
        else np.nan
    )
    dd = max_drawdown(series)
    srt = sortino(series, 0.0)
    calmar = cg / abs(dd) if dd and not np.isnan(dd) else np.nan
    return {
        "CAGR p.a.": cg,
        "Volatilität p.a.": vola,
        "Sharpe Ratio": shp,
        "Max. Drawdown": dd,
        "Sortino": srt,
        "Calmar": calmar,
    }


def render_asset_allocation_tool():
    st.title("Asset Allocation Backtesting Tool")
    st.caption(
        "Freie Wertpapiersuche über Yahoo Finance. Name, Ticker oder ISIN eingeben; "
        "bei nicht eindeutig auflösbaren ISINs funktioniert der Yahoo-Ticker am zuverlässigsten."
    )

    st.markdown("### Wertpapier hinzufügen")
    query = st.text_input(
        "Name, Ticker oder ISIN",
        key="aa_search_query",
        placeholder="z. B. Apple, AAPL oder US0378331005",
    )
    results = yahoo_search(query) if query else []
    if results:
        labels = [
            f"{x['name']} · {x['symbol']}"
            + (f" · {x['exchange']}" if x["exchange"] else "")
            for x in results
        ]
        selected_label = st.selectbox(
            "Suchergebnis",
            labels,
            key="aa_search_result",
        )
        selected_result = results[labels.index(selected_label)]
        add_col, benchmark_col = st.columns(2)
        with add_col:
            if st.button("Zum Portfolio hinzufügen", use_container_width=True):
                add_asset(selected_result)
                st.rerun()
        with benchmark_col:
            if st.button("Als Benchmark verwenden", use_container_width=True):
                st.session_state.aa_benchmark = selected_result
                st.rerun()

    assets = _aa_assets()
    if assets:
        st.markdown("### Portfolio")
        for i, asset in enumerate(list(assets)):
            c1, c2, c3 = st.columns([.54, .28, .18], vertical_alignment="center")
            with c1:
                st.markdown(f"**{asset['name']}**  \n`{asset['symbol']}`")
            with c2:
                new_weight = st.number_input(
                    "Gewicht %",
                    min_value=0.0,
                    max_value=100.0,
                    value=float(asset["weight"]),
                    step=1.0,
                    key=f"aa_weight_{asset['symbol']}",
                )
                asset["weight"] = float(new_weight)
            with c3:
                if st.button(
                    "Entfernen",
                    key=f"aa_remove_{asset['symbol']}",
                    use_container_width=True,
                ):
                    remove_asset(asset["symbol"])
                    st.rerun()

        total_weight = sum(x["weight"] for x in assets)
        st.caption(f"Summe Gewichte: {total_weight:.2f} %")
    else:
        st.info("Noch keine Wertpapiere im Portfolio.")

    benchmark = st.session_state.get("aa_benchmark")
    if benchmark:
        st.markdown(
            f"**Benchmark:** {benchmark['name']} · `{benchmark['symbol']}`"
        )

    rebalance = st.selectbox(
        "Rebalancing",
        [
            "Monatlich",
            "Quartalsweise",
            "Halbjährlich",
            "Jährlich",
            "Kein Rebalancing",
        ],
        index=1,
        key="aa_rebalance",
    )

    if st.button("Backtest starten", type="primary", use_container_width=True):
        if not assets:
            st.error("Mindestens ein Wertpapier hinzufügen.")
            return
        if not benchmark:
            st.error("Bitte eine Benchmark auswählen.")
            return
        weights = np.array([x["weight"] for x in assets], dtype=float)
        if weights.sum() <= 0:
            st.error("Die Summe der Gewichte muss größer als 0 sein.")
            return

        price_series = {}
        errors = []
        with st.spinner("Kursdaten werden geladen …"):
            for asset in assets:
                try:
                    series, _ = asset_series_eur(asset["symbol"])
                    price_series[asset["symbol"]] = series
                except Exception as exc:
                    errors.append(str(exc))
            try:
                benchmark_series, _ = asset_series_eur(benchmark["symbol"])
            except Exception as exc:
                benchmark_series = None
                errors.append(f"Benchmark: {exc}")

        if errors:
            for error in errors:
                st.warning(error)
        if len(price_series) != len(assets) or benchmark_series is None:
            st.error("Backtest konnte nicht vollständig geladen werden.")
            return

        prices = pd.concat(price_series, axis=1).dropna()
        benchmark_series = benchmark_series.reindex(prices.index).dropna()
        common_index = prices.index.intersection(benchmark_series.index)
        prices = prices.loc[common_index]
        benchmark_series = benchmark_series.loc[common_index]
        if len(prices) < 30:
            st.error("Zu wenig gemeinsamer Datenzeitraum.")
            return

        portfolio = backtest_portfolio(
            prices,
            weights,
            rebalance,
        )
        benchmark_indexed = benchmark_series / benchmark_series.iloc[0] * 100.0

        comparison = pd.concat(
            [portfolio.rename("Portfolio"), benchmark_indexed.rename("Benchmark")],
            axis=1,
        ).dropna()

        perf = go.Figure()
        perf.add_trace(
            go.Scatter(
                x=comparison.index,
                y=comparison["Portfolio"],
                mode="lines",
                name="Portfolio",
                line=dict(width=2.8),
            )
        )
        perf.add_trace(
            go.Scatter(
                x=comparison.index,
                y=comparison["Benchmark"],
                mode="lines",
                name="Benchmark",
                line=dict(width=2.0, dash="dash"),
            )
        )
        layout = base_layout(True)
        layout["showlegend"] = True
        layout["yaxis"] = dict(showgrid=False, type="log", title="Indexiert (log)")
        perf.update_layout(**layout)

        dd = comparison / comparison.cummax() - 1.0
        dd_fig = go.Figure()
        for col in dd.columns:
            dd_fig.add_trace(
                go.Scatter(
                    x=dd.index,
                    y=dd[col] * 100,
                    mode="lines",
                    name=col,
                    line=dict(width=2.5 if col == "Portfolio" else 2.0,
                              dash="dash" if col == "Benchmark" else "solid"),
                )
            )
        dd_layout = base_layout(True)
        dd_layout["showlegend"] = True
        dd_layout["yaxis"] = dict(showgrid=False, title="Drawdown in %")
        dd_fig.update_layout(**dd_layout)

        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown("#### Wertentwicklung")
            st.plotly_chart(
                perf,
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
            )
        with c2:
            st.markdown("#### Drawdown")
            st.plotly_chart(
                dd_fig,
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
            )

        stats = pd.DataFrame(
            {
                "Portfolio": backtest_metrics(comparison["Portfolio"]),
                "Benchmark": backtest_metrics(comparison["Benchmark"]),
            }
        ).T
        st.markdown("#### Kennzahlen")
        st.dataframe(
            style_heat(stats),
            width="stretch",
            height=compact_height(len(stats)),
        )

        weights_display = pd.DataFrame(
            {
                "Wertpapier": [x["name"] for x in assets],
                "Ticker": [x["symbol"] for x in assets],
                "Gewicht": weights / weights.sum(),
            }
        )
        st.markdown("#### Backtest-Konfiguration")
        st.dataframe(
            weights_display.style.format({"Gewicht": "{:.2%}"}),
            width="stretch",
            hide_index=True,
            height=compact_height(len(weights_display)),
        )
        st.caption(
            f"Rebalancing: {rebalance} · Zeitraum: "
            f"{comparison.index.min():%d.%m.%Y} – {comparison.index.max():%d.%m.%Y}"
        )


def render_china_dashboard():
    st.title("China ETF Dashboard")
    nav, status_col = st.columns([.58, .42], vertical_alignment="center")
    with nav:
        page = st.segmented_control(
            "Bereich",
            ["Market ETFs vergleichen", "Tech ETFs vergleichen"],
            selection_mode="single",
            default=st.session_state.get("china_page", "Market ETFs vergleichen"),
            key="china_subpage",
            label_visibility="collapsed",
        ) or "Market ETFs vergleichen"
        st.session_state.china_page = page

    if page == "Market ETFs vergleichen":
        selected, dialog = market_tree()
        status = status_col.empty()
        progress = status_col.progress(0)
        cache = _cache("v9_index_data")
        done = sum(name in cache for name in selected)
        status_text(status, done, len(selected))
        progress.progress(100 if not selected else round(done / len(selected) * 100))

        for name in selected:
            if name not in cache:
                session_index(name)
                done += 1
                status_text(status, done, len(selected))
                progress.progress(round(done / len(selected) * 100))

        resolved, warnings = [], []
        for name in selected:
            item, error = cache[name]
            if item is not None:
                resolved.append(item)
            if error:
                warnings.append(f"{name}: {error}")
        for warning in warnings:
            st.warning(warning)

        render_outputs(resolved, "market", "market_focus")
        if dialog:
            etf_dialog(dialog)
    else:
        render_tech(status_col)


st.markdown(
    """
    <style>
    .block-container { padding-top:.7rem !important; }
    div[data-testid="stRadio"] [role="radiogroup"] {
      display:flex !important; gap:1.7rem !important; flex-wrap:wrap !important;
      border-bottom:1px solid #e5e7eb !important; margin-bottom:.45rem !important;
    }
    div[data-testid="stRadio"] label {
      background:transparent !important; border:none !important; border-radius:0 !important;
      padding:.55rem .05rem .45rem .05rem !important; margin:0 !important; white-space:nowrap !important;
    }
    div[data-testid="stRadio"] label:has(input:checked) { border-bottom:2px solid #111827 !important; }
    div[data-testid="stRadio"] label:has(input:checked) p { font-weight:700 !important; color:#111827 !important; }
    div[data-testid="stRadio"] input { display:none !important; }
    [data-testid="stDataFrame"] input[type="checkbox"],
    [data-testid="stDataFrame"] [role="checkbox"] { display:none !important; }
    .selector-box {
      display:block; width:100%; box-sizing:border-box; padding:.58rem .72rem;
      margin:.05rem 0 .45rem 0; border-radius:.58rem; text-decoration:none !important;
      line-height:1.25;
    }
    .selector-box:hover { filter:brightness(.98); }
    .meta-line { color:#4b5563; font-size:.82rem; }
    </style>
    """,
    unsafe_allow_html=True,
)


def base_layout(showlegend=False):
    return dict(
        showlegend=showlegend, hovermode="closest", clickmode="event+select",
        dragmode="zoom", height=520, plot_bgcolor="white", paper_bgcolor="white",
        font=dict(color="#111827"), margin=dict(l=50, r=18, t=18, b=45),
        xaxis=dict(showgrid=False, zeroline=False, autorange=True),
    )


def line_fig(frame, colors, focus=None, dd=False, benchmark_map=None):
    fig = go.Figure()
    for col in frame.columns:
        if col.startswith("__BENCH__"):
            continue
        s = frame[col].dropna()
        y = (s / s.cummax() - 1) * 100 if dd else s
        focused = focus == col
        fig.add_trace(go.Scatter(
            x=y.index, y=y, mode="lines+markers", name=col,
            line=dict(width=4.8 if focused else 1.8, color=colors.get(col)),
            opacity=1.0 if focus is None or focused else .55,
            marker=dict(size=18, opacity=.003),
            selected=dict(marker=dict(opacity=.003)), unselected=dict(marker=dict(opacity=.003)),
            customdata=[col] * len(y),
            hovertemplate=("%{x|%d.%m.%Y}<br><b>%{y:.2f}%</b><extra></extra>" if dd
                           else "%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra></extra>"),
        ))
        if benchmark_map and col in benchmark_map and benchmark_map[col] in frame.columns:
            b = frame[benchmark_map[col]].dropna()
            by = (b / b.cummax() - 1) * 100 if dd else b
            fig.add_trace(go.Scatter(
                x=by.index, y=by, mode="lines", name="Market Proxy",
                line=dict(width=2, color=colors.get(col), dash="dash"),
                opacity=1.0 if focus is None or focused else .35,
                hovertemplate=("%{x|%d.%m.%Y}<br><b>%{y:.2f}%</b><extra>Market Proxy</extra>" if dd
                               else "%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra>Market Proxy</extra>"),
            ))
    layout = base_layout(False)
    layout["yaxis"] = dict(showgrid=False, zeroline=False, autorange=True,
                           type="linear" if dd else "log",
                           title="Drawdown in %" if dd else "Indexiert (log)")
    fig.update_layout(**layout)
    return fig


def _cell_color(value, lo, hi, reverse=False):
    if pd.isna(value):
        return "color:#111827;background-color:#fff"
    p = .5 if hi == lo else (float(value) - lo) / (hi - lo)
    if reverse:
        p = 1 - p
    if p <= .5:
        w, a, b = p * 2, (248, 190, 190), (255, 244, 176)
    else:
        w, a, b = (p - .5) * 2, (255, 244, 176), (183, 229, 190)
    rgb = tuple(round(x + (y - x) * w) for x, y in zip(a, b))
    return f"background-color:rgb{rgb};color:#111827"


def style_heat(df, focus=None, reverse_columns=None):
    reverse_columns = set(reverse_columns or [])
    pct = {"CAGR p.a.", "Volatilität p.a.", "Max. Drawdown", "Tracking Error p.a."}
    ratios = {"Sharpe Ratio", "Sortino", "Calmar", "Information Ratio p.a."}
    fmts = {c: (lambda x: "–" if pd.isna(x) else f"{x:.2%}") for c in df.columns if c in pct}
    fmts.update({c: (lambda x: "–" if pd.isna(x) else f"{x:.2f}")
                 for c in df.columns if c in ratios or str(c).isdigit()})
    sty = df.style.format(fmts, na_rep="–").set_properties(**{"color":"#111827", "background-color":"#fff"})
    for col in df.select_dtypes(include="number").columns:
        vals = pd.to_numeric(df[col], errors="coerce").dropna()
        if vals.empty:
            continue
        lo, hi = float(vals.min()), float(vals.max())
        rev = col in reverse_columns
        sty = sty.map(lambda v, lo=lo, hi=hi, rev=rev: _cell_color(v, lo, hi, rev), subset=[col])
    if focus is not None and focus in df.index:
        sty = sty.apply(lambda row: [
            "font-weight:800;border-top:2px solid #111827;border-bottom:2px solid #111827"
            if row.name == focus else "" for _ in row
        ], axis=1)
    return sty


def status_text(host, done, total, label="Marktdaten geladen"):
    pct = 100 if total == 0 else round(done / total * 100)
    host.markdown(f"{label} — ({pct} %)")


def hex_rgba(hex_color, alpha):
    value = hex_color.lstrip("#")
    r, g, b = int(value[:2], 16), int(value[2:4], 16), int(value[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def selector_box(label, state_key, item, color, active):
    token = quote(f"{state_key}|||{item}", safe="")
    background = hex_rgba(color, .10) if active else "rgba(255,255,255,0)"
    weight = 700 if active else 400
    st.markdown(
        f'<a class="selector-box" href="?toggle={token}" target="_self" '
        f'style="border:1.5px solid {color};background:{background};color:{color};font-weight:{weight};">'
        f'{html.escape(str(label))}</a>',
        unsafe_allow_html=True,
    )


def process_toggle_query():
    token = st.query_params.get("toggle")
    if not token:
        return
    try:
        state_key, item = unquote(str(token)).split("|||", 1)
        current = list(st.session_state.get(state_key, []))
        if item in current:
            current.remove(item)
        else:
            current.append(item)
        st.session_state[state_key] = current
    except Exception:
        pass
    st.query_params.clear()
    st.rerun()


TECH_NAMES = tech_registry_cached()["etf_name"].drop_duplicates().tolist()
TECH_COLOR = {name: PALETTE[i % len(PALETTE)] for i, name in enumerate(TECH_NAMES)}
process_toggle_query()


def market_category(title, items, key):
    selected = ensure_selected(key, items)
    dialog = None
    with st.expander(title, expanded=False):
        for name in items:
            selector_box(name, key, name, INDEX_COLOR[name], name in selected)
            index_details(name)
            left, right = st.columns(2, gap="small")
            with left:
                st.link_button("Methodology", INDEX_INFO[name]["url"], use_container_width=True)
            with right:
                if st.button("ETF-Vergleich", key=f"etf_{key}_{name}", use_container_width=True):
                    dialog = name
            st.divider()
    return list(ensure_selected(key, items)), dialog


def tech_category(title, rows, key, offset=0):
    items = rows["etf_name"].tolist()
    selected = ensure_selected(key, items)
    with st.expander(title, expanded=False):
        for _, row in rows.iterrows():
            name = row["etf_name"]
            color = TECH_COLOR.get(name, "#6b7280")
            proxy = MARKET_PROXY_BY_SIGNATURE.get(parse_share_classes(row["share_classes"]), "–")
            selector_box(name, key, name, color, name in selected)
            st.markdown(
                f"• **Index:** {row['index_name']}  \n"
                f"• **Aktienklassen:** {row['share_classes']}  \n"
                f"• **Mitglieder:** {row['members']}  \n"
                f"• **Market Proxy (Benchmark für IR/TE):** {proxy}  \n"
                f"• **TER:** {row['ter']:.2f}%"
            )
            st.link_button("ETF / Methodology", row["source_url"], use_container_width=True)
            st.divider()
    return list(ensure_selected(key, items))


def handle_table_focus(event, df, focus_key):
    try:
        rows = event.selection.rows
    except Exception:
        return
    if not rows:
        return
    idx = int(rows[0])
    if 0 <= idx < len(df):
        toggle_focus(df.index[idx], focus_key)
        st.rerun()


def render_outputs(resolved, key_prefix, focus_key, benchmark_map=None, benchmark_series=None):
    if not resolved:
        return
    series = {x.label:x.series_eur for x in resolved}
    display = {x.label:(x.index_name if key_prefix == "market" else x.etf_name) for x in resolved}
    colors = {}
    for i, item in enumerate(resolved):
        if key_prefix == "market":
            colors[item.label] = INDEX_COLOR.get(item.index_name, PALETTE[i % len(PALETTE)])
        elif key_prefix == "tech":
            colors[item.label] = TECH_COLOR.get(item.etf_name, PALETTE[i % len(PALETTE)])
        else:
            colors[item.label] = PALETTE[i % len(PALETTE)]
    if benchmark_map and benchmark_series:
        for _, bcol in benchmark_map.items():
            if bcol in benchmark_series:
                series[bcol] = benchmark_series[bcol]
    frame = common_frame(series)
    if frame.empty:
        return
    focus = st.session_state.get(focus_key)
    focus_col = next((c for c,n in display.items() if n == focus), None)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        key = f"{key_prefix}_perf"
        event = st.plotly_chart(line_fig(frame, colors, focus_col, False, benchmark_map),
                                width="stretch", config={"displaylogo":False,"scrollZoom":True},
                                key=key, on_select="rerun", selection_mode="points")
        handle_plot_focus(event, display, focus_key, key)
    with c2:
        st.markdown("#### Drawdown")
        key = f"{key_prefix}_dd"
        event = st.plotly_chart(line_fig(frame, colors, focus_col, True, benchmark_map),
                                width="stretch", config={"displaylogo":False,"scrollZoom":True},
                                key=key, on_select="rerun", selection_mode="points")
        handle_plot_focus(event, display, focus_key, key)

    corr_cols = [c for c in frame.columns if not c.startswith("__BENCH__")]
    corr_frame = frame[corr_cols]
    pair_key = f"{key_prefix}_corr_pair"
    pair = st.session_state.get(pair_key)
    if not pair or any(x not in corr_frame.columns for x in pair) or pair[0] == pair[1]:
        pair = (corr_cols[0], corr_cols[1]) if len(corr_cols) >= 2 else None
    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        event = st.plotly_chart(correlation_fig(corr_frame, display, focus_col), width="stretch",
                                config={"displaylogo":False}, key=f"{key_prefix}_corr",
                                on_select="rerun", selection_mode="points")
        try:
            pts = event.selection.points
            if pts:
                custom = pts[0].get("customdata")
                if custom and "|||" in custom:
                    p = tuple(custom.split("|||", 1))
                    if p[0] != p[1]:
                        st.session_state[pair_key] = p
        except Exception:
            pass
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation")
        pair = st.session_state.get(pair_key) or pair
        if pair:
            st.plotly_chart(rolling_corr_fig(corr_frame, pair[0], pair[1], display), width="stretch",
                            config={"displaylogo":False,"scrollZoom":True}, key=f"{key_prefix}_roll")

    annual = yearly_sharpe_matrix(corr_frame, display)
    bench_stats = {}
    if benchmark_map:
        bench_stats = {lab:frame[bcol] for lab,bcol in benchmark_map.items()
                       if lab in corr_frame.columns and bcol in frame.columns}
    total = total_stats(corr_frame, display, bench_stats if benchmark_map else None)
    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Jahresperformance (Sharpe Ratio)")
        event = st.dataframe(style_heat(annual, focus), width="stretch", height=compact_height(len(annual)),
                             on_select="rerun", selection_mode="single-row",
                             key=f"{key_prefix}_annual_{abs(hash(focus or 'none'))}")
        handle_table_focus(event, annual, focus_key)
    with c2:
        st.markdown("#### Gesamtperformance")
        event = st.dataframe(style_heat(total, focus), width="stretch", height=compact_height(len(total)),
                             on_select="rerun", selection_mode="single-row",
                             key=f"{key_prefix}_total_{abs(hash(focus or 'none'))}")
        handle_table_focus(event, total, focus_key)


@st.cache_data(ttl=60 * 60, show_spinner=False)
def yahoo_search(query):
    query = str(query or "").strip()
    if not query:
        return []
    results = []
    try:
        search = yf.Search(query, max_results=10)
        for item in (getattr(search, "quotes", None) or []):
            symbol = str(item.get("symbol") or "").strip()
            if not symbol:
                continue
            quote_type = str(item.get("quoteType") or item.get("typeDisp") or "")
            if quote_type.upper() not in {"EQUITY","ETF","MUTUALFUND","INDEX","CRYPTOCURRENCY"}:
                continue
            results.append({
                "symbol": symbol,
                "name": str(item.get("longname") or item.get("shortname") or item.get("name") or symbol),
                "exchange_code": str(item.get("exchange") or "").strip(),
                "exchange_name": str(item.get("exchDisp") or item.get("fullExchangeName") or item.get("exchangeName") or "").strip(),
                "type": quote_type,
            })
    except Exception:
        pass
    if not results:
        results.append({"symbol":query.upper(),"name":query,"exchange_code":"","exchange_name":"","type":"Direkteingabe"})
    seen, unique = set(), []
    for item in results:
        if item["symbol"] not in seen:
            seen.add(item["symbol"]); unique.append(item)
    return unique[:10]


def asset_range_text(symbol):
    try:
        series, _ = asset_series_eur(symbol)
        return f"{series.index.min():%d.%m.%Y} – {series.index.max():%d.%m.%Y}"
    except Exception:
        return "–"


def correlation_heatmap(frame):
    corr = frame.pct_change(fill_method=None).dropna().corr()
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=corr.columns, y=corr.index, zmin=-1, zmax=1, zmid=0,
        colorscale="RdYlGn", text=np.round(corr.values,2), texttemplate="%{text:.2f}",
        hovertemplate="%{y} ↔ %{x}<br><b>%{z:.3f}</b><extra></extra>"))
    fig.update_layout(height=500, margin=dict(l=30,r=15,t=15,b=30),
                      plot_bgcolor="white", paper_bgcolor="white", font=dict(color="#111827"))
    return fig


def rolling_benchmark_corr(frame):
    returns = frame.pct_change(fill_method=None).dropna()
    fig = go.Figure()
    for col in frame.columns:
        if col == "Benchmark":
            continue
        rolling = returns[col].rolling(252, min_periods=126).corr(returns["Benchmark"])
        fig.add_trace(go.Scatter(x=rolling.index, y=rolling, mode="lines",
                                 name=f"{col} ↔ Benchmark", line=dict(width=2)))
    layout = base_layout(True)
    layout["height"] = 500
    layout["yaxis"] = dict(showgrid=False, zeroline=True, range=[-1,1], title="Korrelation")
    fig.update_layout(**layout)
    return fig


def render_asset_allocation_tool():
    query = st.text_input("Name, Ticker oder ISIN", key="aa_search_query",
                          placeholder="z. B. Micron, MU oder US5951121038")
    results = yahoo_search(query) if query else []
    if results:
        labels = []
        for x in results:
            venue = f"{x['symbol']}-{x['exchange_code']}" if x['exchange_code'] else x['symbol']
            if x['exchange_name']:
                venue += f" · {x['exchange_name']}"
            labels.append(f"{x['name']} — {venue}")
        selected_label = st.selectbox("Suchergebnis", labels, key="aa_search_result")
        selected_result = results[labels.index(selected_label)]
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Zum Portfolio hinzufügen", use_container_width=True):
                add_asset(selected_result); st.session_state.aa_run = False; st.rerun()
        with c2:
            if st.button("Als Benchmark verwenden", use_container_width=True):
                st.session_state.aa_benchmark = selected_result; st.session_state.aa_run = False; st.rerun()

    assets = _aa_assets()
    if assets:
        st.markdown("#### Portfolio")
        for asset in list(assets):
            c1, c2, c3 = st.columns([.56,.30,.14], vertical_alignment="center")
            with c1:
                st.markdown(f"**{asset['name']}**  \n`{asset['symbol']}`  \n"
                            f"<span class='meta-line'>{asset_range_text(asset['symbol'])}</span>",
                            unsafe_allow_html=True)
            with c2:
                new_weight = st.number_input("Gewicht %", min_value=0.0, max_value=100.0,
                                             value=float(asset['weight']), step=1.0,
                                             key=f"aa_weight_{asset['symbol']}")
                if float(new_weight) != float(asset['weight']):
                    asset['weight'] = float(new_weight); st.session_state.aa_run = False
            with c3:
                if st.button("🗑️", key=f"aa_remove_{asset['symbol']}", use_container_width=True):
                    remove_asset(asset['symbol']); st.rerun()

    benchmark = st.session_state.get("aa_benchmark")
    if benchmark:
        st.markdown(f"**Benchmark:** {benchmark['name']} · `{benchmark['symbol']}`  \n"
                    f"<span class='meta-line'>{asset_range_text(benchmark['symbol'])}</span>",
                    unsafe_allow_html=True)

    rebalance = st.selectbox("Rebalancing",
                             ["Monatlich","Quartalsweise","Halbjährlich","Jährlich","Kein Rebalancing"],
                             index=1, key="aa_rebalance")
    if st.button("Backtest starten", type="primary", use_container_width=True):
        st.session_state.aa_run = True
    if not st.session_state.get("aa_run") or not assets or not benchmark:
        return

    weights = np.array([x['weight'] for x in assets], dtype=float)
    if weights.sum() <= 0:
        st.error("Die Summe der Gewichte muss größer als 0 sein."); return
    price_series, errors = {}, []
    for asset in assets:
        try:
            series, _ = asset_series_eur(asset['symbol']); price_series[asset['symbol']] = series
        except Exception as exc:
            errors.append(str(exc))
    try:
        benchmark_series, _ = asset_series_eur(benchmark['symbol'])
    except Exception as exc:
        benchmark_series = None; errors.append(f"Benchmark: {exc}")
    for error in errors:
        st.warning(error)
    if len(price_series) != len(assets) or benchmark_series is None:
        return

    prices = pd.concat(price_series, axis=1).dropna()
    benchmark_series = benchmark_series.reindex(prices.index).dropna()
    common_index = prices.index.intersection(benchmark_series.index)
    prices, benchmark_series = prices.loc[common_index], benchmark_series.loc[common_index]
    if len(prices) < 30:
        return
    portfolio = backtest_portfolio(prices, weights, rebalance)
    benchmark_indexed = benchmark_series / benchmark_series.iloc[0] * 100
    comparison = pd.concat([portfolio.rename("Portfolio"), benchmark_indexed.rename("Benchmark")], axis=1).dropna()

    perf = go.Figure()
    perf.add_trace(go.Scatter(x=comparison.index,y=comparison['Portfolio'],mode='lines',name='Portfolio',line=dict(width=2.8)))
    perf.add_trace(go.Scatter(x=comparison.index,y=comparison['Benchmark'],mode='lines',name='Benchmark',line=dict(width=2,dash='dash')))
    layout = base_layout(True); layout['yaxis'] = dict(showgrid=False,type='log',title='Indexiert (log)'); perf.update_layout(**layout)
    dd = comparison / comparison.cummax() - 1
    dd_fig = go.Figure()
    dd_fig.add_trace(go.Scatter(x=dd.index,y=dd['Portfolio']*100,mode='lines',name='Portfolio',line=dict(width=2.8)))
    dd_fig.add_trace(go.Scatter(x=dd.index,y=dd['Benchmark']*100,mode='lines',name='Benchmark',line=dict(width=2,dash='dash')))
    layout = base_layout(True); layout['yaxis'] = dict(showgrid=False,title='Drawdown in %'); dd_fig.update_layout(**layout)
    c1,c2 = st.columns(2,gap='large')
    with c1:
        st.markdown('#### Wertentwicklung'); st.plotly_chart(perf,width='stretch',config={'displaylogo':False,'scrollZoom':True})
    with c2:
        st.markdown('#### Drawdown'); st.plotly_chart(dd_fig,width='stretch',config={'displaylogo':False,'scrollZoom':True})

    name_map = {x['symbol']:f"{x['name']} ({x['symbol']})" for x in assets}
    component = (prices / prices.iloc[0] * 100).rename(columns=name_map)
    component['Benchmark'] = benchmark_indexed.reindex(component.index)
    comp_fig = go.Figure()
    for col in component.columns:
        comp_fig.add_trace(go.Scatter(x=component.index,y=component[col],mode='lines',name=col,
                                      line=dict(width=2,dash='dash' if col=='Benchmark' else 'solid')))
    layout = base_layout(True); layout['yaxis'] = dict(showgrid=False,type='log',title='Indexiert (log)'); comp_fig.update_layout(**layout)
    st.markdown('#### Bestandteile'); st.plotly_chart(comp_fig,width='stretch',config={'displaylogo':False,'scrollZoom':True})

    corr_input = component.copy(); corr_input['Portfolio'] = portfolio.reindex(corr_input.index)
    c1,c2 = st.columns(2,gap='large')
    with c1:
        st.markdown('#### Korrelogramm'); st.plotly_chart(correlation_heatmap(corr_input),width='stretch',config={'displaylogo':False})
    with c2:
        st.markdown('#### Rollierende 1-Jahres-Korrelation')
        st.plotly_chart(rolling_benchmark_corr(corr_input),width='stretch',config={'displaylogo':False,'scrollZoom':True})

    stats = pd.DataFrame({'Portfolio':backtest_metrics(comparison['Portfolio']),
                          'Benchmark':backtest_metrics(comparison['Benchmark'])}).T
    st.markdown('#### Kennzahlen')
    st.dataframe(style_heat(stats, reverse_columns={'Volatilität p.a.'}),
                 width='stretch', height=compact_height(len(stats)))


def render_china_dashboard():
    nav, status_col = st.columns([.68,.32], vertical_alignment='center')
    with nav:
        page = st.radio('Bereich', ['Market ETFs vergleichen','Tech ETFs vergleichen'], horizontal=True,
                        index=0 if st.session_state.get('china_page','Market ETFs vergleichen')=='Market ETFs vergleichen' else 1,
                        key='china_page_radio', label_visibility='collapsed')
        st.session_state.china_page = page
    if page == 'Market ETFs vergleichen':
        selected, dialog = market_tree()
        status, progress = status_col.empty(), status_col.progress(0)
        cache = _cache('v9_index_data')
        done = sum(name in cache for name in selected)
        status_text(status, done, len(selected)); progress.progress(100 if not selected else round(done/len(selected)*100))
        for name in selected:
            if name not in cache:
                session_index(name); done += 1; status_text(status,done,len(selected)); progress.progress(round(done/len(selected)*100))
        resolved, warnings = [], []
        for name in selected:
            item, error = cache[name]
            if item is not None: resolved.append(item)
            if error: warnings.append(f"{name}: {error}")
        for warning in warnings: st.warning(warning)
        render_outputs(resolved,'market','market_focus')
        if dialog: etf_dialog(dialog)
    else:
        render_tech(status_col)


st.markdown(
    """
    <style>
    .block-container { padding-top:.65rem !important; }

    /* Page navigation: equal-width, plain text, active = bold + underline only. */
    .st-key-top_text_nav button,
    .st-key-china_text_nav button {
        background:transparent !important;
        border:none !important;
        border-radius:0 !important;
        box-shadow:none !important;
        color:#6b7280 !important;
        padding:.42rem .08rem .32rem .08rem !important;
        min-height:0 !important;
        justify-content:center !important;
    }
    .st-key-top_text_nav button p,
    .st-key-china_text_nav button p {
        white-space:normal !important;
        text-align:center !important;
        font-weight:400 !important;
        color:#6b7280 !important;
    }
    .st-key-top_text_nav button[kind="primary"],
    .st-key-china_text_nav button[kind="primary"],
    .st-key-top_text_nav button[data-testid="stBaseButton-primary"],
    .st-key-china_text_nav button[data-testid="stBaseButton-primary"] {
        border-bottom:2px solid #111827 !important;
    }
    .st-key-top_text_nav button[kind="primary"] p,
    .st-key-china_text_nav button[kind="primary"] p,
    .st-key-top_text_nav button[data-testid="stBaseButton-primary"] p,
    .st-key-china_text_nav button[data-testid="stBaseButton-primary"] p {
        font-weight:700 !important;
        color:#111827 !important;
    }

    /* Compact selection grid. */
    .selection-summary {
        font-size:.82rem;
        line-height:1.38;
        color:#374151;
        padding:.22rem .05rem .38rem .05rem;
    }
    .selection-summary b { color:#111827; }

    /* No selection checkboxes in dataframes. */
    [data-testid="stDataFrame"] input[type="checkbox"],
    [data-testid="stDataFrame"] [role="checkbox"] { display:none !important; }
    </style>
    """,
    unsafe_allow_html=True,
)


def _set_state(key, value):
    st.session_state[key] = value


def _toggle_selector(state_key, item):
    current = list(st.session_state.get(state_key, []))
    if item in current:
        current.remove(item)
    else:
        current.append(item)
    st.session_state[state_key] = current


def _selector_button(label, state_key, item, color, active, key_prefix):
    widget_key = f"{key_prefix}_{abs(hash(state_key + '|||' + str(item)))}"
    bg = hex_rgba(color, .11) if active else "#ffffff"
    text = color if active else "#374151"
    weight = 700 if active else 400
    border = color if active else hex_rgba(color, .62)
    st.markdown(
        f"""
        <style>
        .st-key-{widget_key} button {{
            width:100% !important;
            min-height:2.6rem !important;
            border:1.5px solid {border} !important;
            background:{bg} !important;
            color:{text} !important;
            font-weight:{weight} !important;
            justify-content:flex-start !important;
            text-align:left !important;
            border-radius:.52rem !important;
            box-shadow:none !important;
            padding:.42rem .58rem !important;
        }}
        .st-key-{widget_key} button p {{
            color:{text} !important;
            font-weight:{weight} !important;
            text-align:left !important;
            line-height:1.15 !important;
        }}
        .st-key-{widget_key} button:hover {{
            background:{hex_rgba(color, .15) if active else hex_rgba(color, .04)} !important;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.button(
        label,
        key=widget_key,
        type="secondary",
        use_container_width=True,
        on_click=_toggle_selector,
        args=(state_key, item),
    )


CONCISE_SPECIAL = {
    "MSCI China All Shares Stock Connect Select": "Breite China-Benchmark mit Onshore- und Offshore-Markt.",
    "S&P China 500": "Breite, sektorübergreifende China-Benchmark.",
    "FTSE China 30/18 Capped": "Breite China-Benchmark mit Konzentrationsbegrenzung.",
    "MSCI China": "Breite Standardbenchmark für chinesische Large- und Mid-Caps.",
    "MSCI China ex A Shares": "Offshore-China-Benchmark ohne Mainland-A-Aktien.",
    "Dow Jones China Offshore 50": "Large-Cap-Benchmark für chinesische Offshore-Unternehmen.",
    "FTSE China 50": "Hongkong-notierte China-Large-Cap-Benchmark.",
    "CSI Overseas China Internet": "Offshore-Benchmark für chinesische Internetunternehmen.",
    "MSCI China A": "Breite Mainland-China-Benchmark.",
    "CSI A 500": "Breite Mainland-China-Benchmark mit stärkerer Branchenabdeckung.",
    "MSCI China A Inclusion": "Benchmark für die schrittweise MSCI-Integration chinesischer A-Aktien.",
    "CSI 300": "Leitbenchmark für große und mittelgroße Mainland-China-Unternehmen.",
    "S&P China A 300": "Mainland-China-Benchmark für liquide Large- und Mid-Caps.",
    "SSE Science and Technology Innovation Board 50": "Technologie-/Innovationsfokus auf dem STAR Market.",
    "ChiNext 50 Capped": "Wachstums-/Innovationsfokus auf dem ChiNext-Markt.",
}


def _market_detail(name, key):
    info = INDEX_INFO[name]
    st.markdown(
        f"<div class='selection-summary'><b>{name}</b><br>"
        f"Segment: {info['segment']} · Gewichtung: {info['weight']} · Rebalancing: {info['rebalance']}<br>"
        f"Besonderheit: {CONCISE_SPECIAL.get(name, info['special'])}</div>",
        unsafe_allow_html=True,
    )
    c1, c2 = st.columns(2, gap="small")
    with c1:
        st.link_button("Methodology", info["url"], use_container_width=True)
    with c2:
        if st.button("ETF-Vergleich", key=f"etf_{key}_{name}", use_container_width=True):
            return name
    return None


def market_category(title, items, key):
    selected = ensure_selected(key, items)
    dialog = None
    with st.expander(title, expanded=False):
        for start in range(0, len(items), 3):
            cols = st.columns(3, gap="small")
            for col, name in zip(cols, items[start:start + 3]):
                with col:
                    _selector_button(name, key, name, INDEX_COLOR[name], name in selected, "market_sel")

        active_items = [name for name in items if name in selected]
        if active_items:
            st.divider()
            for name in active_items:
                d = _market_detail(name, key)
                dialog = dialog or d
    return list(ensure_selected(key, items)), dialog


def tech_category(title, rows, key, offset=0):
    items = rows["etf_name"].tolist()
    selected = ensure_selected(key, items)
    with st.expander(title, expanded=False):
        row_map = rows.set_index("etf_name")
        for start in range(0, len(items), 2):
            cols = st.columns(2, gap="small")
            for col, name in zip(cols, items[start:start + 2]):
                with col:
                    color = TECH_COLOR.get(name, "#6b7280")
                    _selector_button(name, key, name, color, name in selected, "tech_sel")

        active_items = [name for name in items if name in selected]
        if active_items:
            st.divider()
            for name in active_items:
                row = row_map.loc[name]
                proxy = MARKET_PROXY_BY_SIGNATURE.get(parse_share_classes(row["share_classes"]), "–")
                st.markdown(
                    f"<div class='selection-summary'><b>{name}</b><br>"
                    f"Index: {row['index_name']} · TER: {row['ter']:.2f}%<br>"
                    f"Market Proxy: {proxy}</div>",
                    unsafe_allow_html=True,
                )
                st.link_button("ETF / Methodology", row["source_url"], use_container_width=True)
    return list(ensure_selected(key, items))


def style_heat(df, focus=None, reverse_columns=None):
    reverse_columns = set(reverse_columns or [])
    pct = {"CAGR p.a.", "Volatilität p.a.", "Max. Drawdown", "Tracking Error p.a."}
    ratios = {"Sharpe Ratio", "Sortino", "Calmar", "Information Ratio p.a."}
    fmts = {c: (lambda x: "–" if pd.isna(x) else f"{x:.2%}") for c in df.columns if c in pct}
    fmts.update({c: (lambda x: "–" if pd.isna(x) else f"{x:.2f}")
                 for c in df.columns if c in ratios or str(c).isdigit()})
    sty = df.style.format(fmts, na_rep="–").set_properties(**{"color":"#111827", "background-color":"#fff"})
    for col in df.select_dtypes(include="number").columns:
        vals = pd.to_numeric(df[col], errors="coerce").dropna()
        if vals.empty:
            continue
        lo, hi = float(vals.min()), float(vals.max())
        rev = col in reverse_columns
        sty = sty.map(lambda v, lo=lo, hi=hi, rev=rev: _cell_color(v, lo, hi, rev), subset=[col])
    if focus is not None and focus in df.index:
        row_style = "font-weight:800;border-top:2px solid #111827;border-bottom:2px solid #111827"
        sty = sty.apply(lambda row: [row_style if row.name == focus else "" for _ in row], axis=1)
        sty = sty.apply_index(lambda values: [row_style if value == focus else "" for value in values], axis=0)
    return sty


def handle_table_focus(event, df, focus_key):
    try:
        cells = event.selection.cells
    except Exception:
        return
    if not cells:
        return
    cell = cells[0]
    if isinstance(cell, dict):
        row_idx = cell.get("row")
    elif isinstance(cell, (list, tuple)) and cell:
        row_idx = cell[0]
    else:
        return
    if row_idx is None:
        return
    idx = int(row_idx)
    if 0 <= idx < len(df):
        toggle_focus(df.index[idx], focus_key)
        st.rerun()


def render_outputs(resolved, key_prefix, focus_key, benchmark_map=None, benchmark_series=None):
    if not resolved:
        return
    series = {x.label:x.series_eur for x in resolved}
    display = {x.label:(x.index_name if key_prefix == "market" else x.etf_name) for x in resolved}
    colors = {}
    for i, item in enumerate(resolved):
        if key_prefix == "market":
            colors[item.label] = INDEX_COLOR.get(item.index_name, PALETTE[i % len(PALETTE)])
        elif key_prefix == "tech":
            colors[item.label] = TECH_COLOR.get(item.etf_name, PALETTE[i % len(PALETTE)])
        else:
            colors[item.label] = PALETTE[i % len(PALETTE)]
    if benchmark_map and benchmark_series:
        for _, bcol in benchmark_map.items():
            if bcol in benchmark_series:
                series[bcol] = benchmark_series[bcol]
    frame = common_frame(series)
    if frame.empty:
        return
    focus = st.session_state.get(focus_key)
    focus_col = next((c for c,n in display.items() if n == focus), None)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        key = f"{key_prefix}_perf"
        event = st.plotly_chart(line_fig(frame, colors, focus_col, False, benchmark_map), width="stretch",
                                config={"displaylogo":False,"scrollZoom":True}, key=key,
                                on_select="rerun", selection_mode="points")
        handle_plot_focus(event, display, focus_key, key)
    with c2:
        st.markdown("#### Drawdown")
        key = f"{key_prefix}_dd"
        event = st.plotly_chart(line_fig(frame, colors, focus_col, True, benchmark_map), width="stretch",
                                config={"displaylogo":False,"scrollZoom":True}, key=key,
                                on_select="rerun", selection_mode="points")
        handle_plot_focus(event, display, focus_key, key)

    corr_cols = [c for c in frame.columns if not c.startswith("__BENCH__")]
    corr_frame = frame[corr_cols]
    pair_key = f"{key_prefix}_corr_pair"
    pair = st.session_state.get(pair_key)
    if not pair or any(x not in corr_frame.columns for x in pair) or pair[0] == pair[1]:
        pair = (corr_cols[0], corr_cols[1]) if len(corr_cols) >= 2 else None
    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        event = st.plotly_chart(correlation_fig(corr_frame, display, focus_col), width="stretch",
                                config={"displaylogo":False}, key=f"{key_prefix}_corr",
                                on_select="rerun", selection_mode="points")
        try:
            pts = event.selection.points
            if pts:
                custom = pts[0].get("customdata")
                if custom and "|||" in custom:
                    p = tuple(custom.split("|||", 1))
                    if p[0] != p[1]:
                        st.session_state[pair_key] = p
        except Exception:
            pass
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation")
        pair = st.session_state.get(pair_key) or pair
        if pair:
            st.plotly_chart(rolling_corr_fig(corr_frame, pair[0], pair[1], display), width="stretch",
                            config={"displaylogo":False,"scrollZoom":True}, key=f"{key_prefix}_roll")

    annual = yearly_sharpe_matrix(corr_frame, display)
    bench_stats = {}
    if benchmark_map:
        bench_stats = {lab:frame[bcol] for lab,bcol in benchmark_map.items()
                       if lab in corr_frame.columns and bcol in frame.columns}
    total = total_stats(corr_frame, display, bench_stats if benchmark_map else None)
    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Jahresperformance (Sharpe Ratio)")
        event = st.dataframe(style_heat(annual, focus), width="stretch", height=compact_height(len(annual)),
                             on_select="rerun", selection_mode="single-cell",
                             key=f"{key_prefix}_annual_{abs(hash(focus or 'none'))}")
        handle_table_focus(event, annual, focus_key)
    with c2:
        st.markdown("#### Gesamtperformance")
        event = st.dataframe(style_heat(total, focus), width="stretch", height=compact_height(len(total)),
                             on_select="rerun", selection_mode="single-cell",
                             key=f"{key_prefix}_total_{abs(hash(focus or 'none'))}")
        handle_table_focus(event, total, focus_key)


@st.dialog("ETFs des Index", width="large")
def etf_dialog(index_name):
    sub = registry[registry["index_name"] == index_name].sort_values("inception").copy()
    if sub.empty:
        return
    st.markdown(f"### {index_name}")
    table = sub.copy()
    table["Auflage"] = table["inception"].map(fmt_date)
    table["Mitglieder"] = INDEX_INFO[index_name]["members"]
    table["JustETF"] = table["isin"].map(lambda x: f"https://www.justetf.com/de/etf-profile.html?isin={x}")
    show = table[["etf_name","isin","Auflage","Mitglieder","ter","distribution","JustETF"]].rename(
        columns={"etf_name":"ETF","isin":"ISIN","ter":"TER","distribution":"Ertragsverwendung"})
    st.dataframe(show.style.set_properties(**{"color":"#111827","background-color":"#fff"}).format({"TER":"{:.2f}%"}),
                 width="stretch", height=compact_height(len(show)), hide_index=True,
                 column_config={"JustETF":st.column_config.LinkColumn("Link",display_text="Öffnen")})

    cache = _cache("v9_etf_data")
    names = sub["etf_name"].tolist()
    resolved, warnings = [], []
    for name in names:
        if (index_name, name) not in cache:
            session_etf(index_name, name)
        rows, row_warnings = cache[(index_name, name)]
        resolved += rows
        warnings += row_warnings
    for warning in warnings:
        st.warning(warning)
    if resolved:
        render_outputs(resolved, f"dlg_{abs(hash(index_name))}", f"dlg_focus_{abs(hash(index_name))}")


def render_tech(_status_host=None):
    tech = tech_registry_cached().copy()
    selected = []
    all_rows = tech[tech["universe"] == "All Shares"]
    on_rows = tech[tech["universe"] == "Onshore"]
    off_rows = tech[tech["universe"] == "Offshore"]
    if not all_rows.empty:
        selected += tech_category("All Shares", all_rows, "t_all", 0)
    left, right = st.columns(2, gap="large")
    with left:
        if not on_rows.empty:
            selected += tech_category("Onshore", on_rows, "t_on", len(all_rows))
    with right:
        if not off_rows.empty:
            selected += tech_category("Offshore", off_rows, "t_off", len(all_rows) + len(on_rows))
    if not selected:
        return

    cache = _cache("v9_tech_data")
    for name in selected:
        if name not in cache:
            session_tech(name)
    resolved, warnings = [], []
    for name in selected:
        items, item_warnings = cache[name]
        resolved += items
        warnings += item_warnings
    for warning in warnings:
        st.warning(warning)
    if not resolved:
        return

    meta = tech.set_index("etf_name")
    benchmark_map, benchmark_series = {}, {}
    for item in resolved:
        if item.etf_name not in meta.index:
            continue
        proxy = MARKET_PROXY_BY_SIGNATURE.get(parse_share_classes(meta.loc[item.etf_name, "share_classes"]))
        if not proxy:
            continue
        benchmark, error = session_index(proxy)
        if benchmark is None:
            continue
        bcol = f"__BENCH__{item.label}"
        benchmark_map[item.label] = bcol
        benchmark_series[bcol] = benchmark.series_eur
    render_outputs(resolved, "tech", "tech_focus", benchmark_map, benchmark_series)


def _text_nav(options, state_key, default, container_key):
    current = st.session_state.get(state_key, default)
    if current not in options:
        current = default
        st.session_state[state_key] = current
    with st.container(key=container_key):
        cols = st.columns([1] * len(options), gap="small")
        for col, option in zip(cols, options):
            with col:
                st.button(option, key=f"{container_key}_{abs(hash(option))}",
                          type="primary" if current == option else "secondary",
                          use_container_width=True, on_click=_set_state, args=(state_key, option))
    return st.session_state.get(state_key, current)


def render_china_dashboard():
    page = _text_nav(
        ["Market ETFs vergleichen", "Tech ETFs vergleichen"],
        "china_page", "Market ETFs vergleichen", "china_text_nav"
    )
    if page == "Market ETFs vergleichen":
        selected, dialog = market_tree()
        cache = _cache("v9_index_data")
        for name in selected:
            if name not in cache:
                session_index(name)
        resolved, warnings = [], []
        for name in selected:
            item, error = cache[name]
            if item is not None:
                resolved.append(item)
            if error:
                warnings.append(f"{name}: {error}")
        for warning in warnings:
            st.warning(warning)
        render_outputs(resolved, "market", "market_focus")
        if dialog:
            etf_dialog(dialog)
    else:
        render_tech()


_original_render_asset_allocation_tool = render_asset_allocation_tool
_AA_LAST_WEIGHT_HISTORY = None
_AA_LAST_PORTFOLIO = None

def backtest_portfolio(prices, weights, frequency):
    global _AA_LAST_WEIGHT_HISTORY, _AA_LAST_PORTFOLIO
    returns = prices.pct_change(fill_method=None).fillna(0.0)
    target = np.asarray(weights, dtype=float)
    target = target / target.sum()
    values = target.copy()
    portfolio_values = []
    weight_rows = []
    last_key = None
    for date, row in returns.iterrows():
        key = rebalance_key(pd.Timestamp(date), frequency)
        if frequency != "Kein Rebalancing" and key != last_key and portfolio_values:
            total_before = float(values.sum())
            values = total_before * target
        values = values * (1.0 + row.to_numpy(dtype=float))
        total = float(values.sum())
        portfolio_values.append(total)
        weight_rows.append(values / total if total != 0 else target.copy())
        last_key = key
    portfolio = pd.Series(portfolio_values, index=returns.index, name="Portfolio", dtype=float) * 100.0
    weight_history = pd.DataFrame(weight_rows, index=returns.index, columns=prices.columns, dtype=float)
    _AA_LAST_WEIGHT_HISTORY = weight_history
    _AA_LAST_PORTFOLIO = portfolio
    return portfolio

def annual_information_ratio(portfolio, benchmark):
    aligned = pd.concat([portfolio.rename("Portfolio"), benchmark.rename("Benchmark")], axis=1).dropna()
    returns = aligned.pct_change(fill_method=None).dropna()
    if returns.empty:
        return pd.Series(dtype=float)
    active = returns["Portfolio"] - returns["Benchmark"]
    values = {}
    for year, series in active.groupby(active.index.year):
        series = series.dropna()
        if len(series) < 20:
            values[int(year)] = np.nan
            continue
        tracking_error = float(series.std(ddof=1))
        if tracking_error == 0 or np.isnan(tracking_error):
            values[int(year)] = np.nan
        else:
            values[int(year)] = float(series.mean()) / tracking_error * np.sqrt(252)
    return pd.Series(values, name="Information Ratio", dtype=float)

def weight_history_figure(weight_history, assets):
    name_map = {asset["symbol"]: f"{asset['name']} ({asset['symbol']})" for asset in assets}
    frame = weight_history.rename(columns=name_map) * 100.0
    fig = go.Figure()
    for col in frame.columns:
        fig.add_trace(go.Scatter(
            x=frame.index, y=frame[col], mode="lines", name=col,
            stackgroup="portfolio_weights", line=dict(width=0.8),
            hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.2f} %</b><extra>%{fullData.name}</extra>",
        ))
    layout = base_layout(True)
    layout["height"] = 500
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(showgrid=False, zeroline=False, range=[0, 100], title="Gewicht in %", ticksuffix=" %")
    fig.update_layout(**layout)
    return fig

def annual_ir_figure(information_ratio):
    clean = information_ratio.dropna()
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=[str(int(year)) for year in clean.index], y=clean.values,
        name="Information Ratio",
        hovertemplate="<b>%{x}</b><br>Information Ratio: %{y:.2f}<extra></extra>",
    ))
    layout = base_layout(False)
    layout["height"] = 430
    layout["hovermode"] = "closest"
    layout["xaxis"] = dict(showgrid=False, zeroline=False, title="Jahr")
    layout["yaxis"] = dict(showgrid=False, zeroline=True, zerolinewidth=1, title="Information Ratio")
    fig.update_layout(**layout)
    return fig

def render_asset_allocation_tool():
    global _AA_LAST_WEIGHT_HISTORY, _AA_LAST_PORTFOLIO
    _AA_LAST_WEIGHT_HISTORY = None
    _AA_LAST_PORTFOLIO = None
    _original_render_asset_allocation_tool()
    if not st.session_state.get("aa_run"):
        return
    assets = _aa_assets()
    benchmark = st.session_state.get("aa_benchmark")
    if not assets or not benchmark:
        return
    if _AA_LAST_WEIGHT_HISTORY is None or _AA_LAST_PORTFOLIO is None:
        return
    st.markdown("#### Gewichtsentwicklung")
    st.plotly_chart(
        weight_history_figure(_AA_LAST_WEIGHT_HISTORY, assets),
        width="stretch",
        config={"displaylogo": False, "scrollZoom": True},
        key="aa_weight_history",
    )
    try:
        benchmark_series, _ = asset_series_eur(benchmark["symbol"])
    except Exception:
        return
    benchmark_aligned = benchmark_series.reindex(_AA_LAST_PORTFOLIO.index).dropna()
    common = _AA_LAST_PORTFOLIO.index.intersection(benchmark_aligned.index)
    if len(common) < 20:
        return
    portfolio_aligned = _AA_LAST_PORTFOLIO.loc[common]
    benchmark_indexed = benchmark_aligned.loc[common] / benchmark_aligned.loc[common].iloc[0] * 100.0
    annual_ir = annual_information_ratio(portfolio_aligned, benchmark_indexed)
    if annual_ir.dropna().empty:
        return
    st.markdown("#### Jährliche Information Ratio")
    st.plotly_chart(
        annual_ir_figure(annual_ir),
        width="stretch",
        config={"displaylogo": False},
        key="aa_annual_information_ratio",
    )


SECTOR_ETFS = [
    {"sector": "Communication Services", "ticker": "XLC", "inception": "18.06.2018"},
    {"sector": "Consumer Discretionary", "ticker": "XLY", "inception": "16.12.1998"},
    {"sector": "Consumer Staples", "ticker": "XLP", "inception": "16.12.1998"},
    {"sector": "Energy", "ticker": "XLE", "inception": "16.12.1998"},
    {"sector": "Financials", "ticker": "XLF", "inception": "16.12.1998"},
    {"sector": "Health Care", "ticker": "XLV", "inception": "16.12.1998"},
    {"sector": "Industrials", "ticker": "XLI", "inception": "16.12.1998"},
    {"sector": "Information Technology", "ticker": "XLK", "inception": "16.12.1998"},
    {"sector": "Materials", "ticker": "XLB", "inception": "16.12.1998"},
    {"sector": "Real Estate", "ticker": "XLRE", "inception": "07.10.2015"},
    {"sector": "Utilities", "ticker": "XLU", "inception": "16.12.1998"},
]
SECTOR_BENCHMARK = {"sector": "S&P 500", "ticker": "SPY", "inception": "22.01.1993"}
SECTOR_LABELS = {x["ticker"]: f"{x['sector']} ({x['ticker']})" for x in SECTOR_ETFS}
SECTOR_LABELS["SPY"] = "S&P 500 (SPY)"


@st.cache_data(ttl=6 * 60 * 60, show_spinner=False)
def sector_prices_usd():
    tickers = [x["ticker"] for x in SECTOR_ETFS] + [SECTOR_BENCHMARK["ticker"]]
    raw = yf.download(
        tickers=tickers,
        start="1990-01-01",
        auto_adjust=False,
        actions=False,
        progress=False,
        threads=True,
        timeout=30,
    )
    if raw is None or raw.empty:
        return {}
    if isinstance(raw.columns, pd.MultiIndex):
        first = raw.columns.get_level_values(0)
        if "Adj Close" in first:
            prices = raw["Adj Close"]
        elif "Close" in first:
            prices = raw["Close"]
        else:
            return {}
    else:
        col = "Adj Close" if "Adj Close" in raw.columns else "Close" if "Close" in raw.columns else None
        if col is None:
            return {}
        prices = raw[[col]].rename(columns={col: tickers[0]})
    if isinstance(prices, pd.Series):
        prices = prices.to_frame()
    if isinstance(prices.index, pd.DatetimeIndex):
        if prices.index.tz is not None:
            prices.index = prices.index.tz_localize(None)
        prices.index = prices.index.normalize()
    result = {}
    for ticker in tickers:
        if ticker not in prices.columns:
            continue
        s = pd.to_numeric(prices[ticker], errors="coerce").dropna()
        s = s[~s.index.duplicated(keep="last")].sort_index()
        if len(s) >= 30:
            result[ticker] = s.rename(SECTOR_LABELS[ticker])
    return result


def _indexed_individually(series_map):
    pieces = []
    for label, series in series_map.items():
        s = series.dropna()
        if s.empty:
            continue
        pieces.append((s / s.iloc[0] * 100.0).rename(label))
    return pd.concat(pieces, axis=1).sort_index() if pieces else pd.DataFrame()


def _sector_performance_figure(frame):
    fig = go.Figure()
    for col in frame.columns:
        is_benchmark = col == "S&P 500 (SPY)"
        fig.add_trace(go.Scatter(
            x=frame.index,
            y=frame[col],
            mode="lines",
            name=col,
            line=dict(width=2.5 if is_benchmark else 1.8, dash="dash" if is_benchmark else "solid"),
            hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra>%{fullData.name}</extra>",
        ))
    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(showgrid=False, zeroline=False, type="log", title="Indexiert (log)")
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.16, x=0)
    fig.update_layout(**layout)
    return fig


def _sector_drawdown_figure(series_map):
    fig = go.Figure()
    for label, series in series_map.items():
        s = series.dropna()
        dd = (s / s.cummax() - 1.0) * 100.0
        is_benchmark = label == "S&P 500 (SPY)"
        fig.add_trace(go.Scatter(
            x=dd.index,
            y=dd,
            mode="lines",
            name=label,
            line=dict(width=2.5 if is_benchmark else 1.8, dash="dash" if is_benchmark else "solid"),
            hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.2f} %</b><extra>%{fullData.name}</extra>",
        ))
    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(showgrid=False, zeroline=True, title="Drawdown in %")
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.16, x=0)
    fig.update_layout(**layout)
    return fig


def _sector_correlation_figure(series_map):
    returns = pd.DataFrame({k: v.pct_change(fill_method=None) for k, v in series_map.items()})
    corr = returns.corr(min_periods=126)
    fig = go.Figure(go.Heatmap(
        z=corr.values,
        x=corr.columns,
        y=corr.index,
        zmin=-1,
        zmax=1,
        zmid=0,
        colorscale="RdYlGn",
        text=np.round(corr.values, 2),
        texttemplate="%{text:.2f}",
        hovertemplate="%{y} ↔ %{x}<br><b>%{z:.3f}</b><extra></extra>",
    ))
    fig.update_layout(
        height=540,
        margin=dict(l=25, r=15, t=15, b=30),
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(color="#111827"),
    )
    return fig


def _sector_rolling_corr_figure(series_map):
    benchmark = series_map.get("S&P 500 (SPY)")
    fig = go.Figure()
    if benchmark is None:
        return fig
    benchmark_returns = benchmark.pct_change(fill_method=None)
    for label, series in series_map.items():
        if label == "S&P 500 (SPY)":
            continue
        aligned = pd.concat([
            series.pct_change(fill_method=None).rename("sector"),
            benchmark_returns.rename("benchmark"),
        ], axis=1).dropna()
        if aligned.empty:
            continue
        rolling = aligned["sector"].rolling(252, min_periods=126).corr(aligned["benchmark"])
        fig.add_trace(go.Scatter(
            x=rolling.index,
            y=rolling,
            mode="lines",
            name=label,
            line=dict(width=1.8),
            hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra>%{fullData.name}</extra>",
        ))
    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(showgrid=False, zeroline=True, range=[-1, 1], title="Korrelation")
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.16, x=0)
    fig.update_layout(**layout)
    return fig


def _sector_metrics(series_map):
    rows = {}
    for label, series in series_map.items():
        metrics = backtest_metrics(series)
        if metrics:
            rows[label] = metrics
    return pd.DataFrame.from_dict(rows, orient="index")


def _sector_annual_sharpe(series_map):
    years = sorted({int(year) for s in series_map.values() for year in s.dropna().index.year})
    rows = {}
    for label, series in series_map.items():
        row = {}
        s = series.dropna()
        for year in years:
            sy = s[s.index.year == year]
            row[str(year)] = sharpe0(sy) if len(sy) >= 20 else np.nan
        rows[label] = row
    return pd.DataFrame.from_dict(rows, orient="index")


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    series_map = {}
    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        label = SECTOR_LABELS[ticker]
        series_map[label] = raw[ticker]
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": f"{raw[ticker].index.min():%d.%m.%Y} – {raw[ticker].index.max():%d.%m.%Y}",
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        overview,
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    indexed = _indexed_individually(series_map)
    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung (jeweils ab Start = 100)")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr",
        )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


EXCLUDED_SECTOR_TICKERS = {"XLC", "XLRE"}


def _sector_overview_style(df):
    def style_row(row):
        excluded = row.get("ETF") in EXCLUDED_SECTOR_TICKERS
        style = "text-decoration:line-through;color:#9ca3af;" if excluded else ""
        return [style] * len(row)

    return df.style.apply(style_row, axis=1)


def _common_active_sector_series(raw):
    active_items = [
        item for item in SECTOR_ETFS
        if item["ticker"] not in EXCLUDED_SECTOR_TICKERS
    ] + [SECTOR_BENCHMARK]

    series = {}
    for item in active_items:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        series[SECTOR_LABELS[ticker]] = raw[ticker]

    expected = len(active_items)
    if len(series) != expected:
        return {}

    frame = pd.concat(series, axis=1).dropna()
    if frame.empty:
        return {}

    return {col: frame[col] for col in frame.columns}


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _common_active_sector_series(raw)
    if not series_map:
        st.error("Kein gemeinsamer Datenzeitraum für alle Sektor-ETFs verfügbar.")
        return

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v14",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v14",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v14",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v14",
        )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


SECTOR_BENCHMARK_LABEL = "S&P 500 (SPY)"


def _sector_rolling_return_diff(series_map):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None:
        return pd.DataFrame()

    benchmark_1y = benchmark / benchmark.shift(252) - 1.0
    data = {}
    for label, series in series_map.items():
        if label == SECTOR_BENCHMARK_LABEL:
            continue
        sector_1y = series / series.shift(252) - 1.0
        data[label] = (sector_1y - benchmark_1y) * 100.0
    return pd.DataFrame(data).dropna(how="all")


def _sector_rolling_return_diff_figure(diff_frame):
    fig = go.Figure()
    for col in diff_frame.columns:
        s = diff_frame[col].dropna()
        fig.add_trace(go.Scatter(
            x=s.index,
            y=s,
            mode="lines",
            name=col,
            line=dict(width=1.8),
            hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.2f} %-Pkt.</b><extra>%{fullData.name}</extra>",
        ))
    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=True,
        zerolinewidth=1,
        title="Renditedifferenz in %-Pkt.",
    )
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.16, x=0)
    fig.update_layout(**layout)
    return fig


def _forward_max_return(series, window=252):
    s = series.dropna()
    future_max = (
        s.iloc[::-1]
        .rolling(window=window, min_periods=window)
        .max()
        .iloc[::-1]
        .shift(-1)
    )
    return (future_max / s - 1.0) * 100.0


def _sector_forward_max_scatter_data(series_map):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None:
        return {}

    benchmark_1y = benchmark / benchmark.shift(252) - 1.0
    result = {}

    for label, series in series_map.items():
        if label == SECTOR_BENCHMARK_LABEL:
            continue

        sector_1y = series / series.shift(252) - 1.0
        trailing_diff = (sector_1y - benchmark_1y) * 100.0
        forward_max = _forward_max_return(series, 252)

        frame = pd.concat(
            [
                trailing_diff.rename("Renditedifferenz"),
                forward_max.rename("Max Folgejahresrendite"),
            ],
            axis=1,
        ).dropna()

        if frame.empty:
            continue

        frame = frame.groupby(frame.index.to_period("M")).tail(1)
        result[label] = frame

    return result


def _sector_forward_max_scatter_figure(scatter_data):
    fig = go.Figure()
    for label, frame in scatter_data.items():
        fig.add_trace(go.Scattergl(
            x=frame["Renditedifferenz"],
            y=frame["Max Folgejahresrendite"],
            mode="markers",
            name=label,
            customdata=np.array([frame.index.strftime("%d.%m.%Y")]).T,
            marker=dict(size=7, opacity=0.58),
            hovertemplate=(
                "%{customdata[0]}<br>"
                "1Y-Differenz: <b>%{x:.2f} %-Pkt.</b><br>"
                "Max. Folgejahresrendite: <b>%{y:.2f} %</b>"
                "<extra>%{fullData.name}</extra>"
            ),
        ))
    layout = base_layout(True)
    layout["height"] = 580
    layout["hovermode"] = "closest"
    layout["xaxis"] = dict(
        showgrid=False,
        zeroline=True,
        zerolinewidth=1,
        title="1Y-Renditedifferenz zum S&P 500 in %-Pkt.",
    )
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=True,
        zerolinewidth=1,
        title="Max. Rendite innerhalb der folgenden 12 Monate in %",
    )
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.18, x=0)
    fig.update_layout(**layout)
    return fig


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _common_active_sector_series(raw)
    if not series_map:
        st.error("Kein gemeinsamer Datenzeitraum für alle Sektor-ETFs verfügbar.")
        return

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v15",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v15",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v15",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v15",
        )

    rolling_diff = _sector_rolling_return_diff(series_map)
    if not rolling_diff.empty:
        st.markdown("#### Rollierende 1-Jahres-Renditedifferenz zum S&P 500")
        st.plotly_chart(
            _sector_rolling_return_diff_figure(rolling_diff),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_return_diff_v15",
        )

    scatter_data = _sector_forward_max_scatter_data(series_map)
    if scatter_data:
        st.markdown("#### Renditedifferenz vs. maximale Folgejahresperformance")
        st.plotly_chart(
            _sector_forward_max_scatter_figure(scatter_data),
            width="stretch",
            config={"displaylogo": False},
            key="sector_forward_max_scatter_v15",
        )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


def _sector_extreme_percentiles(diff_frame, warmup_years=10):
    frame = diff_frame.dropna(how="any").sort_index()
    if frame.empty:
        return pd.DataFrame()

    first_date = pd.Timestamp(frame.index.min())
    evaluation_start = first_date + pd.DateOffset(years=warmup_years)

    all_values = frame.to_numpy(dtype=float).ravel()
    all_values = all_values[np.isfinite(all_values)]
    if all_values.size == 0:
        return pd.DataFrame()
    coordinates = np.unique(all_values)

    tree = np.zeros(len(coordinates) + 1, dtype=np.int64)

    def add(value):
        idx = int(np.searchsorted(coordinates, value, side="left")) + 1
        while idx < len(tree):
            tree[idx] += 1
            idx += idx & -idx

    def prefix_count(value, inclusive=True):
        side = "right" if inclusive else "left"
        idx = int(np.searchsorted(coordinates, value, side=side))
        total = 0
        while idx > 0:
            total += int(tree[idx])
            idx -= idx & -idx
        return total

    history_count = 0
    rows = []

    for date, row in frame.iterrows():
        date = pd.Timestamp(date)
        current_values = pd.to_numeric(row, errors="coerce").dropna()

        if date >= evaluation_start and history_count and not current_values.empty:
            out_label = current_values.idxmax()
            out_value = float(current_values.loc[out_label])
            out_le = prefix_count(out_value, inclusive=True)
            out_lt = prefix_count(out_value, inclusive=False)
            out_percentile = 100.0 * out_le / history_count
            out_tail = 100.0 * (history_count - out_lt) / history_count

            under_label = current_values.idxmin()
            under_value = float(current_values.loc[under_label])
            under_le = prefix_count(under_value, inclusive=True)
            under_percentile = 100.0 * under_le / history_count
            under_tail = under_percentile

            rows.append({
                "Datum": date,
                "Outperformance Sektor": out_label,
                "Outperformance Differenz": out_value,
                "Outperformance Perzentil": out_percentile,
                "Outperformance Extremität": out_percentile,
                "Outperformance Tail": out_tail,
                "Underperformance Sektor": under_label,
                "Underperformance Differenz": under_value,
                "Underperformance Perzentil": under_percentile,
                "Underperformance Extremität": 100.0 - under_percentile,
                "Underperformance Tail": under_tail,
                "Historische Beobachtungen": history_count,
            })

        for value in current_values.to_numpy(dtype=float):
            if np.isfinite(value):
                add(float(value))
                history_count += 1

    if not rows:
        return pd.DataFrame()

    return pd.DataFrame(rows).set_index("Datum")


def _sector_extreme_percentile_figure(percentiles):
    fig = go.Figure()

    out_custom = np.column_stack([
        percentiles["Outperformance Sektor"].astype(str),
        percentiles["Outperformance Differenz"].to_numpy(dtype=float),
        percentiles["Outperformance Perzentil"].to_numpy(dtype=float),
        percentiles["Outperformance Tail"].to_numpy(dtype=float),
        percentiles["Historische Beobachtungen"].to_numpy(dtype=int),
    ])
    fig.add_trace(go.Scatter(
        x=percentiles.index,
        y=percentiles["Outperformance Extremität"],
        mode="lines",
        name="Stärkste Outperformance",
        customdata=out_custom,
        line=dict(width=1.9),
        hovertemplate=(
            "%{x|%d.%m.%Y}<br>"
            "<b>%{customdata[0]}</b><br>"
            "1Y-Differenz: %{customdata[1]:.2f} %-Pkt.<br>"
            "Historisches Perzentil: %{customdata[2]:.2f} %<br>"
            "Tail-Wahrscheinlichkeit ≥ aktuell: %{customdata[3]:.2f} %<br>"
            "Historische Beobachtungen: %{customdata[4]:,.0f}"
            "<extra></extra>"
        ),
    ))

    under_custom = np.column_stack([
        percentiles["Underperformance Sektor"].astype(str),
        percentiles["Underperformance Differenz"].to_numpy(dtype=float),
        percentiles["Underperformance Perzentil"].to_numpy(dtype=float),
        percentiles["Underperformance Tail"].to_numpy(dtype=float),
        percentiles["Historische Beobachtungen"].to_numpy(dtype=int),
    ])
    fig.add_trace(go.Scatter(
        x=percentiles.index,
        y=percentiles["Underperformance Extremität"],
        mode="lines",
        name="Stärkste Underperformance",
        customdata=under_custom,
        line=dict(width=1.9),
        hovertemplate=(
            "%{x|%d.%m.%Y}<br>"
            "<b>%{customdata[0]}</b><br>"
            "1Y-Differenz: %{customdata[1]:.2f} %-Pkt.<br>"
            "Historisches Perzentil: %{customdata[2]:.2f} %<br>"
            "Tail-Wahrscheinlichkeit ≤ aktuell: %{customdata[3]:.2f} %<br>"
            "Historische Beobachtungen: %{customdata[4]:,.0f}"
            "<extra></extra>"
        ),
    ))

    layout = base_layout(True)
    layout["height"] = 560
    layout["hovermode"] = "x unified"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        range=[0, 100],
        title="Extremitätsperzentil",
        ticksuffix=" %",
    )
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.15, x=0)
    fig.update_layout(**layout)
    return fig


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _common_active_sector_series(raw)
    if not series_map:
        st.error("Kein gemeinsamer Datenzeitraum für alle Sektor-ETFs verfügbar.")
        return

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v16",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v16",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v16",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v16",
        )

    rolling_diff = _sector_rolling_return_diff(series_map)
    if not rolling_diff.empty:
        st.markdown("#### Rollierende 1-Jahres-Renditedifferenz zum S&P 500")
        st.plotly_chart(
            _sector_rolling_return_diff_figure(rolling_diff),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_return_diff_v16",
        )

        extreme_percentiles = _sector_extreme_percentiles(rolling_diff, warmup_years=10)
        if not extreme_percentiles.empty:
            st.markdown("#### Historische Extremität der stärksten Out- und Underperformance")
            st.plotly_chart(
                _sector_extreme_percentile_figure(extreme_percentiles),
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key="sector_extreme_percentiles_v16",
            )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


def _sector_top2_extreme_probabilities(diff_frame, warmup_years=10):
    frame = diff_frame.dropna(how="any").sort_index()
    if frame.empty:
        return pd.DataFrame()

    first_date = pd.Timestamp(frame.index.min())
    evaluation_start = first_date + pd.DateOffset(years=warmup_years)

    all_values = frame.to_numpy(dtype=float).ravel()
    all_values = all_values[np.isfinite(all_values)]
    if all_values.size == 0:
        return pd.DataFrame()

    coordinates = np.unique(all_values)
    tree = np.zeros(len(coordinates) + 1, dtype=np.int64)

    def add(value):
        idx = int(np.searchsorted(coordinates, value, side="left")) + 1
        while idx < len(tree):
            tree[idx] += 1
            idx += idx & -idx

    def prefix_count(value, inclusive=True):
        side = "right" if inclusive else "left"
        idx = int(np.searchsorted(coordinates, value, side=side))
        total = 0
        while idx > 0:
            total += int(tree[idx])
            idx -= idx & -idx
        return total

    history_count = 0
    rows = []

    for date, row in frame.iterrows():
        date = pd.Timestamp(date)
        current = pd.to_numeric(row, errors="coerce").dropna()

        if date >= evaluation_start and history_count > 0 and len(current) >= 4:
            descending = current.sort_values(ascending=False)
            ascending = current.sort_values(ascending=True)

            record = {
                "Datum": date,
                "Historische Beobachtungen": history_count,
            }

            for rank, (label, value) in enumerate(descending.iloc[:2].items(), start=1):
                value = float(value)
                le = prefix_count(value, inclusive=True)
                lt = prefix_count(value, inclusive=False)
                percentile = 100.0 * le / history_count
                upper_tail = 100.0 * (history_count - lt) / history_count
                record[f"Out {rank} Sektor"] = label
                record[f"Out {rank} Differenz"] = value
                record[f"Out {rank} Perzentil"] = percentile
                record[f"Out {rank} Tail"] = upper_tail
                record[f"Out {rank} Extremität"] = 100.0 - upper_tail

            for rank, (label, value) in enumerate(ascending.iloc[:2].items(), start=1):
                value = float(value)
                le = prefix_count(value, inclusive=True)
                percentile = 100.0 * le / history_count
                lower_tail = percentile
                record[f"Under {rank} Sektor"] = label
                record[f"Under {rank} Differenz"] = value
                record[f"Under {rank} Perzentil"] = percentile
                record[f"Under {rank} Tail"] = lower_tail
                record[f"Under {rank} Extremität"] = 100.0 - lower_tail

            rows.append(record)

        for value in current.to_numpy(dtype=float):
            if np.isfinite(value):
                add(float(value))
                history_count += 1

    if not rows:
        return pd.DataFrame()

    return pd.DataFrame(rows).set_index("Datum")


def _sector_top2_probability_figure(probabilities):
    fig = go.Figure()
    specs = [
        ("Out 1", "Outperformance #1"),
        ("Out 2", "Outperformance #2"),
        ("Under 1", "Underperformance #1"),
        ("Under 2", "Underperformance #2"),
    ]

    for prefix, label in specs:
        custom = np.column_stack([
            probabilities[f"{prefix} Sektor"].astype(str),
            probabilities[f"{prefix} Differenz"].to_numpy(dtype=float),
            probabilities[f"{prefix} Perzentil"].to_numpy(dtype=float),
            probabilities[f"{prefix} Tail"].to_numpy(dtype=float),
            probabilities["Historische Beobachtungen"].to_numpy(dtype=int),
        ])
        comparator = "≥ aktuell" if prefix.startswith("Out") else "≤ aktuell"
        fig.add_trace(go.Scatter(
            x=probabilities.index,
            y=probabilities[f"{prefix} Tail"],
            mode="lines",
            name=label,
            customdata=custom,
            line=dict(width=1.8),
            hovertemplate=(
                "%{x|%d.%m.%Y}<br>"
                "<b>%{customdata[0]}</b><br>"
                "1Y-Differenz: %{customdata[1]:.2f} %-Pkt.<br>"
                "Historisches Perzentil: %{customdata[2]:.2f} %<br>"
                f"Tail-Wahrscheinlichkeit {comparator}: "
                "<b>%{customdata[3]:.2f} %</b><br>"
                "Historische Beobachtungen: %{customdata[4]:,.0f}"
                "<extra></extra>"
            ),
        ))

    layout = base_layout(True)
    layout["height"] = 570
    layout["hovermode"] = "x unified"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        range=[0, 100],
        title="Historische Tail-Wahrscheinlichkeit",
        ticksuffix=" %",
    )
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.15, x=0)
    fig.update_layout(**layout)
    return fig


def _sector_rotation_backtests(series_map, probabilities, tail_threshold):
    if probabilities.empty or SECTOR_BENCHMARK_LABEL not in series_map:
        return pd.DataFrame()

    prices = pd.DataFrame(series_map).dropna().sort_index()
    if prices.empty:
        return pd.DataFrame()

    returns = prices.pct_change(fill_method=None)
    available_dates = probabilities.index.intersection(prices.index)
    if available_dates.empty:
        return pd.DataFrame()

    start_date = pd.Timestamp(available_dates.min())
    try:
        start_pos = prices.index.get_loc(start_date)
    except KeyError:
        return pd.DataFrame()

    if isinstance(start_pos, slice) or start_pos >= len(prices.index) - 1:
        return pd.DataFrame()

    out_value = 100.0
    under_value = 100.0
    benchmark_value = 100.0

    dates = [prices.index[start_pos]]
    out_values = [out_value]
    under_values = [under_value]
    benchmark_values = [benchmark_value]

    for pos in range(start_pos + 1, len(prices.index)):
        date = prices.index[pos]
        signal_date = prices.index[pos - 1]
        daily = returns.loc[date]

        benchmark_return = float(daily.get(SECTOR_BENCHMARK_LABEL, np.nan))
        if not np.isfinite(benchmark_return):
            continue

        out_return = benchmark_return
        under_return = benchmark_return

        if signal_date in probabilities.index:
            signal = probabilities.loc[signal_date]

            out_active = (
                float(signal["Out 1 Tail"]) <= float(tail_threshold)
                and float(signal["Out 2 Tail"]) <= float(tail_threshold)
            )
            if out_active:
                out_labels = [signal["Out 1 Sektor"], signal["Out 2 Sektor"]]
                candidate = pd.to_numeric(daily.reindex(out_labels), errors="coerce").dropna()
                if len(candidate) == 2:
                    out_return = float(candidate.mean())

            under_active = (
                float(signal["Under 1 Tail"]) <= float(tail_threshold)
                and float(signal["Under 2 Tail"]) <= float(tail_threshold)
            )
            if under_active:
                under_labels = [signal["Under 1 Sektor"], signal["Under 2 Sektor"]]
                candidate = pd.to_numeric(daily.reindex(under_labels), errors="coerce").dropna()
                if len(candidate) == 2:
                    under_return = float(candidate.mean())

        out_value *= 1.0 + out_return
        under_value *= 1.0 + under_return
        benchmark_value *= 1.0 + benchmark_return

        dates.append(date)
        out_values.append(out_value)
        under_values.append(under_value)
        benchmark_values.append(benchmark_value)

    return pd.DataFrame(
        {
            "Top 2 Outperformance": out_values,
            "Top 2 Underperformance": under_values,
            "S&P 500": benchmark_values,
        },
        index=pd.DatetimeIndex(dates),
    )


def _sector_rotation_figure(frame):
    fig = go.Figure()
    for col in frame.columns:
        is_benchmark = col == "S&P 500"
        fig.add_trace(go.Scatter(
            x=frame.index,
            y=frame[col],
            mode="lines",
            name=col,
            line=dict(
                width=2.5 if is_benchmark else 2.0,
                dash="dash" if is_benchmark else "solid",
            ),
            hovertemplate="%{x|%d.%m.%Y}<br><b>%{y:.2f}</b><extra>%{fullData.name}</extra>",
        ))

    layout = base_layout(True)
    layout["height"] = 560
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        type="log",
        title="Indexiert (Start = 100, log)",
    )
    layout["legend"] = dict(orientation="h", yanchor="top", y=-0.15, x=0)
    fig.update_layout(**layout)
    return fig


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _common_active_sector_series(raw)
    if not series_map:
        st.error("Kein gemeinsamer Datenzeitraum für alle Sektor-ETFs verfügbar.")
        return

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v17",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v17",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v17",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v17",
        )

    rolling_diff = _sector_rolling_return_diff(series_map)
    if not rolling_diff.empty:
        st.markdown("#### Rollierende 1-Jahres-Renditedifferenz zum S&P 500")
        st.plotly_chart(
            _sector_rolling_return_diff_figure(rolling_diff),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_return_diff_v17",
        )

        probabilities = _sector_top2_extreme_probabilities(rolling_diff, warmup_years=10)
        if not probabilities.empty:
            st.markdown("#### Historische Wahrscheinlichkeit der Top-2-Extremsektoren")
            st.plotly_chart(
                _sector_top2_probability_figure(probabilities),
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key="sector_top2_probabilities_v17",
            )

            threshold = st.slider(
                "Schwellenwert x – maximale Tail-Wahrscheinlichkeit für Umschichtung",
                min_value=1,
                max_value=25,
                value=10,
                step=1,
                format="%d %%",
                key="sector_rotation_tail_threshold",
            )
            strategy_frame = _sector_rotation_backtests(
                series_map,
                probabilities,
                tail_threshold=threshold,
            )
            if not strategy_frame.empty:
                st.markdown("#### Top-2-Sektorstrategien vs. S&P 500")
                st.plotly_chart(
                    _sector_rotation_figure(strategy_frame),
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_rotation_backtests_v17",
                )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


ACTIVE_SECTOR_COLORS = {
    SECTOR_LABELS[item["ticker"]]: PALETTE[i % len(PALETTE)]
    for i, item in enumerate(SECTOR_ETFS)
    if item["ticker"] not in EXCLUDED_SECTOR_TICKERS
}


def _sector_rank_colored_figure(probabilities, side, measure):
    fig = go.Figure()
    is_out = side == "out"
    prefixes = ["Out 1", "Out 2"] if is_out else ["Under 1", "Under 2"]
    field = "Differenz" if measure == "diff" else "Tail"
    seen = set()

    for rank_idx, prefix in enumerate(prefixes, start=1):
        sector_col = f"{prefix} Sektor"
        value_col = f"{prefix} {field}"
        for sector in probabilities[sector_col].dropna().astype(str).unique():
            mask = probabilities[sector_col].astype(str).eq(sector)
            y = pd.to_numeric(probabilities[value_col], errors="coerce").where(mask)
            if y.dropna().empty:
                continue

            custom = np.column_stack([
                probabilities[sector_col].astype(str),
                pd.to_numeric(probabilities[f"{prefix} Differenz"], errors="coerce"),
                pd.to_numeric(probabilities[f"{prefix} Perzentil"], errors="coerce"),
                pd.to_numeric(probabilities[f"{prefix} Tail"], errors="coerce"),
            ])

            color = ACTIVE_SECTOR_COLORS.get(sector, "#6b7280")
            showlegend = sector not in seen
            if showlegend:
                seen.add(sector)

            fig.add_trace(go.Scatter(
                x=probabilities.index,
                y=y,
                mode="lines",
                name=sector,
                legendgroup=sector,
                showlegend=showlegend,
                customdata=custom,
                connectgaps=False,
                line=dict(
                    width=2.2 if rank_idx == 1 else 1.5,
                    dash="solid" if rank_idx == 1 else "dot",
                    color=color,
                ),
                hovertemplate=(
                    "%{x|%d.%m.%Y}<br>"
                    f"Rang: <b>#{rank_idx}</b><br>"
                    "<b>%{customdata[0]}</b><br>"
                    "1Y-Differenz: %{customdata[1]:.2f} %-Pkt.<br>"
                    "Historisches Perzentil: %{customdata[2]:.2f} %<br>"
                    "Tail-Wahrscheinlichkeit: <b>%{customdata[3]:.2f} %</b>"
                    "<extra></extra>"
                ),
            ))

    layout = base_layout(True)
    layout["height"] = 500
    layout["hovermode"] = "closest"
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.18,
        x=0,
        title=dict(text="#1 durchgezogen · #2 gepunktet"),
    )

    if measure == "diff":
        layout["yaxis"] = dict(
            showgrid=False,
            zeroline=True,
            zerolinewidth=1,
            title="1Y-Renditedifferenz in %-Pkt.",
        )
    else:
        layout["yaxis"] = dict(
            showgrid=False,
            zeroline=False,
            range=[0, 100],
            title="Tail-Wahrscheinlichkeit",
            ticksuffix=" %",
        )

    fig.update_layout(**layout)
    return fig


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _common_active_sector_series(raw)
    if not series_map:
        st.error("Kein gemeinsamer Datenzeitraum für alle Sektor-ETFs verfügbar.")
        return

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v18",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v18",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v18",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v18",
        )

    rolling_diff = _sector_rolling_return_diff(series_map)
    if not rolling_diff.empty:
        st.markdown("#### Rollierende 1-Jahres-Renditedifferenz zum S&P 500 (seit Inception)")
        st.plotly_chart(
            _sector_rolling_return_diff_figure(rolling_diff),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_return_diff_v18",
        )

        probabilities = _sector_top2_extreme_probabilities(rolling_diff, warmup_years=10)
        if not probabilities.empty:
            c1, c2 = st.columns(2, gap="large")
            with c1:
                st.markdown("#### Top 2 Outperformance – 1Y-Differenz ab Auswertungsstart")
                st.plotly_chart(
                    _sector_rank_colored_figure(probabilities, "out", "diff"),
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_top2_out_diff_v18",
                )
            with c2:
                st.markdown("#### Bottom 2 Underperformance – 1Y-Differenz ab Auswertungsstart")
                st.plotly_chart(
                    _sector_rank_colored_figure(probabilities, "under", "diff"),
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_bottom2_under_diff_v18",
                )

            c1, c2 = st.columns(2, gap="large")
            with c1:
                st.markdown("#### Wahrscheinlichkeit – Top 2 Outperformance")
                st.plotly_chart(
                    _sector_rank_colored_figure(probabilities, "out", "tail"),
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_top2_out_prob_v18",
                )
            with c2:
                st.markdown("#### Wahrscheinlichkeit – Bottom 2 Underperformance")
                st.plotly_chart(
                    _sector_rank_colored_figure(probabilities, "under", "tail"),
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_bottom2_under_prob_v18",
                )

            threshold = st.slider(
                "Schwellenwert x – maximale Tail-Wahrscheinlichkeit für Umschichtung",
                min_value=1,
                max_value=25,
                value=10,
                step=1,
                format="%d %%",
                key="sector_rotation_tail_threshold",
            )
            strategy_frame = _sector_rotation_backtests(
                series_map,
                probabilities,
                tail_threshold=threshold,
            )
            if not strategy_frame.empty:
                st.markdown("#### Top-2-Sektorstrategien vs. S&P 500")
                st.plotly_chart(
                    _sector_rotation_figure(strategy_frame),
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_rotation_backtests_v18",
                )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


def _rolling_relative_return_diff(series_map, lookback_months):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None:
        return pd.DataFrame()

    periods = max(int(round(float(lookback_months) * 21)), 1)
    benchmark_return = benchmark / benchmark.shift(periods) - 1.0

    data = {}
    for label, series in series_map.items():
        if label == SECTOR_BENCHMARK_LABEL:
            continue
        sector_return = series / series.shift(periods) - 1.0
        data[label] = (sector_return - benchmark_return) * 100.0

    return pd.DataFrame(data).dropna(how="all")


def _rolling_relative_return_figure(diff_frame, lookback_months):
    fig = go.Figure()

    for label in diff_frame.columns:
        s = pd.to_numeric(diff_frame[label], errors="coerce").dropna()
        if s.empty:
            continue
        color = ACTIVE_SECTOR_COLORS.get(label, "#9ca3af")
        fig.add_trace(go.Scatter(
            x=s.index,
            y=s,
            mode="lines",
            name=label,
            line=dict(width=1.7, color=color),
            hovertemplate=(
                "%{x|%d.%m.%Y}<br>"
                "<b>%{y:.2f} %-Pkt.</b>"
                "<extra>%{fullData.name}</extra>"
            ),
        ))

    fig.add_hline(y=0, line_width=1, line_dash="dot")

    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title=f"{lookback_months}M-Renditedifferenz in %-Pkt.",
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.15,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def _forward_relative_return_scatter(
    series_map,
    current_diff,
    history_years,
    forward_months,
):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None or current_diff.empty:
        return None

    forward_periods = max(int(round(float(forward_months) * 21)), 1)
    benchmark_forward = benchmark.shift(-forward_periods) / benchmark - 1.0

    latest_date = pd.Timestamp(current_diff.index.max())
    start_date = latest_date - pd.DateOffset(years=int(history_years))

    fig = go.Figure()
    points_found = False

    for label in current_diff.columns:
        sector = series_map.get(label)
        if sector is None:
            continue

        sector_forward = sector.shift(-forward_periods) / sector - 1.0
        forward_diff = (sector_forward - benchmark_forward) * 100.0

        pair = pd.concat(
            [
                pd.to_numeric(current_diff[label], errors="coerce").rename("current"),
                pd.to_numeric(forward_diff, errors="coerce").rename("forward"),
            ],
            axis=1,
        ).dropna()
        pair = pair.loc[pair.index >= start_date]
        if pair.empty:
            continue

        points_found = True
        color = ACTIVE_SECTOR_COLORS.get(label, "#9ca3af")
        dates = pair.index.strftime("%d.%m.%Y").to_numpy().reshape(-1, 1)

        fig.add_trace(go.Scattergl(
            x=pair["current"],
            y=pair["forward"],
            mode="markers",
            name=label,
            marker=dict(size=5, opacity=0.42, color=color),
            customdata=dates,
            hovertemplate=(
                "Datum: %{customdata[0]}<br>"
                "Aktuell: %{x:.2f} %-Pkt.<br>"
                f"Forward {forward_months}M: "
                "%{y:.2f} %-Pkt."
                "<extra>%{fullData.name}</extra>"
            ),
        ))

    if not points_found:
        return None

    fig.add_hline(y=0, line_width=1, line_dash="dot")
    fig.add_vline(x=0, line_width=1, line_dash="dot")

    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["xaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title="Aktuelle rollierende Renditedifferenz in %-Pkt.",
    )
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title=f"Forward {forward_months}M-Renditedifferenz in %-Pkt.",
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.15,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def _all_sector_forward_relative_return_scatter(
    series_map,
    current_diff,
    forward_months,
):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None or current_diff.empty:
        return None

    forward_periods = max(int(round(float(forward_months) * 21)), 1)
    benchmark_forward = benchmark.shift(-forward_periods) / benchmark - 1.0

    fig = go.Figure()
    points_found = False

    for label in current_diff.columns:
        sector = series_map.get(label)
        if sector is None:
            continue

        sector_forward = sector.shift(-forward_periods) / sector - 1.0
        forward_diff = (sector_forward - benchmark_forward) * 100.0

        pair = pd.concat(
            [
                pd.to_numeric(current_diff[label], errors="coerce").rename("current"),
                pd.to_numeric(forward_diff, errors="coerce").rename("forward"),
            ],
            axis=1,
        ).dropna()

        if pair.empty:
            continue

        points_found = True
        color = ACTIVE_SECTOR_COLORS.get(label, "#9ca3af")
        dates = pair.index.strftime("%d.%m.%Y").to_numpy().reshape(-1, 1)

        fig.add_trace(go.Scattergl(
            x=pair["current"],
            y=pair["forward"],
            mode="markers",
            name=label,
            marker=dict(size=5, opacity=0.42, color=color),
            customdata=dates,
            hovertemplate=(
                "Datum: %{customdata[0]}<br>"
                "Aktuelle Renditedifferenz: %{x:.2f} %-Pkt.<br>"
                f"Forward {forward_months}M-Renditedifferenz: "
                "%{y:.2f} %-Pkt."
                "<extra>%{fullData.name}</extra>"
            ),
        ))

    if not points_found:
        return None

    fig.add_hline(y=0, line_width=1, line_dash="dot")
    fig.add_vline(x=0, line_width=1, line_dash="dot")

    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["xaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title="Aktuelle rollierende Renditedifferenz (Sektor − S&P 500) in %-Pkt.",
    )
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title=f"Forward {forward_months}M-Renditedifferenz desselben Sektors in %-Pkt.",
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.15,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _common_active_sector_series(raw)
    if not series_map:
        st.error("Kein gemeinsamer Datenzeitraum für alle Sektor-ETFs verfügbar.")
        return

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v27",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v27",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v27",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v27",
        )

    s1, s2 = st.columns(2, gap="large")
    with s1:
        lookback_months = st.slider(
            "Lookback Renditedifferenz (Monate)",
            min_value=1,
            max_value=60,
            value=12,
            step=1,
            key="sector_diff_lookback_months_v27",
        )
    with s2:
        forward_months = st.slider(
            "Forward-Horizont Y (Monate)",
            min_value=1,
            max_value=36,
            value=12,
            step=1,
            key="sector_forward_months_v27",
        )

    rolling_diff = _rolling_relative_return_diff(
        series_map,
        lookback_months,
    )

    if not rolling_diff.empty:
        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown(
                f"#### Rollierende {lookback_months}-Monats-Renditedifferenz zum S&P 500"
            )
            st.plotly_chart(
                _rolling_relative_return_figure(
                    rolling_diff,
                    lookback_months,
                ),
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key="sector_dynamic_rolling_diff_v27",
            )

        with c2:
            st.markdown(
                f"#### Renditedifferenz vs. Forward {forward_months}M – alle Sektoren"
            )
            forward_fig = _all_sector_forward_relative_return_scatter(
                series_map,
                rolling_diff,
                forward_months,
            )
            if forward_fig is not None:
                st.plotly_chart(
                    forward_fig,
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_all_forward_scatter_v27",
                )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


def _all_sector_forward_relative_return_scatter(
    series_map,
    current_diff,
    forward_months,
):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None or current_diff.empty:
        return None

    max_months = int(forward_months)
    min_months = int(st.session_state.get("sector_forward_min_months_v28", 1))
    min_months = max(1, min(min_months, max_months))

    min_periods = max(int(round(float(min_months) * 21)), 1)
    max_periods = max(int(round(float(max_months) * 21)), min_periods)

    base_index = pd.DatetimeIndex(current_diff.index)

    benchmark_aligned = pd.to_numeric(
        benchmark.reindex(base_index),
        errors="coerce",
    )
    n = len(base_index)
    if n <= max_periods:
        return None

    usable_n = n - max_periods
    current_dates = base_index[:usable_n]
    benchmark_values = benchmark_aligned.to_numpy(dtype=float)
    benchmark_start = benchmark_values[:usable_n]

    fig = go.Figure()
    points_found = False

    for label in current_diff.columns:
        sector = series_map.get(label)
        if sector is None:
            continue

        sector_aligned = pd.to_numeric(
            sector.reindex(base_index),
            errors="coerce",
        )
        sector_values = sector_aligned.to_numpy(dtype=float)
        sector_start = sector_values[:usable_n]

        max_forward = np.full(usable_n, -np.inf, dtype=float)
        max_offset = np.zeros(usable_n, dtype=int)
        has_value = np.zeros(usable_n, dtype=bool)

        with np.errstate(divide="ignore", invalid="ignore"):
            for offset in range(min_periods, max_periods + 1):
                sector_future = sector_values[offset:offset + usable_n]
                benchmark_future = benchmark_values[offset:offset + usable_n]

                forward_diff = (
                    sector_future / sector_start
                    - benchmark_future / benchmark_start
                ) * 100.0

                valid = np.isfinite(forward_diff)
                better = valid & (
                    (~has_value)
                    | (forward_diff > max_forward)
                )

                max_forward[better] = forward_diff[better]
                max_offset[better] = offset
                has_value |= valid

        max_forward[~has_value] = np.nan

        current_values = pd.to_numeric(
            current_diff[label].reindex(current_dates),
            errors="coerce",
        ).to_numpy(dtype=float)

        valid_points = np.isfinite(current_values) & np.isfinite(max_forward)
        if not valid_points.any():
            continue

        points_found = True
        point_positions = np.flatnonzero(valid_points)
        max_positions = point_positions + max_offset[valid_points]

        point_dates = current_dates[valid_points].strftime("%d.%m.%Y")
        peak_dates = base_index[max_positions].strftime("%d.%m.%Y")
        customdata = np.column_stack([point_dates, peak_dates])

        color = ACTIVE_SECTOR_COLORS.get(label, "#9ca3af")

        fig.add_trace(go.Scattergl(
            x=current_values[valid_points],
            y=max_forward[valid_points],
            mode="markers",
            name=label,
            marker=dict(
                size=5,
                opacity=0.42,
                color=color,
            ),
            customdata=customdata,
            hovertemplate=(
                "Datum: %{customdata[0]}<br>"
                "Aktuelle Renditedifferenz: %{x:.2f} %-Pkt.<br>"
                f"Max. Forward-Differenz zwischen {min_months}M und {max_months}M: "
                "%{y:.2f} %-Pkt.<br>"
                "Maximum am: %{customdata[1]}"
                "<extra>%{fullData.name}</extra>"
            ),
        ))

    if not points_found:
        return None

    fig.add_hline(y=0, line_width=1, line_dash="dot")
    fig.add_vline(x=0, line_width=1, line_dash="dot")

    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["xaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title="Aktuelle rollierende Renditedifferenz (Sektor − S&P 500) in %-Pkt.",
    )
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title=(
            f"Max. Forward-Renditedifferenz zwischen "
            f"{min_months}M und {max_months}M in %-Pkt."
        ),
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.15,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def _available_sector_series(raw):
    if not raw or "SPY" not in raw:
        return {}

    benchmark = pd.to_numeric(raw.get("SPY"), errors="coerce").dropna().sort_index()
    if benchmark.empty:
        return {}

    series = {SECTOR_BENCHMARK_LABEL: benchmark}
    for item in SECTOR_ETFS:
        ticker = item["ticker"]
        if ticker in EXCLUDED_SECTOR_TICKERS:
            continue
        raw_series = raw.get(ticker)
        if raw_series is None:
            continue
        s = pd.to_numeric(raw_series, errors="coerce").dropna().sort_index()
        if s.empty:
            continue
        series[SECTOR_LABELS[ticker]] = s

    if len(series) <= 1:
        return {}

    frame = pd.concat(series, axis=1, join="inner").dropna(how="any").sort_index()
    if frame.empty:
        return {}

    return {col: frame[col].copy() for col in frame.columns}


def _single_sector_12m_diff(series_map, sector_label):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    sector = series_map.get(sector_label)
    if benchmark is None or sector is None:
        return pd.Series(dtype=float)

    periods = 252
    benchmark_return = benchmark / benchmark.shift(periods) - 1.0
    sector_return = sector / sector.shift(periods) - 1.0
    return ((sector_return - benchmark_return) * 100.0).dropna()


def _two_year_block_troughs(diff_series):
    s = pd.to_numeric(diff_series, errors="coerce").dropna().sort_index()
    if s.empty:
        return []

    first_date = pd.Timestamp(s.index.min())
    last_date = pd.Timestamp(s.index.max())
    block_start = first_date
    events = []

    while block_start <= last_date:
        block_end = block_start + pd.DateOffset(years=2)
        block = s.loc[(s.index >= block_start) & (s.index < block_end)]
        if not block.empty:
            trough_date = pd.Timestamp(block.idxmin())
            events.append({
                "block_start": block_start,
                "block_end": min(block_end - pd.Timedelta(days=1), last_date),
                "date": trough_date,
                "signal": float(block.loc[trough_date]),
            })
        block_start = block_end

    return events


def _single_sector_diff_figure(diff_series, sector_label, events, selected_event_idx):
    s = pd.to_numeric(diff_series, errors="coerce").dropna()
    if s.empty:
        return None

    color = ACTIVE_SECTOR_COLORS.get(sector_label, "#9ca3af")
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=s.index,
        y=s,
        mode="lines",
        name=sector_label,
        line=dict(width=2.1, color=color),
        hovertemplate=(
            "%{x|%d.%m.%Y}<br>"
            "<b>%{y:.2f} %-Pkt.</b>"
            "<extra>%{fullData.name}</extra>"
        ),
    ))

    if events:
        fig.add_trace(go.Scatter(
            x=[item["date"] for item in events],
            y=[item["signal"] for item in events],
            mode="markers",
            name="2Y-Tiefpunkte",
            marker=dict(size=7, color=color, symbol="circle-open"),
            hovertemplate=(
                "%{x|%d.%m.%Y}<br>"
                "2Y-Tiefpunkt: <b>%{y:.2f} %-Pkt.</b>"
                "<extra></extra>"
            ),
        ))

        idx = max(0, min(int(selected_event_idx), len(events) - 1))
        fig.add_vline(
            x=events[idx]["date"],
            line_width=1.4,
            line_dash="dash",
        )

    fig.add_hline(y=0, line_width=1, line_dash="dot")

    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title="12M-Renditedifferenz in %-Pkt.",
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.15,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def _indexed_from_trough_figure(series_map, sector_label, event, max_follow_years=5):
    sector = series_map.get(sector_label)
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if sector is None or benchmark is None:
        return None

    start_date = pd.Timestamp(event["date"])
    latest_date = min(pd.Timestamp(sector.index.max()), pd.Timestamp(benchmark.index.max()))
    end_date = min(
        start_date + pd.DateOffset(years=int(max_follow_years)),
        latest_date,
    )

    frame = pd.concat(
        [
            pd.to_numeric(sector, errors="coerce").rename(sector_label),
            pd.to_numeric(benchmark, errors="coerce").rename(SECTOR_BENCHMARK_LABEL),
        ],
        axis=1,
        join="inner",
    ).dropna().sort_index()

    frame = frame.loc[(frame.index >= start_date) & (frame.index <= end_date)]
    if frame.empty:
        return None

    frame = frame / frame.iloc[0] * 100.0
    color = ACTIVE_SECTOR_COLORS.get(sector_label, "#9ca3af")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=frame.index,
        y=frame[sector_label],
        mode="lines",
        name=sector_label,
        line=dict(width=2.5, color=color),
        hovertemplate=(
            "%{x|%d.%m.%Y}<br>"
            "<b>%{y:.2f}</b>"
            "<extra>%{fullData.name}</extra>"
        ),
    ))
    fig.add_trace(go.Scatter(
        x=frame.index,
        y=frame[SECTOR_BENCHMARK_LABEL],
        mode="lines",
        name=SECTOR_BENCHMARK_LABEL,
        line=dict(width=2.3, color="#6b7280", dash="dash"),
        hovertemplate=(
            "%{x|%d.%m.%Y}<br>"
            "<b>%{y:.2f}</b>"
            "<extra>%{fullData.name}</extra>"
        ),
    ))

    layout = base_layout(True)
    layout["height"] = 540
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title="Indexiert (Tiefpunkt = 100)",
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.15,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def _render_sector_selector_analysis(series_map):
    sectors = [
        label for label in series_map
        if label != SECTOR_BENCHMARK_LABEL
    ]
    if not sectors:
        return

    selected_sector = st.selectbox(
        "Sektor",
        options=sectors,
        index=0,
        key="sector_focus_select_v31",
    )

    diff_series = _single_sector_12m_diff(series_map, selected_sector)
    if diff_series.empty:
        return

    events = _two_year_block_troughs(diff_series)
    if not events:
        return

    signature_key = "sector_focus_signature_v31"
    index_key = "sector_focus_trough_idx_v31"
    signature = (selected_sector, len(events), events[-1]["date"].isoformat())

    if st.session_state.get(signature_key) != signature:
        st.session_state[signature_key] = signature
        st.session_state[index_key] = len(events) - 1

    idx = int(st.session_state.get(index_key, len(events) - 1))
    idx = max(0, min(idx, len(events) - 1))
    st.session_state[index_key] = idx
    event = events[idx]

    c1, c2 = st.columns(2, gap="large")

    with c1:
        st.markdown("#### Rollierende 12-Monats-Renditedifferenz zum S&P 500")
        fig = _single_sector_diff_figure(
            diff_series,
            selected_sector,
            events,
            idx,
        )
        if fig is not None:
            st.plotly_chart(
                fig,
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key=f"sector_focus_diff_v31_{selected_sector}",
            )

    with c2:
        nav_left, nav_center, nav_right = st.columns([1, 6, 1], gap="small")

        with nav_left:
            if st.button(
                "←",
                key="sector_focus_prev_v31",
                disabled=idx <= 0,
            ):
                st.session_state[index_key] = idx - 1
                st.rerun()

        with nav_center:
            st.markdown(
                f"#### Tiefpunkt {idx + 1} / {len(events)} · "
                f"{event['date']:%d.%m.%Y}"
            )
            st.caption(
                f"2Y-Block: {event['block_start']:%d.%m.%Y} – "
                f"{event['block_end']:%d.%m.%Y} · "
                f"{event['signal']:.2f} %-Pkt."
            )

        with nav_right:
            if st.button(
                "→",
                key="sector_focus_next_v31",
                disabled=idx >= len(events) - 1,
            ):
                st.session_state[index_key] = idx + 1
                st.rerun()

        indexed_fig = _indexed_from_trough_figure(
            series_map,
            selected_sector,
            event,
            max_follow_years=5,
        )
        if indexed_fig is not None:
            st.plotly_chart(
                indexed_fig,
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key=f"sector_focus_indexed_v31_{selected_sector}_{idx}",
            )


def render_sp500_sector_etfs():
    raw = sector_prices_usd()
    if not raw:
        st.error("Sektordaten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"],
            "ETF": ticker,
            "Auflage": item["inception"],
            "Daten verfügbar": (
                f"{raw[ticker].index.min():%d.%m.%Y} – "
                f"{raw[ticker].index.max():%d.%m.%Y}"
            ),
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        _sector_overview_style(overview),
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=500),
    )

    series_map = _available_sector_series(raw)
    if not series_map:
        st.error("Keine ausreichenden Sektordaten verfügbar.")
        return

    _render_sector_selector_analysis(series_map)

    indexed = _indexed_individually(series_map)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Wertentwicklung")
        st.plotly_chart(
            _sector_performance_figure(indexed),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_perf_v31",
        )
    with c2:
        st.markdown("#### Drawdown")
        st.plotly_chart(
            _sector_drawdown_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_dd_v31",
        )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("#### Korrelogramm")
        st.plotly_chart(
            _sector_correlation_figure(series_map),
            width="stretch",
            config={"displaylogo": False},
            key="sector_corr_v31",
        )
    with c2:
        st.markdown("#### Rollierende 1-Jahres-Korrelation zum S&P 500")
        st.plotly_chart(
            _sector_rolling_corr_figure(series_map),
            width="stretch",
            config={"displaylogo": False, "scrollZoom": True},
            key="sector_rolling_corr_v31",
        )

    s1, s2 = st.columns(2, gap="large")
    with s1:
        lookback_months = st.slider(
            "Lookback Renditedifferenz (Monate)",
            min_value=1,
            max_value=60,
            value=12,
            step=1,
            key="sector_diff_lookback_months_v31",
        )
    with s2:
        min_forward = st.slider(
            "Forward-Fenster Minimum (Monate)",
            min_value=1,
            max_value=35,
            value=1,
            step=1,
            key="sector_forward_min_months_v31",
        )
        max_forward = st.slider(
            "Forward-Fenster Maximum (Monate)",
            min_value=int(min_forward),
            max_value=36,
            value=max(12, int(min_forward)),
            step=1,
            key="sector_forward_max_months_v31",
        )

    st.session_state["sector_forward_min_months_v28"] = int(min_forward)
    rolling_diff = _rolling_relative_return_diff(series_map, lookback_months)

    if not rolling_diff.empty:
        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown(
                f"#### Rollierende {lookback_months}-Monats-Renditedifferenz zum S&P 500"
            )
            st.plotly_chart(
                _rolling_relative_return_figure(rolling_diff, lookback_months),
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
                key="sector_dynamic_rolling_diff_v31",
            )

        with c2:
            st.markdown(
                f"#### Max. Forward-Renditedifferenz zwischen "
                f"{min_forward}M und {max_forward}M"
            )
            forward_fig = _all_sector_forward_relative_return_scatter(
                series_map,
                rolling_diff,
                int(max_forward),
            )
            if forward_fig is not None:
                st.plotly_chart(
                    forward_fig,
                    width="stretch",
                    config={"displaylogo": False, "scrollZoom": True},
                    key="sector_all_forward_scatter_v31",
                )

    metrics = _sector_metrics(series_map)
    st.markdown("#### Kennzahlen")
    st.dataframe(
        style_heat(metrics, reverse_columns={"Volatilität p.a."}),
        width="stretch",
        height=compact_height(len(metrics), maximum=520),
    )

    annual_sharpe = _sector_annual_sharpe(series_map)
    st.markdown("#### Jährliche Sharpe Ratio")
    st.dataframe(
        style_heat(annual_sharpe),
        width="stretch",
        height=compact_height(len(annual_sharpe), maximum=520),
    )


COMMODITY_UNIVERSE = [
    {"class": "Energie", "name": "WTI Rohöl", "ticker": "CL=F"},
    {"class": "Energie", "name": "Brent Rohöl", "ticker": "BZ=F"},
    {"class": "Energie", "name": "Erdgas", "ticker": "NG=F"},
    {"class": "Energie", "name": "RBOB Benzin", "ticker": "RB=F"},
    {"class": "Energie", "name": "Heizöl", "ticker": "HO=F"},
    {"class": "Metalle", "name": "Gold", "ticker": "GC=F"},
    {"class": "Metalle", "name": "Silber", "ticker": "SI=F"},
    {"class": "Metalle", "name": "Kupfer", "ticker": "HG=F"},
    {"class": "Metalle", "name": "Platin", "ticker": "PL=F"},
    {"class": "Metalle", "name": "Palladium", "ticker": "PA=F"},
    {"class": "Getreide & Ölsaaten", "name": "Mais", "ticker": "ZC=F"},
    {"class": "Getreide & Ölsaaten", "name": "Weizen", "ticker": "ZW=F"},
    {"class": "Getreide & Ölsaaten", "name": "Sojabohnen", "ticker": "ZS=F"},
    {"class": "Getreide & Ölsaaten", "name": "Sojaöl", "ticker": "ZL=F"},
    {"class": "Getreide & Ölsaaten", "name": "Sojaschrot", "ticker": "ZM=F"},
    {"class": "Soft Commodities", "name": "Kaffee", "ticker": "KC=F"},
    {"class": "Soft Commodities", "name": "Zucker", "ticker": "SB=F"},
    {"class": "Soft Commodities", "name": "Kakao", "ticker": "CC=F"},
    {"class": "Soft Commodities", "name": "Baumwolle", "ticker": "CT=F"},
    {"class": "Soft Commodities", "name": "Orangensaft", "ticker": "OJ=F"},
    {"class": "Vieh", "name": "Live Cattle", "ticker": "LE=F"},
    {"class": "Vieh", "name": "Lean Hogs", "ticker": "HE=F"},
]

COMMODITY_BY_TICKER = {item["ticker"]: item for item in COMMODITY_UNIVERSE}
COMMODITY_CLASS_ORDER = list(dict.fromkeys(item["class"] for item in COMMODITY_UNIVERSE))


@st.cache_data(ttl=21600, show_spinner=False)
def commodity_prices_usd():
    tickers = [item["ticker"] for item in COMMODITY_UNIVERSE]
    try:
        data = yf.download(
            tickers=tickers,
            start="1990-01-01",
            auto_adjust=False,
            progress=False,
            threads=True,
            group_by="column",
        )
    except Exception:
        return pd.DataFrame()

    if data is None or data.empty:
        return pd.DataFrame()

    if isinstance(data.columns, pd.MultiIndex):
        level0 = data.columns.get_level_values(0)
        if "Adj Close" in level0:
            prices = data["Adj Close"].copy()
        elif "Close" in level0:
            prices = data["Close"].copy()
        else:
            return pd.DataFrame()
    else:
        field = "Adj Close" if "Adj Close" in data.columns else "Close"
        if field not in data.columns:
            return pd.DataFrame()
        prices = data[[field]].copy()
        prices.columns = [tickers[0]]

    if isinstance(prices, pd.Series):
        prices = prices.to_frame()

    prices = prices.apply(pd.to_numeric, errors="coerce")
    prices = prices.sort_index()
    prices = prices.loc[:, prices.notna().sum(axis=0) >= 252]
    prices = prices.dropna(how="all")
    return prices


def _commodity_common_returns(prices):
    if prices.empty:
        return pd.DataFrame(), pd.Series(dtype=float)

    returns = prices.pct_change(fill_method=None)
    returns = returns.replace([np.inf, -np.inf], np.nan)

    common = returns.dropna(how="any").sort_index()
    if common.empty:
        return pd.DataFrame(), pd.Series(dtype=float)

    index_return = common.mean(axis=1)
    index_return.name = "Equal Weighted Commodity Index"
    return common, index_return


def _equal_weight_commodity_index(index_return):
    if index_return.empty:
        return pd.Series(dtype=float)
    index = (1.0 + index_return).cumprod() * 100.0
    index.name = "Equal Weighted Commodity Index"
    return index


def _rolling_commodity_beta(common_returns, index_return, window_days):
    if common_returns.empty or index_return.empty:
        return pd.DataFrame()

    market_var = index_return.rolling(
        int(window_days),
        min_periods=int(window_days),
    ).var()

    beta = {}
    for ticker in common_returns.columns:
        covariance = common_returns[ticker].rolling(
            int(window_days),
            min_periods=int(window_days),
        ).cov(index_return)
        beta[ticker] = covariance / market_var

    return pd.DataFrame(beta).replace([np.inf, -np.inf], np.nan)


def _commodity_index_figure(index_series):
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=index_series.index,
        y=index_series,
        mode="lines",
        name="Equal Weighted Commodity Index",
        line=dict(width=2.4),
        hovertemplate=(
            "%{x|%d.%m.%Y}<br>"
            "<b>%{y:.2f}</b>"
            "<extra></extra>"
        ),
    ))
    layout = base_layout(True)
    layout["height"] = 520
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title="Indexiert (Start = 100)",
    )
    fig.update_layout(**layout)
    return fig


def _commodity_beta_figure(beta_frame, selected_class, window_months):
    fig = go.Figure()

    selected_tickers = [
        item["ticker"]
        for item in COMMODITY_UNIVERSE
        if item["class"] == selected_class and item["ticker"] in beta_frame.columns
    ]

    for ticker in selected_tickers:
        s = pd.to_numeric(beta_frame[ticker], errors="coerce").dropna()
        if s.empty:
            continue
        item = COMMODITY_BY_TICKER[ticker]
        fig.add_trace(go.Scatter(
            x=s.index,
            y=s,
            mode="lines",
            name=f"{item['name']} ({ticker})",
            line=dict(width=1.8),
            hovertemplate=(
                "%{x|%d.%m.%Y}<br>"
                "<b>Beta %{y:.2f}</b>"
                "<extra>%{fullData.name}</extra>"
            ),
        ))

    fig.add_hline(y=1, line_width=1, line_dash="dot")
    fig.add_hline(y=0, line_width=1, line_dash="dot")

    layout = base_layout(True)
    layout["height"] = 570
    layout["hovermode"] = "closest"
    layout["yaxis"] = dict(
        showgrid=False,
        zeroline=False,
        title=f"Rollierendes Beta ({window_months}M)",
    )
    layout["legend"] = dict(
        orientation="h",
        yanchor="top",
        y=-0.16,
        x=0,
    )
    fig.update_layout(**layout)
    return fig


def render_commodities():
    prices = commodity_prices_usd()
    if prices.empty:
        st.error("Commodity-Daten konnten nicht geladen werden.")
        return

    overview_rows = []
    for item in COMMODITY_UNIVERSE:
        ticker = item["ticker"]
        if ticker not in prices.columns:
            continue
        s = pd.to_numeric(prices[ticker], errors="coerce").dropna()
        if s.empty:
            continue
        overview_rows.append({
            "Oberklasse": item["class"],
            "Rohstoff": item["name"],
            "Symbol": ticker,
            "Daten ab": f"{s.index.min():%d.%m.%Y}",
            "Daten bis": f"{s.index.max():%d.%m.%Y}",
        })

    overview = pd.DataFrame(overview_rows)
    st.dataframe(
        overview,
        width="stretch",
        hide_index=True,
        height=compact_height(len(overview), maximum=650),
    )

    available_tickers = [
        item["ticker"]
        for item in COMMODITY_UNIVERSE
        if item["ticker"] in prices.columns
    ]
    prices = prices.reindex(columns=available_tickers)

    common_returns, index_return = _commodity_common_returns(prices)
    if common_returns.empty:
        st.error("Kein gemeinsamer Zeitraum für den Commodity Index verfügbar.")
        return

    index_series = _equal_weight_commodity_index(index_return)

    st.markdown("#### Equal Weighted Commodity Index")
    st.plotly_chart(
        _commodity_index_figure(index_series),
        width="stretch",
        config={"displaylogo": False, "scrollZoom": True},
        key="commodity_equal_weight_index_v32",
    )

    c1, c2 = st.columns(2, gap="large")
    with c1:
        beta_months = st.slider(
            "Beta-Fenster (Monate)",
            min_value=3,
            max_value=36,
            value=12,
            step=1,
            key="commodity_beta_months_v32",
        )
    with c2:
        available_classes = [
            category
            for category in COMMODITY_CLASS_ORDER
            if any(
                item["class"] == category and item["ticker"] in common_returns.columns
                for item in COMMODITY_UNIVERSE
            )
        ]
        selected_class = st.selectbox(
            "Oberklasse",
            options=available_classes,
            index=0,
            key="commodity_beta_class_v32",
        )

    window_days = max(int(round(float(beta_months) * 21)), 1)
    beta_frame = _rolling_commodity_beta(
        common_returns,
        index_return,
        window_days,
    )

    st.markdown(f"#### Rollierendes Beta zum Commodity Index – {selected_class}")
    st.plotly_chart(
        _commodity_beta_figure(beta_frame, selected_class, beta_months),
        width="stretch",
        config={"displaylogo": False, "scrollZoom": True},
        key=f"commodity_beta_chart_v32_{selected_class}_{beta_months}",
    )

    current_rows = []
    for item in COMMODITY_UNIVERSE:
        ticker = item["ticker"]
        if item["class"] != selected_class or ticker not in beta_frame.columns:
            continue
        s = pd.to_numeric(beta_frame[ticker], errors="coerce").dropna()
        if s.empty:
            continue
        current_rows.append({
            "Rohstoff": item["name"],
            "Symbol": ticker,
            "Aktuelles Beta": float(s.iloc[-1]),
        })

    if current_rows:
        current = pd.DataFrame(current_rows)
        st.dataframe(
            current.style.format({"Aktuelles Beta": "{:.2f}"}),
            width="stretch",
            hide_index=True,
            height=compact_height(len(current), maximum=360),
        )


_original_render_asset_allocation_tool = render_asset_allocation_tool


def render_asset_allocation_tool():
    st.title("Asset Allocation Backtesting Tool")
    st.caption(
        "Freie Wertpapiersuche über Yahoo Finance. Name, Ticker oder ISIN eingeben; "
        "bei nicht eindeutig auflösbaren ISINs funktioniert der Yahoo-Ticker am zuverlässigsten."
    )

    st.markdown("### Wertpapier hinzufügen")
    query = st.text_input(
        "Name, Ticker oder ISIN",
        key="aa_search_query",
        placeholder="z. B. Apple, AAPL oder US0378331005",
    )
    results = yahoo_search(query) if query else []
    if results:
        labels = [
            f"{x['name']} · {x['symbol']}"
            + (f" · {x['exchange']}" if x["exchange"] else "")
            for x in results
        ]
        selected_label = st.selectbox(
            "Suchergebnis",
            labels,
            key="aa_search_result",
        )
        selected_result = results[labels.index(selected_label)]
        add_col, benchmark_col = st.columns(2)
        with add_col:
            if st.button("Zum Portfolio hinzufügen", use_container_width=True):
                add_asset(selected_result)
                st.rerun()
        with benchmark_col:
            if st.button("Als Benchmark verwenden", use_container_width=True):
                st.session_state.aa_benchmark = selected_result
                st.rerun()

    assets = _aa_assets()
    if assets:
        st.markdown("### Portfolio")
        for i, asset in enumerate(list(assets)):
            c1, c2, c3 = st.columns([.54, .28, .18], vertical_alignment="center")
            with c1:
                st.markdown(f"**{asset['name']}**  \n`{asset['symbol']}`")
            with c2:
                new_weight = st.number_input(
                    "Gewicht %",
                    min_value=0.0,
                    max_value=100.0,
                    value=float(asset["weight"]),
                    step=1.0,
                    key=f"aa_weight_{asset['symbol']}",
                )
                asset["weight"] = float(new_weight)
            with c3:
                if st.button(
                    "Entfernen",
                    key=f"aa_remove_{asset['symbol']}",
                    use_container_width=True,
                ):
                    remove_asset(asset["symbol"])
                    st.rerun()

        total_weight = sum(x["weight"] for x in assets)
        st.caption(f"Summe Gewichte: {total_weight:.2f} %")
    else:
        st.info("Noch keine Wertpapiere im Portfolio.")

    benchmark = st.session_state.get("aa_benchmark")
    if benchmark:
        st.markdown(
            f"**Benchmark:** {benchmark['name']} · `{benchmark['symbol']}`"
        )

    # Neue Funktion: Zeitraum ändern
    st.markdown("### Backtesting-Einstellungen")
    c1, c2, c3 = st.columns(3, gap="large")
    
    with c1:
        rebalance = st.selectbox(
            "Rebalancing",
            [
                "Monatlich",
                "Quartalsweise",
                "Halbjährlich",
                "Jährlich",
                "Kein Rebalancing",
            ],
            index=1,
            key="aa_rebalance",
        )
    
    with c2:
        time_period_option = st.selectbox(
            "Zeitraum",
            [
                "Gesamter Datenzeitraum",
                "Letzte 1 Jahr",
                "Letzte 3 Jahre",
                "Letzte 5 Jahre",
                "Letzte 10 Jahre",
                "Benutzerdefiniert",
            ],
            index=0,
            key="aa_time_period",
        )
    
    with c3:
        if time_period_option == "Benutzerdefiniert":
            custom_years = st.number_input(
                "Jahre zurück",
                min_value=1,
                max_value=50,
                value=5,
                step=1,
                key="aa_custom_years",
            )
        else:
            custom_years = None

    if st.button("Backtest starten", type="primary", use_container_width=True):
        if not assets:
            st.error("Mindestens ein Wertpapier hinzufügen.")
            return
        if not benchmark:
            st.error("Bitte eine Benchmark auswählen.")
            return
        weights = np.array([x["weight"] for x in assets], dtype=float)
        if weights.sum() <= 0:
            st.error("Die Summe der Gewichte muss größer als 0 sein.")
            return

        price_series = {}
        errors = []
        with st.spinner("Kursdaten werden geladen …"):
            for asset in assets:
                try:
                    series, _ = asset_series_eur(asset["symbol"])
                    price_series[asset["symbol"]] = series
                except Exception as exc:
                    errors.append(str(exc))
            try:
                benchmark_series, _ = asset_series_eur(benchmark["symbol"])
            except Exception as exc:
                benchmark_series = None
                errors.append(f"Benchmark: {exc}")

        if errors:
            for error in errors:
                st.warning(error)
        if len(price_series) != len(assets) or benchmark_series is None:
            st.error("Backtest konnte nicht vollständig geladen werden.")
            return

        prices = pd.concat(price_series, axis=1).dropna()
        benchmark_series = benchmark_series.reindex(prices.index).dropna()
        common_index = prices.index.intersection(benchmark_series.index)
        prices = prices.loc[common_index]
        benchmark_series = benchmark_series.loc[common_index]
        
        # Zeitraum filtern
        if time_period_option != "Gesamter Datenzeitraum":
            if time_period_option == "Letzte 1 Jahr":
                years_back = 1
            elif time_period_option == "Letzte 3 Jahre":
                years_back = 3
            elif time_period_option == "Letzte 5 Jahre":
                years_back = 5
            elif time_period_option == "Letzte 10 Jahre":
                years_back = 10
            else:  # Benutzerdefiniert
                years_back = custom_years
            
            cutoff_date = pd.Timestamp.now() - pd.DateOffset(years=years_back)
            prices = prices[prices.index >= cutoff_date]
            benchmark_series = benchmark_series[benchmark_series.index >= cutoff_date]
            common_index = prices.index.intersection(benchmark_series.index)
            prices = prices.loc[common_index]
            benchmark_series = benchmark_series.loc[common_index]
        
        if len(prices) < 30:
            st.error("Zu wenig gemeinsamer Datenzeitraum.")
            return

        portfolio = backtest_portfolio(
            prices,
            weights,
            rebalance,
        )
        benchmark_indexed = benchmark_series / benchmark_series.iloc[0] * 100.0

        comparison = pd.concat(
            [portfolio.rename("Portfolio"), benchmark_indexed.rename("Benchmark")],
            axis=1,
        ).dropna()

        perf = go.Figure()
        perf.add_trace(go.Scatter(
            x=comparison.index,
            y=comparison["Portfolio"],
            mode="lines",
            name="Portfolio",
            line=dict(width=2.8),
            hovertemplate=(
                "%{x|%d.%m.%Y}<br>"
                "<b>%{y:.2f}</b>"
                "<extra></extra>"
            ),
        ))
        perf.add_trace(go.Scatter(
            x=comparison.index,
            y=comparison["Benchmark"],
            mode="lines",
            name="Benchmark",
            line=dict(
                width=2.0,
                dash="dash",
            ),
            hovertemplate=(
                "%{x|%d.%m.%Y}<br>"
                "<b>%{y:.2f}</b>"
                "<extra></extra>"
            ),
        ))
        perf_layout = base_layout(True)
        perf_layout["yaxis"] = dict(
            showgrid=False,
            type="log",
            title="Indexiert (log)",
        )
        perf.update_layout(**perf_layout)

        dd = comparison / comparison.cummax() - 1
        dd_fig = go.Figure()
        for col in dd.columns:
            dd_fig.add_trace(go.Scatter(
                x=dd.index,
                y=dd[col] * 100,
                mode="lines",
                name=col,
                line=dict(width=2.5 if col == "Portfolio" else 2.0,
                          dash="dash" if col == "Benchmark" else "solid"),
            ))
        dd_layout = base_layout(True)
        dd_layout["showlegend"] = True
        dd_layout["yaxis"] = dict(showgrid=False, title="Drawdown in %")
        dd_fig.update_layout(**dd_layout)

        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown("#### Wertentwicklung")
            st.plotly_chart(
                perf,
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
            )
        with c2:
            st.markdown("#### Drawdown")
            st.plotly_chart(
                dd_fig,
                width="stretch",
                config={"displaylogo": False, "scrollZoom": True},
            )

        stats = pd.DataFrame(
            {
                "Portfolio": backtest_metrics(comparison["Portfolio"]),
                "Benchmark": backtest_metrics(comparison["Benchmark"]),
            }
        ).T
        st.markdown("#### Kennzahlen")
        st.dataframe(
            style_heat(stats),
            width="stretch",
            height=compact_height(len(stats)),
        )

        weights_display = pd.DataFrame(
            {
                "Wertpapier": [x["name"] for x in assets],
                "Ticker": [x["symbol"] for x in assets],
                "Gewicht": weights / weights.sum(),
            }
        )
        st.markdown("#### Backtest-Konfiguration")
        st.dataframe(
            weights_display.style.format({"Gewicht": "{:.2%}"}),
            width="stretch",
            hide_index=True,
            height=compact_height(len(weights_display)),
        )
        st.caption(
            f"Rebalancing: {rebalance} · Zeitraum: "
            f"{comparison.index.min():%d.%m.%Y} – {comparison.index.max():%d.%m.%Y}"
        )


top_page = _text_nav(
    [
        "China ETF Dashboard",
        "Asset Allocation Backtesting Tool",
        "S&P 500 Sector ETFs",
        "Commodities",
    ],
    "top_page",
    "China ETF Dashboard",
    "top_text_nav",
)
st.session_state.after_tax = True

if top_page == "China ETF Dashboard":
    render_china_dashboard()
elif top_page == "Asset Allocation Backtesting Tool":
    render_asset_allocation_tool()
elif top_page == "S&P 500 Sector ETFs":
    render_sp500_sector_etfs()
else:
    render_commodities()