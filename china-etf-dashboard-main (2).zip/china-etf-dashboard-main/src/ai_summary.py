"""Server-side Gemini summaries grounded in the dashboard's price data."""
from __future__ import annotations

import json
import os
import hashlib
import logging
import time
from pathlib import Path

import requests

from src.cache import cache


class SummaryError(Exception):
    pass


logger = logging.getLogger(__name__)
CACHE_DIR = Path(__file__).resolve().parents[1] / ".cache" / "ai_summaries"


def _post_with_retry(url, **kwargs):
    for attempt in range(3):
        try:
            response = requests.post(url, **kwargs)
        except requests.RequestException:
            if attempt == 2:
                raise SummaryError("Google ist nach drei Versuchen nicht erreichbar. Bitte später erneut versuchen.") from None
            logger.warning("Gemini connection failed (attempt %s/3)", attempt + 1)
        else:
            if response.status_code not in (500, 502, 503, 504):
                return response
            logger.warning("Gemini HTTP %s (attempt %s/3)", response.status_code, attempt + 1)
            if attempt == 2:
                return response
        time.sleep(attempt + 1)


def _api_key():
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        path = Path(__file__).resolve().parents[1] / ".secrets" / "gemini.json"
        try:
            key = json.loads(path.read_text(encoding="utf-8")).get("api_key", "").strip()
        except (OSError, ValueError):
            pass
    if not key:
        raise SummaryError("Der Gemini-Schlüssel fehlt auf dem Server.")
    return key


@cache.memoize(timeout=3600)
def generate_summaries(payload_json: str):
    payload = json.loads(payload_json)
    keys = [item["key"] for item in payload]
    model = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash")
    # A yearly review needs refreshing once per data day, not for every
    # intraday price movement. Persist successful responses across restarts.
    identity = [(item["key"], item.get("start"), item.get("end"), item.get("data_status"), item.get("ticker")) for item in payload]
    digest = hashlib.sha256(json.dumps([2, model, identity]).encode()).hexdigest()
    cache_path = CACHE_DIR / (digest + ".json")
    try:
        saved = json.loads(cache_path.read_text(encoding="utf-8"))
        if set(saved) == set(keys) and all(isinstance(v, str) and v.strip() for v in saved.values()):
            return saved
    except (OSError, ValueError, TypeError):
        pass
    instruction = (
        "Schreibe auf Deutsch für jede übergebene Anlageklasse einen eigenen, gut lesbaren "
        "Rückblick über die letzten zwölf Monate (80 bis 120 Wörter). Nutze ausschließlich "
        "die übergebenen Daten: Rendite, Verlauf, Drawdown und Schwankungen. Werte sind "
        "Dezimalzahlen, z.B. 0.12 = 12 Prozent. Benenne den ETF-/Krypto-Proxy und den tatsächlichen "
        "Zeitraum. Monatswerte sind Monatsendstände auf Start=100, keine Monatsrenditen. "
        "Erfinde keine Nachrichten, Ereignisse, Ursachen, Prognosen oder Anlageempfehlungen. "
        "Bei fehlenden Daten beschreibe die Datenlücke statt Zahlen zu erfinden. "
        "Liefere exakt einen Eintrag pro key. Keine Markdown-Überschriften im Text."
    )
    try:
        response = _post_with_retry(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
            headers={"x-goog-api-key": _api_key()},
            json={
                "systemInstruction": {"parts": [{"text": instruction}]},
                "contents": [{"role": "user", "parts": [{"text": payload_json}]}],
                "generationConfig": {
                    "temperature": 0.2, "maxOutputTokens": 8000,
                    "thinkingConfig": {"thinkingLevel": "minimal"},
                    "responseMimeType": "application/json",
                    "responseSchema": {
                        "type": "OBJECT", "required": ["summaries"],
                        "properties": {"summaries": {
                            "type": "ARRAY", "items": {
                                "type": "OBJECT", "required": ["key", "text"],
                                "properties": {"key": {"type": "STRING", "enum": keys},
                                               "text": {"type": "STRING"}},
                            },
                        }},
                    },
                },
            },
            timeout=(10, 40),
        )
    except requests.RequestException:
        raise SummaryError("Gemini ist derzeit nicht erreichbar. Bitte erneut versuchen.") from None
    if response.status_code == 429:
        raise SummaryError("Das Gemini-Kontingent ist derzeit ausgeschöpft. Bitte Kontingent prüfen oder später erneut versuchen.")
    if response.status_code in (400, 401, 403):
        raise SummaryError("Gemini hat die Anfrage abgelehnt. Bitte API-Schlüssel und Modellzugriff prüfen.")
    if not response.ok:
        logger.warning("Gemini request rejected: HTTP %s", response.status_code)
        if response.status_code == 404:
            raise SummaryError("Das konfigurierte Gemini-Modell ist für diesen Schlüssel nicht verfügbar.")
        raise SummaryError(f"Google meldet eine vorübergehende Störung (HTTP {response.status_code}). Drei Versuche sind fehlgeschlagen. Bitte später erneut versuchen.")
    try:
        candidate = response.json()["candidates"][0]
        if candidate.get("finishReason") != "STOP":
            raise ValueError("Incomplete response")
        text = "".join(part.get("text", "") for part in candidate["content"]["parts"])
        summaries = json.loads(text)["summaries"]
        if len(summaries) != len(keys) or {item["key"] for item in summaries} != set(keys):
            raise ValueError("Missing categories")
        if any(not isinstance(item["text"], str) or not item["text"].strip() for item in summaries):
            raise ValueError("Missing text")
        result = {item["key"]: item["text"] for item in summaries}
        try:
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
        except OSError:
            logger.warning("Could not persist Gemini summary cache")
        return result
    except (KeyError, IndexError, TypeError, ValueError):
        raise SummaryError("Die KI-Antwort war unvollständig. Bitte erneut versuchen.") from None
