import asyncio
import json
import requests
from playwright.async_api import async_playwright

payload = {
    "output": "page-content.children",
    "outputs": {"id": "page-content", "property": "children"},
    "inputs": [
        {"id": "url", "property": "pathname", "value": "/commodities"},
        {"id": "url", "property": "search", "value": ""},
    ],
    "changedPropIds": ["url.pathname"],
    "parsedChangedPropsIds": ["url.pathname"],
}
r = requests.post("http://127.0.0.1:8050/_dash-update-component", json=payload, timeout=60)
tree = r.json()

def find_store_data(node, target_id):
    if isinstance(node, dict):
        props = node.get("props", {})
        if isinstance(props.get("id"), dict) and props["id"].get("index") == target_id:
            return props.get("data")
        for v in node.values():
            found = find_store_data(v, target_id)
            if found is not None:
                return found
    elif isinstance(node, list):
        for item in node:
            found = find_store_data(item, target_id)
            if found is not None:
                return found
    return None

spec = find_store_data(tree, "commodity-index-chart")
print("spec series count:", len(spec["series"]) if spec else None)
print("first 3 data points:", spec["series"][0]["data"][:3] if spec else None)
print("last 3 data points:", spec["series"][0]["data"][-3:] if spec else None)
print("total points:", len(spec["series"][0]["data"]) if spec else None)

with open("scratch_spec.json", "w") as f:
    json.dump(spec, f)

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1400, "height": 1000})
        await page.goto("http://127.0.0.1:8050/commodities", wait_until="load", timeout=60000)
        await page.wait_for_timeout(3000)
        result = await page.evaluate("""
            (spec) => {
                try {
                    window.renderTVChart('commodity-index-chart', spec);
                    const el = document.getElementById('commodity-index-chart');
                    return 'OK children=' + el.children.length;
                } catch (e) {
                    return 'THREW: ' + e.message + '\\nSTACK: ' + e.stack;
                }
            }
        """, spec)
        print("RESULT:", result)
        await browser.close()

asyncio.run(main())
