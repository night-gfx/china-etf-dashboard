import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1400, "height": 1000})
        console_msgs = []
        page.on("console", lambda msg: console_msgs.append(f"[{msg.type}] {msg.text}"))
        page.on("pageerror", lambda exc: console_msgs.append(f"[pageerror] {exc}"))
        await page.goto("http://127.0.0.1:8050/commodities", wait_until="load", timeout=60000)
        await page.wait_for_timeout(4000)
        print("ALL CONSOLE:")
        for m in console_msgs:
            print(m)

        result = await page.evaluate("""
            () => {
                try {
                    const el = document.getElementById('commodity-index-chart');
                    if (!el) return 'no element found';
                    if (!window.renderTVChart) return 'renderTVChart missing';
                    window.renderTVChart('commodity-index-chart', {series:[{name:'Test', color:'#e0a458', data:[{time:'2020-01-01', value:100},{time:'2020-01-02', value:101}], type:'line', dashed:false, showLastValue:true}], height:420, logScale:false, valueFormat:'plain', showLegend:true, legendPosition:'top', hlines:[]});
                    return 'ok, children now: ' + el.children.length;
                } catch (e) {
                    return 'THREW: ' + e.message + ' | ' + e.stack;
                }
            }
        """)
        print("MANUAL RENDER RESULT:", result)
        await browser.close()

asyncio.run(main())
