import sys
sys.path.insert(0, ".")
from pages import commodities as c

prices = c.commodity_prices_usd.uncached()
available = [x["ticker"] for x in c.COMMODITY_UNIVERSE if x["ticker"] in prices.columns]
prices = prices.reindex(columns=available)
common = c._commodity_common_returns(prices)
port_ret, tw, cw = c._annual_rebalanced_index(common)

print("date range:", common.index.min(), "->", common.index.max())
print("n tickers:", len(common.columns))

# check weight right at each January reset (first row of each year) vs previous December
import pandas as pd
years = sorted(set(common.index.year))
for y in years[:6]:
    first_date = common.index[common.index.year == y][0]
    print(y, "first date", first_date.date(), "class weights:", cw.loc[first_date].round(4).to_dict())

print("---last few years---")
for y in years[-4:]:
    first_date = common.index[common.index.year == y][0]
    print(y, "first date", first_date.date(), "class weights:", cw.loc[first_date].round(4).to_dict())

print("row sums (should always be 1.0):", cw.sum(axis=1).min(), cw.sum(axis=1).max())
