import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1400, "height": 1000})
        errors = []
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
        page.on("pageerror", lambda exc: errors.append(str(exc)))
        await page.goto("http://127.0.0.1:8050/commodities", wait_until="load", timeout=60000)
        await page.wait_for_timeout(5000)
        print("ERRORS:", errors)
        loc = page.locator("#commodity-contribution-chart")
        await loc.scroll_into_view_if_needed()
        await page.wait_for_timeout(1000)
        await loc.screenshot(path="scratch_weight_chart.png")
        await page.screenshot(path="scratch_commodities_full.png", full_page=True)
        await browser.close()

asyncio.run(main())
