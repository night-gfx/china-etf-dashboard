import json
import requests

payload = {
    "output": "page-content.children",
    "outputs": {"id": "page-content", "property": "children"},
    "inputs": [
        {"id": "url", "property": "pathname", "value": "/commodities"},
        {"id": "url", "property": "search", "value": ""},
    ],
    "changedPropIds": ["url.pathname"],
    "parsedChangedPropsIds": ["url.pathname"],
}
r = requests.post("http://127.0.0.1:8050/_dash-update-component", json=payload, timeout=60)
text = r.text
idx = text.find("commodity-index-chart")
print("first occurrence idx:", idx)
print(text[max(0, idx-300): idx+1500])
