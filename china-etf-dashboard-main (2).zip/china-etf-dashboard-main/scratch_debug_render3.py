import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1400, "height": 1000})
        msgs = []
        page.on("console", lambda msg: msgs.append(f"[{msg.type}] {msg.text}"))
        page.on("pageerror", lambda exc: msgs.append(f"[pageerror] {exc}"))
        await page.goto("http://127.0.0.1:8050/commodities", wait_until="load", timeout=60000)
        await page.wait_for_timeout(12000)
        for m in msgs:
            print(m)
        info = await page.evaluate("""
            () => {
                const ids = ['commodity-index-chart','commodity-beta-chart','commodity-contribution-chart'];
                const out = {};
                ids.forEach(id => {
                    const el = document.getElementById(id);
                    out[id] = el ? el.children.length + ' children, html=' + el.innerHTML.slice(0,80) : 'MISSING';
                });
                return JSON.stringify(out, null, 2);
            }
        """)
        print(info)
        await browser.close()

asyncio.run(main())
