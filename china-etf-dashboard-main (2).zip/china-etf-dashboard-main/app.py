from __future__ import annotations

import datetime as dt
from urllib.parse import parse_qs

import dash
import dash_ag_grid  # Register table components before the first callback runs.
import dash_mantine_components as dmc
from dash import Dash, Input, Output, State, dcc, html
from dash_iconify import DashIconify

from src.cache import init_cache
from src.theme import ACCENT, ACCENT_OPTIONS, BG, DEFAULT_TAX, FONT_FAMILY, TEXT_MUTED
from pages import asset_allocation, china_dashboard, commodities, equities, equities_overview, overview, sp500_sectors
from pages.simple_asset_page import AssetClassPage

dash._dash_renderer._set_react_version("18.2.0")

bonds_page = AssetClassPage(
    "bonds", "Anleihen", "Staats- und Unternehmensanleihen im Überblick.",
    [
        {"label": "US Aggregate Bond", "sub": "AGG", "ticker": "AGG"},
        {"label": "US Treasury 20+Y", "sub": "TLT", "ticker": "TLT"},
        {"label": "US High Yield Corporate", "sub": "HYG", "ticker": "HYG"},
    ],
)
real_estate_page = AssetClassPage(
    "real-estate", "Immobilien", "Börsennotierte Immobilien (REITs), USA und international.",
    [
        {"label": "US Real Estate", "sub": "VNQ", "ticker": "VNQ"},
        {"label": "Internationale Immobilien", "sub": "RWX", "ticker": "RWX"},
    ],
)
hedge_funds_page = AssetClassPage(
    "hedge-funds", "Hedge Fonds", "Liquide Hedge-Fonds-Strategien als ETF-Proxy (Multi-Strategy).",
    [
        {"label": "Multi-Strategy", "sub": "QAI", "ticker": "QAI"},
        {"label": "Managed Futures", "sub": "DBMF", "ticker": "DBMF"},
    ],
)
crypto_page = AssetClassPage(
    "crypto", "Kryptowährungen", "Die größten Kryptowährungen nach Marktkapitalisierung.",
    [
        {"label": "Bitcoin", "sub": "BTC-USD", "ticker": "BTC-USD"},
        {"label": "Ethereum", "sub": "ETH-USD", "ticker": "ETH-USD"},
    ],
)
money_market_page = AssetClassPage(
    "money-market", "Geldmarkt", "Kurzlaufende Anleihen als Cash-Ersatz / risikoarme Verzinsung.",
    [
        {"label": "1-3M US T-Bills", "sub": "BIL", "ticker": "BIL"},
        {"label": "Ultrashort Bond", "sub": "MINT", "ticker": "MINT"},
    ],
)

NAV_TREE = [
    {"label": "Overview", "path": "/", "icon": "tabler:layout-dashboard"},
    {
        "label": "Aktien", "path": "/aktien", "icon": "tabler:chart-line", "group_id": "nav-group-aktien",
        "children": [
            {"label": "Länder", "icon": "tabler:world", "group_id": "nav-group-countries", "children": [
                {"label": "Länderübersicht", "path": "/laender", "icon": "tabler:world"},
                {"label": "China Markets", "path": "/china-markets", "icon": "tabler:chart-candle"},
            ]},
            {"label": "Sektoren", "icon": "tabler:building-bank", "group_id": "nav-group-sectors", "children": [
                {"label": "S&P 500 Sectors", "path": "/sp500-sectors", "icon": "tabler:building-bank"},
            ]},
        ],
    },
    {
        "label": "Anleihen", "icon": "tabler:certificate", "group_id": "nav-group-bonds",
        "children": [{"label": "Übersicht", "path": "/anleihen", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Commodities", "icon": "tabler:flask", "group_id": "nav-group-commodities",
        "children": [{"label": "Übersicht", "path": "/commodities", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Immobilien", "icon": "tabler:building-estate", "group_id": "nav-group-real-estate",
        "children": [{"label": "Übersicht", "path": "/immobilien", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Hedge Fonds", "icon": "tabler:chart-arrows", "group_id": "nav-group-hedge-funds",
        "children": [{"label": "Übersicht", "path": "/hedge-fonds", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Krypto", "icon": "tabler:currency-bitcoin", "group_id": "nav-group-crypto",
        "children": [{"label": "Übersicht", "path": "/krypto", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Geldmarkt", "icon": "tabler:cash", "group_id": "nav-group-money-market",
        "children": [{"label": "Übersicht", "path": "/geldmarkt", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Backtesting", "icon": "tabler:flask-2", "group_id": "nav-group-backtesting",
        "divider_label": "TOOLS",
        "children": [{"label": "Asset Allocation", "path": "/asset-allocation", "icon": "tabler:layout-grid-add"}],
    },
]

PAGES = {
    "/": overview,
    "/aktien": equities_overview,
    "/laender": equities,
    "/china-markets": china_dashboard,
    "/sp500-sectors": sp500_sectors,
    "/anleihen": bonds_page,
    "/commodities": commodities,
    "/immobilien": real_estate_page,
    "/hedge-fonds": hedge_funds_page,
    "/krypto": crypto_page,
    "/geldmarkt": money_market_page,
    "/asset-allocation": asset_allocation,
}

app = Dash(
    __name__,
    external_stylesheets=[
    ],
    external_scripts=[
        "https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js",
        "https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js",
    ],
    suppress_callback_exceptions=True,
    title="Market Dashboard",
)
init_cache(app)


def _nav_link(item, indent=False):
    return dcc.Link(
        dmc.Group(
            [
                DashIconify(icon=item["icon"], width=15, color=TEXT_MUTED, className="nav-icon"),
                dmc.Text(item["label"], size="sm", className="nav-label"),
            ],
            gap=10,
            wrap="nowrap",
            className="nav-link-inner",
        ),
        href=item["path"],
        id={"type": "nav-link", "path": item["path"]},
        className="nav-link nav-link-sub" if indent else "nav-link",
    )


def _nav_group(item):
    if item.get("path"):
        return html.Div([
            _nav_link(item),
            html.Div([
                _nav_group(c) if "children" in c else _nav_link(c, indent=True)
                for c in item["children"]
            ], style={"paddingLeft": "8px"}),
        ])
    return dmc.NavLink(
        label=dmc.Text(item["label"], size="sm", className="nav-label"),
        leftSection=DashIconify(icon=item["icon"], width=15, color=TEXT_MUTED, className="nav-icon"),
        childrenOffset=8,
        id={"type": "nav-group", "group_id": item["group_id"]},
        className="nav-group",
        children=[_nav_group(c) if "children" in c else _nav_link(c, indent=True) for c in item["children"]],
    )


def _nav_items():
    items = []
    for item in NAV_TREE:
        if item.get("divider_label"):
            items.append(dmc.Divider(
                label=dmc.Text(item["divider_label"], size="9px", c="dimmed", tt="uppercase", fw=700, style={"letterSpacing": "0.06em"}),
                labelPosition="left", my=6, color="var(--border)",
            ))
        if "children" in item:
            items.append(_nav_group(item))
        else:
            items.append(_nav_link(item))
    return items


def _settings_drawer():
    return dmc.Drawer(
        [
            dmc.Stack(
                [
                    dmc.Text("Darstellung", fw=700, size="sm", tt="uppercase", c="dimmed"),
                    dmc.SegmentedControl(
                        id="settings-theme",
                        data=[{"label": "Dunkel", "value": "dark"}, {"label": "Hell", "value": "light"}],
                        value="dark", fullWidth=True,
                        persistence=True, persistence_type="local",
                    ),
                    dmc.Space(h=4),
                    dmc.Text("Akzentfarbe", size="xs", c="dimmed"),
                    dmc.SegmentedControl(
                        id="settings-accent", fullWidth=True,
                        data=[
                            {
                                "label": html.Span(style={
                                    "display": "inline-block", "width": "14px", "height": "14px",
                                    "borderRadius": "50%", "backgroundColor": opt["hex"],
                                }),
                                "value": opt["key"],
                            }
                            for opt in ACCENT_OPTIONS
                        ],
                        value="orange", persistence=True, persistence_type="local",
                    ),
                    dmc.Divider(my="sm"),
                    dmc.Text("Steuerparameter (Deutschland)", fw=700, size="sm", tt="uppercase", c="dimmed"),
                    dmc.Text(
                        "Wirkt auf alle Nach-Steuer-Berechnungen im China ETF Dashboard.",
                        size="xs", c="dimmed",
                    ),
                    dmc.NumberInput(id="settings-tax-base", label="Kapitalertragsteuer", suffix=" %",
                                    min=0, max=60, step=0.5, value=DEFAULT_TAX["base_rate"],
                                    persistence=True, persistence_type="local"),
                    dmc.NumberInput(id="settings-tax-soli", label="Solidaritätszuschlag (auf Steuer)", suffix=" %",
                                    min=0, max=20, step=0.5, value=DEFAULT_TAX["soli"],
                                    persistence=True, persistence_type="local"),
                    dmc.NumberInput(id="settings-tax-teilfreistellung", label="Teilfreistellung Aktienfonds", suffix=" %",
                                    min=0, max=100, step=1, value=DEFAULT_TAX["teilfreistellung"],
                                    persistence=True, persistence_type="local"),
                    dmc.Text(id="settings-effective-tax", size="xs", c="dimmed"),
                    dmc.Button("Auf Standard zurücksetzen", id="settings-reset", variant="subtle",
                               color="gray", size="xs", mt="sm"),
                ],
                gap="xs",
            ),
        ],
        id="settings-drawer",
        title="Einstellungen",
        position="right",
        size="340px",
        opened=False,
    )


def _cmdk_overlay():
    return html.Div(
        [
            html.Div(className="cmdk-backdrop", id="cmdk-backdrop"),
            html.Div(
                [
                    DashIconify(icon="tabler:search", width=17, className="cmdk-search-icon"),
                    dcc.Input(
                        id="cmdk-input", type="text", autoComplete="off",
                        placeholder="Seiten, Indizes, ETFs, Rohstoffe durchsuchen…",
                        className="cmdk-input",
                    ),
                    html.Kbd("Esc", className="cmdk-esc"),
                ],
                className="cmdk-input-row",
            ),
            html.Div(id="cmdk-results", className="cmdk-results"),
        ],
        id="cmdk-overlay", className="cmdk-overlay",
    )


def build_layout():
    sidebar = dmc.AppShellNavbar(
        [
            dmc.Stack(_nav_items(), gap=2, p="xs"),
            dmc.Stack(
                [
                    dmc.Button(
                        [DashIconify(icon="tabler:command", width=15), dmc.Text("Suche", size="xs", ml=6)],
                        id="cmdk-open-btn", variant="default", size="xs", fullWidth=True,
                        leftSection=None, className="cmdk-open-btn",
                    ),
                    dmc.Text("Strg/Cmd + K", size="9px", c="dimmed", ta="center"),
                ],
                gap=2, p="xs", mt="auto",
            ),
        ],
        id="app-navbar", className="app-navbar",
        style={"display": "flex", "flexDirection": "column", "justifyContent": "space-between"},
    )

    header = dmc.AppShellHeader(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.Group(
                            [
                                dmc.ActionIcon(
                                    DashIconify(icon="tabler:menu-2", width=22),
                                    id="mobile-nav-toggle", className="mobile-nav-toggle",
                                    variant="subtle", color="gray", size="lg",
                                    **{"aria-label": "Navigation öffnen oder schließen"},
                                ),
                                dmc.ThemeIcon(
                                    DashIconify(icon="tabler:chart-dots-3", width=18, color=ACCENT),
                                    size=30, radius="var(--radius-sm)", variant="outline", color="gray", id="brand-icon",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("Market Dashboard", fw=700, size="sm", className="brand-title"),
                                    ],
                                    gap=0,
                                ),
                            ],
                            gap=10,
                        ),
                        dmc.Group(
                            [
                                dmc.Badge(id="live-badge", children="LIVE", color="gray", variant="outline", size="sm"),
                                dmc.ActionIcon(
                                    DashIconify(icon="tabler:settings", width=18),
                                    id="settings-open-btn", variant="subtle", color="gray", size="lg",
                                ),
                            ],
                            gap=10,
                        ),
                    ],
                    justify="space-between", px="lg", h=56,
                ),
                html.Div(id="kpi-ticker", className="kpi-ticker"),
            ],
            gap=0,
        ),
        className="app-header",
    )

    return dmc.AppShell(
        [
            header,
            sidebar,
            dmc.AppShellMain(html.Div(id="page-content", className="page-content")),
        ],
        header={"height": 92},
        navbar={"width": 232, "breakpoint": "sm", "collapsed": {"mobile": True}},
        padding="lg",
        className="app-shell",
        id="app-shell",
    )


app.layout = dmc.MantineProvider(
    [
        dcc.Location(id="url", refresh=False),
        dcc.Interval(id="live-interval", interval=90 * 1000, n_intervals=0),
        dcc.Store(id="theme-css-sync"),
        dcc.Store(id="tv-chart-sync"),
        dcc.Store(id="echart-sync"),
        build_layout(),
        _settings_drawer(),
        _cmdk_overlay(),
    ],
    id="mantine-provider",
    theme={
        "fontFamily": FONT_FAMILY,
        "primaryColor": "orange",
        "colors": {
            "dark": [
                "#e6e8ee", "#c7ccd6", "#9aa1b0", "#767e91", "#565f75",
                "#3a4256", "#242b3a", "#171c28", "#12161f", BG,
            ],
        },
    },
    forceColorScheme="dark",
)

for module in (
    overview, equities, china_dashboard, asset_allocation, sp500_sectors, commodities,
    bonds_page, real_estate_page, hedge_funds_page, crypto_page, money_market_page,
):
    module.register_callbacks(app)


def _parse_search(search):
    if not search:
        return {}
    return {k: v[0] for k, v in parse_qs(search.lstrip("?")).items()}


@app.callback(Output("app-shell", "navbar"), Input("mobile-nav-toggle", "n_clicks"),
              Input("url", "pathname"), State("app-shell", "navbar"), prevent_initial_call=True)
def toggle_mobile_navigation(clicks, pathname, navbar):
    navbar = dict(navbar)
    closed = navbar.get("collapsed", {}).get("mobile", True)
    navbar["collapsed"] = {"mobile": not closed if dash.ctx.triggered_id == "mobile-nav-toggle" else True}
    return navbar


@app.callback(Output("page-content", "children"), Input("url", "pathname"), Input("url", "search"))
def render_page(pathname, search):
    module = PAGES.get(pathname, overview)
    return module.layout(_parse_search(search))


def _group_paths(items):
    groups = {}
    for item in items:
        if "children" in item:
            nested = _group_paths(item["children"])
            groups.update(nested)
            groups[item["group_id"]] = [c["path"] for c in item["children"] if "path" in c]
            for paths in nested.values():
                groups[item["group_id"]].extend(paths)
    return groups


NAV_GROUP_CHILD_PATHS = _group_paths(NAV_TREE)


@app.callback(
    Output({"type": "nav-group", "group_id": dash.ALL}, "opened"),
    Input("url", "pathname"),
)
def open_active_nav_groups(pathname):
    return [pathname in NAV_GROUP_CHILD_PATHS.get(item["id"]["group_id"], [])
            for item in dash.callback_context.outputs_list]


@app.callback(
    Output({"type": "nav-link", "path": dash.ALL}, "className"),
    Input("url", "pathname"),
)
def highlight_active_nav(pathname):
    result = []
    for item in dash.callback_context.outputs_list:
        path = item["id"]["path"]
        active = path == pathname or (path == "/" and pathname is None)
        indented = any(path in paths for paths in NAV_GROUP_CHILD_PATHS.values())
        classes = "nav-link"
        if indented:
            classes += " nav-link-sub"
        if active:
            classes += " nav-link-active"
        result.append(classes)
    return result


@app.callback(
    Output({"type": "nav-group", "group_id": dash.ALL}, "active"),
    Input("url", "pathname"),
)
def highlight_nav_group(pathname):
    result = []
    for item in dash.callback_context.outputs_list:
        group_id = item["id"]["group_id"]
        result.append(pathname in NAV_GROUP_CHILD_PATHS.get(group_id, []))
    return result


# ---------------------------------------------------------------------------
# TradingView Lightweight Charts: one generic clientside callback renders
# every chart on the page whenever its data Store changes (pattern-matched,
# so individual pages never need to wire their own clientside callback).
# ---------------------------------------------------------------------------

app.clientside_callback(
    """
    function(dataList, idsList) {
        (dataList || []).forEach(function (data, i) {
            if (data && window.renderTVChart && idsList[i]) {
                window.renderTVChart(idsList[i].index, data);
            }
        });
        return "";
    }
    """,
    Output("tv-chart-sync", "data"),
    Input({"type": "tv-chart-data", "index": dash.ALL}, "data"),
    State({"type": "tv-chart-data", "index": dash.ALL}, "id"),
)

app.clientside_callback(
    """
    function(dataList, idsList) {
        (dataList || []).forEach(function (data, i) {
            if (data && window.renderEChart && idsList[i]) {
                window.renderEChart(idsList[i].index, data);
            }
        });
        return "";
    }
    """,
    Output("echart-sync", "data"),
    Input({"type": "echart-data", "index": dash.ALL}, "data"),
    State({"type": "echart-data", "index": dash.ALL}, "id"),
)

# ---------------------------------------------------------------------------
# Settings drawer: open/close, theme + accent + tax
# ---------------------------------------------------------------------------

@app.callback(
    Output("settings-drawer", "opened"),
    Input("settings-open-btn", "n_clicks"),
    State("settings-drawer", "opened"),
    prevent_initial_call=True,
)
def toggle_settings(_n, opened):
    return not opened


@app.callback(
    Output("mantine-provider", "forceColorScheme"),
    Input("settings-theme", "value"),
)
def apply_theme(theme):
    return theme or "dark"


@app.callback(
    Output("mantine-provider", "theme"),
    Input("settings-accent", "value"),
    State("mantine-provider", "theme"),
)
def apply_accent(accent, theme):
    theme = dict(theme or {})
    theme["primaryColor"] = accent or "orange"
    return theme


app.clientside_callback(
    """
    function(theme, accent) {
        const opt = {"orange": "#e0a458", "blue": "#5b9bd5", "teal": "#3ecf8e", "grape": "#c084fc", "red": "#f0616d"};
        document.documentElement.setAttribute('data-theme', theme || 'dark');
        document.documentElement.style.setProperty('--accent', opt[accent] || opt.orange);
        return "";
    }
    """,
    Output("theme-css-sync", "data"),
    Input("settings-theme", "value"),
    Input("settings-accent", "value"),
)


@app.callback(
    Output("settings-effective-tax", "children"),
    Input("settings-tax-base", "value"),
    Input("settings-tax-soli", "value"),
    Input("settings-tax-teilfreistellung", "value"),
)
def show_effective_tax(base, soli, teilfreistellung):
    try:
        rate = (base / 100.0) * (1 + soli / 100.0) * (1 - teilfreistellung / 100.0)
        return f"Effektiver Steuersatz auf positive Gewinne: {rate:.2%}"
    except Exception:
        return ""


@app.callback(
    Output("settings-theme", "value"),
    Output("settings-accent", "value"),
    Output("settings-tax-base", "value"),
    Output("settings-tax-soli", "value"),
    Output("settings-tax-teilfreistellung", "value"),
    Input("settings-reset", "n_clicks"),
    prevent_initial_call=True,
)
def reset_settings(_n):
    return "dark", "orange", DEFAULT_TAX["base_rate"], DEFAULT_TAX["soli"], DEFAULT_TAX["teilfreistellung"]


# Command palette open/close and filtering runs entirely client-side (see
# assets/cmdk.js) so the keyboard shortcut and the sidebar button never fight
# over server round-trips.


# ---------------------------------------------------------------------------
# Live badge + KPI ticker
# ---------------------------------------------------------------------------

TICKER_SPECS = [
    {"label": "CSI 300", "kind": "index", "ref": "CSI 300"},
    {"label": "MSCI China A", "kind": "index", "ref": "MSCI China A"},
    {"label": "S&P 500", "kind": "sector_bench", "ref": "SPY"},
    {"label": "Gold", "kind": "commodity", "ref": "GC=F"},
    {"label": "WTI Crude", "kind": "commodity", "ref": "CL=F"},
]


def _pct_change(series):
    s = series.dropna()
    if len(s) < 2:
        return None, None
    return float(s.iloc[-1]), float(s.iloc[-1] / s.iloc[-2] - 1.0)


def _ticker_item(label, value, change):
    if value is None:
        return dmc.Group([dmc.Text(label, size="xs", c="dimmed"), dmc.Text("–", size="xs", c="dimmed")],
                          gap=6, className="kpi-item", wrap="nowrap")
    up = change is not None and change >= 0
    color = "teal" if up else "red"
    arrow = "tabler:arrow-up-right" if up else "tabler:arrow-down-right"
    return dmc.Group(
        [
            dmc.Text(label, size="xs", c="dimmed"),
            dmc.Text(f"{value:,.2f}", size="xs", fw=700, className="kpi-value"),
            dmc.Group(
                [DashIconify(icon=arrow, width=12, color=f"var(--mantine-color-{color}-5)"),
                 dmc.Text(f"{change:+.2%}" if change is not None else "–", size="xs", c=color)],
                gap=2,
            ) if change is not None else None,
        ],
        gap=8, className="kpi-item", wrap="nowrap",
    )


@app.callback(
    Output("kpi-ticker", "children"),
    Output("live-badge", "children"),
    Input("live-interval", "n_intervals"),
)
def update_ticker(_n):
    items = []
    for spec in TICKER_SPECS:
        try:
            if spec["kind"] == "index":
                resolved, error = china_dashboard.resolve_index_cached(spec["ref"])
                value, change = (_pct_change(resolved.series_eur) if resolved is not None else (None, None))
            elif spec["kind"] == "sector_bench":
                raw = sp500_sectors.sector_prices_usd()
                series = raw.get(spec["ref"])
                value, change = _pct_change(series) if series is not None else (None, None)
            else:
                prices = commodities.commodity_prices_usd()
                series = prices[spec["ref"]] if spec["ref"] in prices.columns else None
                value, change = _pct_change(series) if series is not None else (None, None)
        except Exception:
            value, change = None, None
        items.append(_ticker_item(spec["label"], value, change))

    now = dt.datetime.now().strftime("%H:%M:%S")
    badge = [DashIconify(icon="tabler:circle-filled", width=8), dmc.Text(f"LIVE · {now}", size="xs", ml=4)]
    return items, badge


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8050, threaded=True)
