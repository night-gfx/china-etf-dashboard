import asyncio
import json
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="msedge", headless=True)
        page = await browser.new_page(viewport={"width": 1500, "height": 1100})
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        await page.goto("http://127.0.0.1:8050/", wait_until="domcontentloaded")
        await page.locator("#overview-chart canvas").first.wait_for(timeout=90000)
        await page.wait_for_function("document.querySelectorAll('#overview-chart .tv-legend-row').length === 7")
        assert await page.get_by_text("Ein Blick über alle wichtigen Anlageklassen", exact=False).count() == 0
        await page.locator("#overview-range").get_by_text("3J", exact=True).click()
        await page.wait_for_function("document.getElementById('overview-chart')._lastSpec.series[0].data.length < 900")
        expected = await page.locator("#overview-chart").evaluate("el => el._lastSpec.series[0].data.length")
        await page.locator('a.stat-card-link[href="/anleihen"]').click()
        await page.wait_for_function("!document.getElementById('overview-chart')")
        await page.go_back()
        await page.locator("#overview-chart canvas").first.wait_for(timeout=90000)
        await page.wait_for_function("n => document.getElementById('overview-chart')._lastSpec.series[0].data.length === n", arg=expected)
        styles = await page.locator(".stat-label").first.evaluate("el => ({font:getComputedStyle(el).fontFamily, weight:getComputedStyle(el).fontWeight})")
        assert "Arial" in styles["font"] and int(styles["weight"]) >= 700, styles
        await page.screenshot(path="scratch_overview_updated.png", full_page=True)
        await page.set_viewport_size({"width": 390, "height": 844})
        await page.wait_for_timeout(500)
        assert await page.locator("#overview-chart canvas").first.is_visible()
        await page.screenshot(path="scratch_overview_mobile.png", full_page=True)
        print(json.dumps({"navigation": "passed", "persisted_range_points": expected, "styles": styles, "page_errors": errors}))
        assert not errors, errors
        await browser.close()


asyncio.run(main())
