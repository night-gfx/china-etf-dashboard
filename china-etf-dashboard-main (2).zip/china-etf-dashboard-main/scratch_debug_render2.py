import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1400, "height": 1000})
        await page.goto("http://127.0.0.1:8050/commodities", wait_until="load", timeout=60000)
        await page.wait_for_timeout(4000)
        html = await page.content()
        idx = html.find("commodity-index-chart")
        print("found at", idx)
        print(html[max(0,idx-200):idx+500] if idx >= 0 else "NOT IN HTML AT ALL")

        # count all ids matching commodity- prefix
        import re
        ids = re.findall(r'id="([^"]*commodity[^"]*)"', html)
        print("commodity ids found:", ids)
        await browser.close()

asyncio.run(main())
