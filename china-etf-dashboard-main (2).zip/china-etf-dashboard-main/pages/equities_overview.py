from __future__ import annotations

import dash_mantine_components as dmc
from dash import dcc, html
from dash_iconify import DashIconify


def _category(title, description, icon, href, links):
    return html.Div([
        dcc.Link([
            DashIconify(icon=icon, width=32, className="equity-category-icon"),
            dmc.Title(title, order=4),
            dmc.Text(description, size="sm", c="dimmed"),
        ], href=href, className="equity-category-link"),
        html.Div([
            html.Div([
                dcc.Link([
                    DashIconify(icon=link_icon, width=18),
                    html.Span(label),
                ], href=path, className="equity-subpage-link")
                for label, path, link_icon in links
            ], className="equity-subpages"),
        ], className="equity-category-details"),
    ], className="equity-category section-card")


def layout(params=None):
    return html.Div([
        dmc.Title("Aktien", order=3, mb="xs"),
        dmc.SimpleGrid([
            _category("Länder", "Globale Aktienmärkte vergleichen und einzelne Länder entdecken.",
                      "tabler:world", "/laender", [
                          ("Länderübersicht", "/laender", "tabler:world"),
                          ("China Markets", "/china-markets", "tabler:chart-candle"),
                      ]),
            _category("Sektoren", "Branchen vergleichen und die Sektoren des S&P 500 analysieren.",
                      "tabler:building-bank", "/sp500-sectors", [
                          ("S&P 500 Sectors", "/sp500-sectors", "tabler:building-bank"),
                      ]),
        ], cols={"base": 1, "sm": 2}, spacing="md"),
    ])
