from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import dash_mantine_components as dmc
import pandas as pd
from dash import Input, Output, dcc, html

from src.cache import LONG_TTL, cache
from src.data import download_adjusted_close
from src.metrics import annual_volatility, cagr, max_drawdown
from src.theme import (
    DOWN, PALETTE, UP,
    ag_heat_table, card_header, sparkline_figure, tv_chart, tv_series, tv_spec,
)

RANGE_OPTIONS = [
    {"label": "1J", "value": "1"}, {"label": "3J", "value": "3"}, {"label": "5J", "value": "5"},
    {"label": "10J", "value": "10"}, {"label": "Max", "value": "max"},
]


@cache.memoize(timeout=LONG_TTL)
def _series(ticker: str) -> pd.Series:
    try:
        return download_adjusted_close(ticker, start="2000-01-01")
    except Exception:
        return pd.Series(dtype=float)


def _filtered(series: pd.Series, years) -> pd.Series:
    s = series.dropna()
    if s.empty or years == "max":
        return s
    cutoff = pd.Timestamp.now() - pd.DateOffset(years=int(years))
    return s[s.index >= cutoff]


def _card(title, children):
    return html.Div([html.Div(title, className="section-title"), *children], className="section-card")


class AssetClassPage:
    """A reusable, self-contained single-page view for a broad asset class:
    stat cards, an indexed comparison chart, and a metrics table for a
    small curated list of representative tickers."""

    def __init__(self, slug: str, title: str, description: str, items: list[dict]):
        self.slug = slug
        self.title = title
        self.description = description
        self.items = items
        self.range_id = f"{slug}-range"
        self.chart_id = f"{slug}-chart"
        self.table_id = f"{slug}-table"

    def _spec(self, years):
        series_list = []
        for i, item in enumerate(self.items):
            s = _filtered(_series(item["ticker"]), years)
            if len(s) < 2:
                continue
            indexed = s / s.iloc[0] * 100.0
            series_list.append(tv_series(item["label"], indexed, PALETTE[i % len(PALETTE)]))
        return tv_spec(series_list, height=460, log_scale=True, value_format="ratio", rebase_visible=True)

    def _stat_cards(self):
        cards = []
        for item in self.items:
            s = _filtered(_series(item["ticker"]), "1").dropna()
            if len(s) < 2:
                cards.append(dmc.Paper(dmc.Text(f"{item['label']}: keine Daten", size="xs", c="dimmed"),
                                        p="md", radius="md", withBorder=True, className="stat-card"))
                continue
            ret = float(s.iloc[-1] / s.iloc[0] - 1.0)
            color = UP if ret >= 0 else DOWN
            cards.append(dmc.Paper(
                [
                    dmc.Group([
                        dmc.Stack([
                            dmc.Text(item["label"].upper(), className="stat-label"),
                            dmc.Text(item.get("sub", item["ticker"]), size="10px", c="dimmed"),
                        ], gap=0),
                        dmc.Text(f"{ret:+.1%}", size="lg", fw=700, c=("teal" if ret >= 0 else "red")),
                    ], justify="space-between", align="flex-start"),
                    dcc.Graph(figure=sparkline_figure(s.tail(252), color), config={"staticPlot": True},
                              style={"height": "40px", "marginTop": "6px"}),
                ],
                p="md", radius="md", withBorder=True, className="stat-card",
            ))
        return cards

    def _metrics_table(self, years):
        rows = {}
        for item in self.items:
            s = _filtered(_series(item["ticker"]), years).dropna()
            if len(s) < 2:
                continue
            cg, dd = cagr(s), max_drawdown(s)
            rows[item["label"]] = {
                "Gesamtrendite": float(s.iloc[-1] / s.iloc[0] - 1.0),
                "CAGR p.a.": cg,
                "Volatilität p.a.": annual_volatility(s),
                "Max. Drawdown": dd,
                "Calmar": cg / abs(dd) if dd and dd == dd and dd != 0 else None,
            }
        df = pd.DataFrame.from_dict(rows, orient="index")
        if df.empty:
            return dmc.Text("Keine Daten verfügbar.", size="sm", c="dimmed")
        return ag_heat_table(df, reverse_columns={"Volatilität p.a.", "Max. Drawdown"})

    def layout(self, params=None):
        with ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(_series, [item["ticker"] for item in self.items]))
        cols = {"base": 2, "sm": min(3, len(self.items)), "md": len(self.items)}
        return html.Div([
            dmc.Title(self.title, order=3, mb="xs"),
            dmc.Text(self.description, size="sm", c="dimmed", mb="md"),
            dmc.SimpleGrid(self._stat_cards(), cols=cols, spacing="sm", mb="md"),
            html.Div([
                card_header("Wertentwicklung", dmc.SegmentedControl(
                    id=self.range_id, data=RANGE_OPTIONS, value="5", size="xs",
                    persistence=True, persistence_type="session",
                )),
                tv_chart(self.chart_id, self._spec("5")),
            ], className="section-card"),
            _card("Kennzahlen", [html.Div(id=self.table_id, children=self._metrics_table("5"))]),
        ])

    def register_callbacks(self, app):
        @app.callback(
            Output({"type": "tv-chart-data", "index": self.chart_id}, "data"),
            Output(self.table_id, "children"),
            Input(self.range_id, "value"),
        )
        def _update(years):
            return self._spec(years), self._metrics_table(years)
