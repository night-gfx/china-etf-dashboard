from __future__ import annotations

import math

import dash
import dash_mantine_components as dmc
import numpy as np
import pandas as pd
import yfinance as yf
from dash import Input, Output, State, dcc, html

from src.cache import LONG_TTL, cache
from src.metrics import cagr, max_drawdown, sortino
from src.theme import (
    PALETTE, SURFACE_2, TEXT_MUTED, TEXT_MUTED_LIGHT,
    ag_heat_table, ag_table, cell_color, echart, tv_chart, tv_marker, tv_series, tv_spec,
)

SECTOR_ETFS = [
    {"sector": "Communication Services", "ticker": "XLC", "inception": "18.06.2018"},
    {"sector": "Consumer Discretionary", "ticker": "XLY", "inception": "16.12.1998"},
    {"sector": "Consumer Staples", "ticker": "XLP", "inception": "16.12.1998"},
    {"sector": "Energy", "ticker": "XLE", "inception": "16.12.1998"},
    {"sector": "Financials", "ticker": "XLF", "inception": "16.12.1998"},
    {"sector": "Health Care", "ticker": "XLV", "inception": "16.12.1998"},
    {"sector": "Industrials", "ticker": "XLI", "inception": "16.12.1998"},
    {"sector": "Information Technology", "ticker": "XLK", "inception": "16.12.1998"},
    {"sector": "Materials", "ticker": "XLB", "inception": "16.12.1998"},
    {"sector": "Real Estate", "ticker": "XLRE", "inception": "07.10.2015"},
    {"sector": "Utilities", "ticker": "XLU", "inception": "16.12.1998"},
]
SECTOR_BENCHMARK = {"sector": "S&P 500", "ticker": "SPY", "inception": "22.01.1993"}
SECTOR_LABELS = {x["ticker"]: f"{x['sector']} ({x['ticker']})" for x in SECTOR_ETFS}
SECTOR_LABELS["SPY"] = "S&P 500 (SPY)"
SECTOR_BENCHMARK_LABEL = "S&P 500 (SPY)"
EXCLUDED_SECTOR_TICKERS = {"XLC", "XLRE"}
ACTIVE_SECTOR_COLORS = {
    SECTOR_LABELS[item["ticker"]]: PALETTE[i % len(PALETTE)]
    for i, item in enumerate(SECTOR_ETFS) if item["ticker"] not in EXCLUDED_SECTOR_TICKERS
}


@cache.memoize(timeout=LONG_TTL)
def sector_prices_usd():
    tickers = [x["ticker"] for x in SECTOR_ETFS] + [SECTOR_BENCHMARK["ticker"]]
    raw = yf.download(tickers=tickers, start="1990-01-01", auto_adjust=False, actions=False,
                       progress=False, threads=True, timeout=30)
    if raw is None or raw.empty:
        return {}
    if isinstance(raw.columns, pd.MultiIndex):
        first = raw.columns.get_level_values(0)
        prices = raw["Adj Close"] if "Adj Close" in first else raw["Close"] if "Close" in first else None
        if prices is None:
            return {}
    else:
        col = "Adj Close" if "Adj Close" in raw.columns else "Close" if "Close" in raw.columns else None
        if col is None:
            return {}
        prices = raw[[col]].rename(columns={col: tickers[0]})
    if isinstance(prices, pd.Series):
        prices = prices.to_frame()
    if isinstance(prices.index, pd.DatetimeIndex):
        if prices.index.tz is not None:
            prices.index = prices.index.tz_localize(None)
        prices.index = prices.index.normalize()
    result = {}
    for ticker in tickers:
        if ticker not in prices.columns:
            continue
        s = pd.to_numeric(prices[ticker], errors="coerce").dropna()
        s = s[~s.index.duplicated(keep="last")].sort_index()
        if len(s) >= 30:
            result[ticker] = s.rename(SECTOR_LABELS[ticker])
    return result


def _available_sector_series(raw):
    if not raw or "SPY" not in raw:
        return {}
    benchmark = pd.to_numeric(raw.get("SPY"), errors="coerce").dropna().sort_index()
    if benchmark.empty:
        return {}
    series = {SECTOR_BENCHMARK_LABEL: benchmark}
    for item in SECTOR_ETFS:
        ticker = item["ticker"]
        if ticker in EXCLUDED_SECTOR_TICKERS:
            continue
        raw_series = raw.get(ticker)
        if raw_series is None:
            continue
        s = pd.to_numeric(raw_series, errors="coerce").dropna().sort_index()
        if s.empty:
            continue
        series[SECTOR_LABELS[ticker]] = s
    if len(series) <= 1:
        return {}
    frame = pd.concat(series, axis=1, join="inner").dropna(how="any").sort_index()
    if frame.empty:
        return {}
    return {col: frame[col].copy() for col in frame.columns}


def _indexed_individually(series_map):
    pieces = []
    for label, series in series_map.items():
        s = series.dropna()
        if s.empty:
            continue
        pieces.append((s / s.iloc[0] * 100.0).rename(label))
    return pd.concat(pieces, axis=1).sort_index() if pieces else pd.DataFrame()


def _sector_performance_spec(frame):
    series_list = []
    for i, col in enumerate(frame.columns):
        is_bm = col == SECTOR_BENCHMARK_LABEL
        color = "#8a93a6" if is_bm else PALETTE[i % len(PALETTE)]
        series_list.append(tv_series(col, frame[col], color, dashed=is_bm, line_width=2.4 if is_bm else 1.6))
    return tv_spec(series_list, height=460, log_scale=True, value_format="ratio", rebase_visible=True)


def _sector_drawdown_spec(series_map):
    series_list = []
    for i, (label, series) in enumerate(series_map.items()):
        s = series.dropna()
        dd = (s / s.cummax() - 1.0) * 100.0
        is_bm = label == SECTOR_BENCHMARK_LABEL
        color = "#8a93a6" if is_bm else PALETTE[i % len(PALETTE)]
        series_list.append(tv_series(label, dd, color, dashed=is_bm, line_width=2.4 if is_bm else 1.6))
    return tv_spec(series_list, height=460, value_format="percent")


def _sector_correlation_option(series_map):
    returns = pd.DataFrame({k: v.pct_change(fill_method=None) for k, v in series_map.items()})
    corr = returns.corr(min_periods=126)
    names = list(corr.columns)
    data = []
    for i in range(len(names)):
        for j in range(len(names)):
            v = corr.values[i, j]
            data.append([j, i, None if pd.isna(v) else round(float(v), 2)])
    return {
        "grid": {"left": 130, "right": 15, "top": 10, "bottom": 90},
        "xAxis": {"type": "category", "data": names, "axisLabel": {"rotate": 45, "fontSize": 9}, "splitArea": {"show": True}},
        "yAxis": {"type": "category", "data": names, "axisLabel": {"fontSize": 9}, "splitArea": {"show": True}},
        "visualMap": {"min": -1, "max": 1, "show": False, "inRange": {"color": ["#c0392b", "#3a3320", "#1f7a4d"]}},
        "tooltip": {"position": "top"},
        "series": [{"type": "heatmap", "data": data, "label": {"show": True, "fontSize": 9, "color": "#111827"},
                    "emphasis": {"itemStyle": {"borderColor": "#e6e8ee", "borderWidth": 1.5}}}],
    }


def _sector_rolling_corr_spec(series_map):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None:
        return tv_spec([])
    benchmark_returns = benchmark.pct_change(fill_method=None)
    series_list = []
    for i, (label, series) in enumerate(series_map.items()):
        if label == SECTOR_BENCHMARK_LABEL:
            continue
        aligned = pd.concat([series.pct_change(fill_method=None).rename("s"), benchmark_returns.rename("b")], axis=1).dropna()
        if aligned.empty:
            continue
        rolling = aligned["s"].rolling(252, min_periods=126).corr(aligned["b"])
        series_list.append(tv_series(label, rolling, PALETTE[i % len(PALETTE)], show_last_value=False))
    return tv_spec(series_list, height=460, value_format="ratio", hlines=[{"value": 0, "label": "0"}])


def _rolling_relative_return_diff(series_map, lookback_months):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None:
        return pd.DataFrame()
    periods = max(int(round(float(lookback_months) * 21)), 1)
    benchmark_return = benchmark / benchmark.shift(periods) - 1.0
    data = {}
    for label, series in series_map.items():
        if label == SECTOR_BENCHMARK_LABEL:
            continue
        sector_return = series / series.shift(periods) - 1.0
        data[label] = (sector_return - benchmark_return) * 100.0
    return pd.DataFrame(data).dropna(how="all")


def _rolling_relative_return_spec(diff_frame, lookback_months):
    series_list = []
    for label in diff_frame.columns:
        s = pd.to_numeric(diff_frame[label], errors="coerce").dropna()
        if s.empty:
            continue
        color = ACTIVE_SECTOR_COLORS.get(label, "#9ca3af")
        series_list.append(tv_series(label, s, color, show_last_value=False))
    return tv_spec(series_list, height=460, value_format="pp", hlines=[{"value": 0, "label": "0"}])


def _all_sector_forward_relative_return_option(series_map, current_diff, forward_months, min_months):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if benchmark is None or current_diff.empty:
        return None
    max_months = int(forward_months)
    min_months = max(1, min(int(min_months), max_months))
    min_periods = max(int(round(float(min_months) * 21)), 1)
    max_periods = max(int(round(float(max_months) * 21)), min_periods)
    base_index = pd.DatetimeIndex(current_diff.index)
    benchmark_aligned = pd.to_numeric(benchmark.reindex(base_index), errors="coerce")
    n = len(base_index)
    if n <= max_periods:
        return None
    usable_n = n - max_periods
    current_dates = base_index[:usable_n]
    benchmark_values = benchmark_aligned.to_numpy(dtype=float)
    benchmark_start = benchmark_values[:usable_n]

    series = []
    points_found = False
    for label in current_diff.columns:
        sector = series_map.get(label)
        if sector is None:
            continue
        sector_aligned = pd.to_numeric(sector.reindex(base_index), errors="coerce")
        sector_values = sector_aligned.to_numpy(dtype=float)
        sector_start = sector_values[:usable_n]
        max_forward = np.full(usable_n, -np.inf, dtype=float)
        has_value = np.zeros(usable_n, dtype=bool)
        with np.errstate(divide="ignore", invalid="ignore"):
            for offset in range(min_periods, max_periods + 1):
                sector_future = sector_values[offset:offset + usable_n]
                benchmark_future = benchmark_values[offset:offset + usable_n]
                forward_diff = (sector_future / sector_start - benchmark_future / benchmark_start) * 100.0
                valid = np.isfinite(forward_diff)
                better = valid & ((~has_value) | (forward_diff > max_forward))
                max_forward[better] = forward_diff[better]
                has_value |= valid
        max_forward[~has_value] = np.nan
        current_values = pd.to_numeric(current_diff[label].reindex(current_dates), errors="coerce").to_numpy(dtype=float)
        valid_points = np.isfinite(current_values) & np.isfinite(max_forward)
        if not valid_points.any():
            continue
        points_found = True
        color = ACTIVE_SECTOR_COLORS.get(label, "#9ca3af")
        points = list(zip(
            np.round(current_values[valid_points], 2).tolist(),
            np.round(max_forward[valid_points], 2).tolist(),
        ))
        series.append({
            "name": label, "type": "scatter", "symbolSize": 5,
            "itemStyle": {"color": color, "opacity": 0.45},
            "data": points,
        })
    if not points_found:
        return None
    return {
        "grid": {"left": 55, "right": 20, "top": 10, "bottom": 70},
        "xAxis": {"type": "value", "name": "Aktuelle Renditedifferenz in %-Pkt.", "nameLocation": "middle", "nameGap": 30,
                  "axisLine": {"show": True}, "splitLine": {"show": False}},
        "yAxis": {"type": "value", "name": f"Max. Fwd.-Diff. {min_months}-{max_months}M in %-Pkt.",
                  "nameLocation": "middle", "nameGap": 45, "axisLine": {"show": True}},
        "legend": {"bottom": 0, "type": "scroll"},
        "tooltip": {"trigger": "item", "formatter": "{a}<br/>x: {c[0]} %-Pkt.<br/>y: {c[1]} %-Pkt."},
        "series": series,
    }


def _sector_metrics(series_map):
    rows = {}
    for label, series in series_map.items():
        s = series.dropna()
        if len(s) < 2:
            continue
        returns = s.pct_change(fill_method=None).dropna()
        cg = cagr(s)
        vola = returns.std(ddof=1) * math.sqrt(252) if len(returns) > 1 else np.nan
        shp = returns.mean() / returns.std(ddof=1) * math.sqrt(252) if len(returns) > 1 and returns.std(ddof=1) != 0 else np.nan
        dd = max_drawdown(s)
        srt = sortino(s, 0.0)
        rows[label] = {"CAGR p.a.": cg, "Volatilität p.a.": vola, "Sharpe Ratio": shp,
                       "Max. Drawdown": dd, "Sortino": srt, "Calmar": cg / abs(dd) if dd and not np.isnan(dd) else np.nan}
    return pd.DataFrame.from_dict(rows, orient="index")


def _sharpe0(s):
    r = s.dropna().pct_change(fill_method=None).dropna()
    if len(r) < 2 or r.std(ddof=1) == 0:
        return np.nan
    return r.mean() / r.std(ddof=1) * math.sqrt(252)


def _sector_annual_sharpe(series_map):
    years = sorted({int(y) for s in series_map.values() for y in s.dropna().index.year})
    rows = {}
    for label, series in series_map.items():
        row = {}
        s = series.dropna()
        for year in years:
            sy = s[s.index.year == year]
            row[str(year)] = _sharpe0(sy) if len(sy) >= 20 else np.nan
        rows[label] = row
    return pd.DataFrame.from_dict(rows, orient="index")


def _single_sector_12m_diff(series_map, sector_label):
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    sector = series_map.get(sector_label)
    if benchmark is None or sector is None:
        return pd.Series(dtype=float)
    periods = 252
    benchmark_return = benchmark / benchmark.shift(periods) - 1.0
    sector_return = sector / sector.shift(periods) - 1.0
    return ((sector_return - benchmark_return) * 100.0).dropna()


def _two_year_block_troughs(diff_series):
    s = pd.to_numeric(diff_series, errors="coerce").dropna().sort_index()
    if s.empty:
        return []
    first_date, last_date = pd.Timestamp(s.index.min()), pd.Timestamp(s.index.max())
    block_start, events = first_date, []
    while block_start <= last_date:
        block_end = block_start + pd.DateOffset(years=2)
        block = s.loc[(s.index >= block_start) & (s.index < block_end)]
        if not block.empty:
            trough_date = pd.Timestamp(block.idxmin())
            events.append({"block_start": block_start, "block_end": min(block_end - pd.Timedelta(days=1), last_date),
                            "date": trough_date, "signal": float(block.loc[trough_date])})
        block_start = block_end
    return events


def _single_sector_diff_spec(diff_series, sector_label, events, selected_event_idx):
    s = pd.to_numeric(diff_series, errors="coerce").dropna()
    if s.empty:
        return None
    color = ACTIVE_SECTOR_COLORS.get(sector_label, "#9ca3af")
    markers = []
    if events:
        idx = max(0, min(int(selected_event_idx), len(events) - 1))
        for i, e in enumerate(events):
            selected = i == idx
            markers.append(tv_marker(
                pd.Timestamp(e["date"]),
                text="ausgewählt" if selected else "",
                color=TEXT_MUTED_LIGHT if selected else color,
                position="inBar",
                shape="arrowDown" if selected else "circle",
            ))
    series_list = [tv_series(sector_label, s, color, line_width=2.1, markers=markers)]
    return tv_spec(series_list, height=420, value_format="pp", hlines=[{"value": 0, "label": "0"}])


def _indexed_from_trough_spec(series_map, sector_label, event, max_follow_years=5):
    sector = series_map.get(sector_label)
    benchmark = series_map.get(SECTOR_BENCHMARK_LABEL)
    if sector is None or benchmark is None:
        return None
    start_date = pd.Timestamp(event["date"])
    latest_date = min(pd.Timestamp(sector.index.max()), pd.Timestamp(benchmark.index.max()))
    end_date = min(start_date + pd.DateOffset(years=int(max_follow_years)), latest_date)
    frame = pd.concat([pd.to_numeric(sector, errors="coerce").rename(sector_label),
                        pd.to_numeric(benchmark, errors="coerce").rename(SECTOR_BENCHMARK_LABEL)],
                       axis=1, join="inner").dropna().sort_index()
    frame = frame.loc[(frame.index >= start_date) & (frame.index <= end_date)]
    if frame.empty:
        return None
    frame = frame / frame.iloc[0] * 100.0
    color = ACTIVE_SECTOR_COLORS.get(sector_label, "#9ca3af")
    series_list = [
        tv_series(sector_label, frame[sector_label], color, line_width=2.5),
        tv_series(SECTOR_BENCHMARK_LABEL, frame[SECTOR_BENCHMARK_LABEL], "#8a93a6", dashed=True, line_width=2.3),
    ]
    return tv_spec(series_list, height=420, value_format="ratio", rebase_visible=True)


def _heat_datatable(df, reverse_columns=None):
    return ag_heat_table(df, reverse_columns=reverse_columns)


def _card(title, children, id_=None):
    kwargs = {"className": "section-card"}
    if id_:
        kwargs["id"] = id_
    return html.Div([html.Div(title, className="section-title"), *children], **kwargs)


def _sector_heatmap_tiles(series_map):
    rows = []
    for label, series in series_map.items():
        if label == SECTOR_BENCHMARK_LABEL:
            continue
        s = series.dropna()
        r1m = float(s.iloc[-1] / s.iloc[-22] - 1.0) if len(s) > 22 else None
        r3m = float(s.iloc[-1] / s.iloc[-63] - 1.0) if len(s) > 63 else None
        rows.append({"label": label.split(" (")[0], "ticker": label.split("(")[-1].rstrip(")"), "r1m": r1m, "r3m": r3m})

    vals = [r["r1m"] for r in rows if r["r1m"] is not None]
    lo, hi = (min(vals), max(vals)) if vals else (0.0, 0.0)

    tiles = []
    for r in rows:
        if r["r1m"] is not None:
            bg, fg = cell_color(r["r1m"], lo, hi)
        else:
            bg, fg = SURFACE_2, TEXT_MUTED
        tiles.append(
            dmc.Paper(
                [
                    dmc.Text(r["ticker"], size="xs", fw=700, c=fg, ta="center"),
                    dmc.Text(r["label"], size="9px", c=fg, ta="center", opacity=0.85, lineClamp=1),
                    dmc.Text(f"{r['r1m']:+.1%}" if r["r1m"] is not None else "–", size="md", fw=700, c=fg, ta="center", mt=2),
                    dmc.Text(f"3M {r['r3m']:+.1%}" if r["r3m"] is not None else "3M –", size="9px", c=fg, ta="center", opacity=0.85),
                ],
                p="xs", radius="md", withBorder=True,
                style={"backgroundColor": bg}, className="heat-tile",
            )
        )
    return dmc.SimpleGrid(tiles, cols={"base": 3, "sm": 4, "md": 6, "lg": 9}, spacing="xs")


def layout(params=None):
    params = params or {}
    raw = sector_prices_usd()
    if not raw:
        return dmc.Alert("Sektordaten konnten nicht geladen werden.", color="red", m="md")

    overview_rows = []
    for item in SECTOR_ETFS + [SECTOR_BENCHMARK]:
        ticker = item["ticker"]
        if ticker not in raw:
            continue
        overview_rows.append({
            "Sektor": item["sector"] + (" (exkl.)" if ticker in EXCLUDED_SECTOR_TICKERS else ""),
            "ETF": ticker, "Auflage": item["inception"],
            "Daten verfügbar": f"{raw[ticker].index.min():%d.%m.%Y} – {raw[ticker].index.max():%d.%m.%Y}",
        })
    overview = pd.DataFrame(overview_rows)

    series_map = _available_sector_series(raw)
    sectors = [label for label in series_map if label != SECTOR_BENCHMARK_LABEL]
    default_sector = params.get("sector") if params.get("sector") in sectors else (sectors[0] if sectors else None)

    return html.Div([
        dmc.Title("S&P 500 Sector ETFs", order=3, mb="md"),
        _card("Universum", [ag_table(overview)]),

        _card("Performance-Heatmap (1M, 3M)", [_sector_heatmap_tiles(series_map)]),

        _card("Sektor-Tiefpunkt-Analyse (rollierende 12M-Renditedifferenz)", [
            dmc.Select(id="sector-focus-select", data=sectors, value=default_sector,
                       allowDeselect=False, mb="sm", style={"maxWidth": "420px"}),
            dcc.Store(id="sector-trough-idx", data=0),
            dmc.Grid([
                dmc.GridCol(tv_chart("sector-focus-diff-chart", tv_spec([])), span=6),
                dmc.GridCol([
                    dmc.Group([
                        dmc.ActionIcon("←", id="sector-trough-prev", variant="outline", color="orange"),
                        dmc.Text(id="sector-trough-label", size="sm", ta="center", style={"flex": 1}),
                        dmc.ActionIcon("→", id="sector-trough-next", variant="outline", color="orange"),
                    ], justify="space-between", mb="xs"),
                    tv_chart("sector-focus-indexed-chart", tv_spec([])),
                ], span=6),
            ]),
        ]),

        dmc.Grid([
            dmc.GridCol(_card("Wertentwicklung", [tv_chart("sector-performance-chart", _sector_performance_spec(_indexed_individually(series_map)))]), span=6),
            dmc.GridCol(_card("Drawdown", [tv_chart("sector-drawdown-chart", _sector_drawdown_spec(series_map))]), span=6),
        ]),
        dmc.Grid([
            dmc.GridCol(_card("Korrelogramm", [echart("sector-correlation-chart", _sector_correlation_option(series_map), height=460)]), span=6),
            dmc.GridCol(_card("Rollierende 1J-Korrelation zum S&P 500", [tv_chart("sector-rolling-corr-chart", _sector_rolling_corr_spec(series_map))]), span=6),
        ]),

        _card("Rollierende Renditedifferenz zum S&P 500", [
            dmc.Grid([
                dmc.GridCol(dmc.Stack([dmc.Text("Lookback (Monate)", size="xs", c="dimmed"),
                                        dmc.Slider(id="sector-lookback-months", min=1, max=60, step=1, value=12, color="orange",
                                                    marks=[{"value": v, "label": str(v)} for v in (1, 12, 24, 36, 48, 60)])]), span=4),
                dmc.GridCol(dmc.Stack([dmc.Text("Forward-Fenster Minimum (Monate)", size="xs", c="dimmed"),
                                        dmc.Slider(id="sector-forward-min", min=1, max=35, step=1, value=1, color="orange",
                                                    marks=[{"value": v, "label": str(v)} for v in (1, 12, 24, 35)])]), span=4),
                dmc.GridCol(dmc.Stack([dmc.Text("Forward-Fenster Maximum (Monate)", size="xs", c="dimmed"),
                                        dmc.Slider(id="sector-forward-max", min=1, max=36, step=1, value=12, color="orange",
                                                    marks=[{"value": v, "label": str(v)} for v in (1, 12, 24, 36)])]), span=4),
            ], mb="md"),
            dmc.Grid([
                dmc.GridCol(tv_chart("sector-rolling-diff-chart", tv_spec([])), span=6),
                dmc.GridCol(echart("sector-forward-scatter-chart", {}, height=460), span=6),
            ]),
        ]),

        dmc.Grid([
            dmc.GridCol(_card("Kennzahlen", [_heat_datatable(_sector_metrics(series_map), reverse_columns={"Volatilität p.a."})]), span=6),
            dmc.GridCol(_card("Jährliche Sharpe Ratio", [_heat_datatable(_sector_annual_sharpe(series_map))]), span=6),
        ]),
    ])


def register_callbacks(app):
    @app.callback(
        Output("sector-trough-idx", "data", allow_duplicate=True),
        Input("sector-focus-select", "value"),
        prevent_initial_call=True,
    )
    def reset_trough_on_sector_change(_sector):
        return 10**9  # sentinel: clamp to last event on next render

    @app.callback(
        Output("sector-trough-idx", "data"),
        Input("sector-trough-prev", "n_clicks"),
        Input("sector-trough-next", "n_clicks"),
        State("sector-trough-idx", "data"),
        State("sector-focus-select", "value"),
        prevent_initial_call=True,
    )
    def move_trough(_prev, _next, idx, sector):
        raw = sector_prices_usd()
        series_map = _available_sector_series(raw)
        events = _two_year_block_troughs(_single_sector_12m_diff(series_map, sector))
        if not events:
            return 0
        triggered = dash.callback_context.triggered_id
        idx = max(0, min(int(idx), len(events) - 1))
        if triggered == "sector-trough-prev":
            idx = max(0, idx - 1)
        elif triggered == "sector-trough-next":
            idx = min(len(events) - 1, idx + 1)
        return idx

    @app.callback(
        Output({"type": "tv-chart-data", "index": "sector-focus-diff-chart"}, "data"),
        Output({"type": "tv-chart-data", "index": "sector-focus-indexed-chart"}, "data"),
        Output("sector-trough-label", "children"),
        Output("sector-trough-prev", "disabled"),
        Output("sector-trough-next", "disabled"),
        Input("sector-focus-select", "value"),
        Input("sector-trough-idx", "data"),
    )
    def render_trough_analysis(sector, idx):
        raw = sector_prices_usd()
        series_map = _available_sector_series(raw)
        if not sector or sector not in series_map:
            return tv_spec([]), tv_spec([]), "", True, True
        diff_series = _single_sector_12m_diff(series_map, sector)
        events = _two_year_block_troughs(diff_series)
        if not events:
            return tv_spec([]), tv_spec([]), "Keine Tiefpunkte gefunden.", True, True
        idx = max(0, min(int(idx), len(events) - 1))
        event = events[idx]
        diff_spec = _single_sector_diff_spec(diff_series, sector, events, idx)
        indexed_spec = _indexed_from_trough_spec(series_map, sector, event, max_follow_years=5)
        label = f"Tiefpunkt {idx + 1}/{len(events)} · {event['date']:%d.%m.%Y} · {event['signal']:.2f} %-Pkt."
        return diff_spec or tv_spec([]), indexed_spec or tv_spec([]), label, idx <= 0, idx >= len(events) - 1

    @app.callback(
        Output("sector-forward-max", "min"),
        Input("sector-forward-min", "value"),
    )
    def sync_forward_max_min(min_months):
        return int(min_months)

    @app.callback(
        Output({"type": "tv-chart-data", "index": "sector-rolling-diff-chart"}, "data"),
        Output({"type": "echart-data", "index": "sector-forward-scatter-chart"}, "data"),
        Input("sector-lookback-months", "value"),
        Input("sector-forward-min", "value"),
        Input("sector-forward-max", "value"),
    )
    def update_rolling_and_forward(lookback_months, min_months, max_months):
        raw = sector_prices_usd()
        series_map = _available_sector_series(raw)
        max_months = max(int(max_months), int(min_months))
        rolling_diff = _rolling_relative_return_diff(series_map, lookback_months)
        if rolling_diff.empty:
            return tv_spec([]), {}
        diff_spec = _rolling_relative_return_spec(rolling_diff, lookback_months)
        scatter_option = _all_sector_forward_relative_return_option(series_map, rolling_diff, max_months, min_months)
        return diff_spec, (scatter_option or {})
