from __future__ import annotations

import math

import dash
import dash_mantine_components as dmc
import numpy as np
import pandas as pd
import yfinance as yf
from dash import ALL, MATCH, Input, Output, State, dcc, html

from src.cache import LONG_TTL, SHORT_TTL, cache
from src.data import convert_to_eur, detect_currency, download_adjusted_close
from src.metrics import cagr, max_drawdown, sortino
from src.theme import (
    ACCENT, PALETTE,
    ag_heat_table, ag_table, tv_chart, tv_series, tv_spec,
)


@cache.memoize(timeout=SHORT_TTL)
def yahoo_search(query: str):
    query = str(query or "").strip()
    if not query:
        return []
    results = []
    try:
        search = yf.Search(query, max_results=10)
        for item in (getattr(search, "quotes", None) or []):
            symbol = str(item.get("symbol") or "").strip()
            if not symbol:
                continue
            quote_type = str(item.get("quoteType") or item.get("typeDisp") or "")
            if quote_type.upper() not in {"EQUITY", "ETF", "MUTUALFUND", "INDEX", "CRYPTOCURRENCY"}:
                continue
            results.append({
                "symbol": symbol,
                "name": str(item.get("longname") or item.get("shortname") or item.get("name") or symbol),
                "exchange_code": str(item.get("exchange") or "").strip(),
                "exchange_name": str(item.get("exchDisp") or item.get("fullExchangeName") or item.get("exchangeName") or "").strip(),
                "type": quote_type,
            })
    except Exception:
        pass
    if not results:
        results.append({"symbol": query.upper(), "name": query, "exchange_code": "", "exchange_name": "", "type": "Direkteingabe"})
    seen, unique = set(), []
    for item in results:
        if item["symbol"] not in seen:
            seen.add(item["symbol"])
            unique.append(item)
    return unique[:10]


@cache.memoize(timeout=LONG_TTL)
def asset_series_eur(symbol: str):
    prices = download_adjusted_close(symbol, start="2000-01-01")
    if len(prices) < 30:
        raise RuntimeError(f"{symbol}: zu wenig Kursdaten")
    currency = detect_currency(symbol, "EUR")
    eur, detected = convert_to_eur(prices, currency)
    if len(eur) < 30:
        raise RuntimeError(f"{symbol}: zu wenig EUR-Daten")
    return eur.rename(symbol), detected


def rebalance_key(date, frequency):
    if frequency == "Monatlich":
        return (date.year, date.month)
    if frequency == "Quartalsweise":
        return (date.year, (date.month - 1) // 3)
    if frequency == "Halbjährlich":
        return (date.year, (date.month - 1) // 6)
    if frequency == "Jährlich":
        return (date.year,)
    return None


def backtest_portfolio(prices, weights, frequency):
    returns = prices.pct_change(fill_method=None).fillna(0.0)
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.sum()
    values = weights.copy()
    output = []
    last_key = None
    for date, row in returns.iterrows():
        key = rebalance_key(pd.Timestamp(date), frequency)
        if frequency != "Kein Rebalancing" and key != last_key and len(output) > 0:
            total = float(values.sum())
            values = total * weights
        values = values * (1.0 + row.to_numpy(dtype=float))
        output.append(float(values.sum()))
        last_key = key
    return pd.Series(output, index=returns.index, name="Portfolio") * 100.0


def backtest_metrics(series):
    series = series.dropna()
    if len(series) < 2:
        return {}
    returns = series.pct_change(fill_method=None).dropna()
    cg = cagr(series)
    vola = returns.std(ddof=1) * math.sqrt(252) if len(returns) > 1 else np.nan
    shp = (returns.mean() / returns.std(ddof=1) * math.sqrt(252)
           if len(returns) > 1 and returns.std(ddof=1) != 0 else np.nan)
    dd = max_drawdown(series)
    srt = sortino(series, 0.0)
    calmar = cg / abs(dd) if dd and not np.isnan(dd) else np.nan
    return {"CAGR p.a.": cg, "Volatilität p.a.": vola, "Sharpe Ratio": shp,
            "Max. Drawdown": dd, "Sortino": srt, "Calmar": calmar}


REBALANCE_OPTIONS = ["Monatlich", "Quartalsweise", "Halbjährlich", "Jährlich", "Kein Rebalancing"]
TIME_PERIOD_OPTIONS = ["Gesamter Datenzeitraum", "Letzte 1 Jahr", "Letzte 3 Jahre", "Letzte 5 Jahre", "Letzte 10 Jahre", "Benutzerdefiniert"]


def _card(title, children):
    return html.Div([html.Div(title, className="section-title"), *children], className="section-card")


def layout(params=None):
    return html.Div([
        dmc.Title("Asset Allocation Backtesting Tool", order=3, mb="xs"),
        dmc.Text(
            "Freie Wertpapiersuche über Yahoo Finance. Name, Ticker oder ISIN eingeben; "
            "bei nicht eindeutig auflösbaren ISINs funktioniert der Yahoo-Ticker am zuverlässigsten.",
            size="sm", c="dimmed", mb="md",
        ),
        dcc.Store(id="aa-assets-store", storage_type="session", data=[]),
        dcc.Store(id="aa-benchmark-store", storage_type="session", data=None),
        dcc.Store(id="aa-search-results-store", data=[]),

        html.Div([
            html.Div("Wertpapier hinzufügen", className="section-title"),
            dmc.Grid([
                dmc.GridCol(dmc.TextInput(id="aa-search-input", placeholder="z. B. Apple, AAPL oder US0378331005",
                                           label="Name, Ticker oder ISIN"), span=8),
                dmc.GridCol(dmc.Button("Suchen", id="aa-search-button", fullWidth=True, mt=24, color="orange"), span=4),
            ]),
            html.Div(id="aa-search-results-container", style={"marginTop": "12px"}),
        ], className="section-card"),

        html.Div(id="aa-portfolio-container", className="section-card"),

        html.Div([
            html.Div("Backtesting-Einstellungen", className="section-title"),
            dmc.Grid([
                dmc.GridCol(dmc.Select(id="aa-rebalance", label="Rebalancing", data=REBALANCE_OPTIONS,
                                        value="Quartalsweise", allowDeselect=False), span=4),
                dmc.GridCol(dmc.Select(id="aa-time-period", label="Zeitraum", data=TIME_PERIOD_OPTIONS,
                                        value="Gesamter Datenzeitraum", allowDeselect=False), span=4),
                dmc.GridCol(dmc.NumberInput(id="aa-custom-years", label="Jahre zurück", min=1, max=50, value=5,
                                             style={"display": "none"}), span=4, id="aa-custom-years-col"),
            ]),
            dmc.Button("Backtest starten", id="aa-backtest-button", color="orange", fullWidth=True, mt="md"),
        ], className="section-card"),

        html.Div(id="aa-results-container"),
    ])


def _search_result_option(item):
    exch = item.get("exchange_name") or item.get("exchange_code") or ""
    label = f"{item['name']} · {item['symbol']}" + (f" · {exch}" if exch else "")
    return {"value": item["symbol"], "label": label}


def register_callbacks(app):
    @app.callback(
        Output("aa-search-results-container", "children"),
        Output("aa-search-results-store", "data"),
        Input("aa-search-button", "n_clicks"),
        Input("aa-search-input", "n_submit"),
        State("aa-search-input", "value"),
        prevent_initial_call=True,
    )
    def do_search(_clicks, _submit, query):
        results = yahoo_search(query)
        if not results:
            return dmc.Text("Keine Treffer.", size="sm", c="dimmed"), []
        options = [_search_result_option(r) for r in results]
        content = dmc.Stack([
            dmc.Select(id="aa-search-select", data=options, value=options[0]["value"], allowDeselect=False),
            dmc.Group([
                dmc.Button("Zum Portfolio hinzufügen", id="aa-add-button", color="orange", variant="light"),
                dmc.Button("Als Benchmark verwenden", id="aa-benchmark-button", variant="outline", color="orange"),
            ], mt="sm"),
        ])
        return content, results

    @app.callback(
        Output("aa-assets-store", "data"),
        Input("aa-add-button", "n_clicks"),
        State("aa-search-select", "value"),
        State("aa-search-results-store", "data"),
        State("aa-assets-store", "data"),
        prevent_initial_call=True,
    )
    def add_asset(_n, selected_symbol, results, assets):
        assets = list(assets or [])
        if not _n or not selected_symbol or any(a["symbol"] == selected_symbol for a in assets):
            return assets
        match = next((r for r in results if r["symbol"] == selected_symbol), None)
        if not match:
            return assets
        assets.append({"symbol": match["symbol"], "name": match["name"], "weight": 0.0})
        equal = 100.0 / len(assets)
        for a in assets:
            a["weight"] = equal
        return assets

    @app.callback(
        Output("aa-benchmark-store", "data"),
        Input("aa-benchmark-button", "n_clicks"),
        State("aa-search-select", "value"),
        State("aa-search-results-store", "data"),
        prevent_initial_call=True,
    )
    def set_benchmark(_n, selected_symbol, results):
        if not _n:
            return dash.no_update
        match = next((r for r in results if r["symbol"] == selected_symbol), None)
        return match

    @app.callback(
        Output("aa-assets-store", "data", allow_duplicate=True),
        Input({"type": "aa-remove", "symbol": ALL}, "n_clicks"),
        State("aa-assets-store", "data"),
        prevent_initial_call=True,
    )
    def remove_asset(_clicks, assets):
        triggered = dash.callback_context.triggered_id
        if not triggered or not any(_clicks):
            return dash.no_update
        symbol = triggered["symbol"]
        assets = [a for a in (assets or []) if a["symbol"] != symbol]
        if assets:
            equal = 100.0 / len(assets)
            for a in assets:
                a["weight"] = equal
        return assets

    @app.callback(
        Output("aa-assets-store", "data", allow_duplicate=True),
        Input({"type": "aa-weight", "symbol": ALL}, "value"),
        State({"type": "aa-weight", "symbol": ALL}, "id"),
        State("aa-assets-store", "data"),
        prevent_initial_call=True,
    )
    def update_weights(values, ids, assets):
        weight_by_symbol = {i["symbol"]: v for i, v in zip(ids, values)}
        assets = list(assets or [])
        for a in assets:
            if a["symbol"] in weight_by_symbol and weight_by_symbol[a["symbol"]] is not None:
                a["weight"] = float(weight_by_symbol[a["symbol"]])
        return assets

    @app.callback(
        Output("aa-portfolio-container", "children"),
        Input("aa-assets-store", "data"),
        Input("aa-benchmark-store", "data"),
    )
    def render_portfolio(assets, benchmark):
        assets = assets or []
        rows = []
        if assets:
            for asset in assets:
                rows.append(
                    dmc.Grid([
                        dmc.GridCol(dmc.Text([
                            dmc.Text(asset["name"], fw=600, span=True), " ",
                            dmc.Text(f"({asset['symbol']})", c="dimmed", span=True, size="sm"),
                        ]), span=6),
                        dmc.GridCol(dmc.NumberInput(
                            id={"type": "aa-weight", "symbol": asset["symbol"]},
                            value=round(float(asset["weight"]), 2), min=0, max=100, step=1, suffix=" %",
                        ), span=4),
                        dmc.GridCol(dmc.Button("Entfernen", id={"type": "aa-remove", "symbol": asset["symbol"]},
                                                color="red", variant="subtle", size="xs", fullWidth=True), span=2),
                    ], align="center", mb=6)
                )
            total_weight = sum(a["weight"] for a in assets)
            rows.append(dmc.Text(f"Summe Gewichte: {total_weight:.2f} %", size="xs", c="dimmed", mt="xs"))
        else:
            rows.append(dmc.Text("Noch keine Wertpapiere im Portfolio.", size="sm", c="dimmed"))

        if benchmark:
            rows.append(dmc.Text([
                dmc.Text("Benchmark: ", fw=600, span=True),
                f"{benchmark['name']} ({benchmark['symbol']})",
            ], mt="sm", size="sm"))

        return [html.Div("Portfolio", className="section-title"), *rows]

    @app.callback(
        Output("aa-custom-years-col", "style"),
        Input("aa-time-period", "value"),
    )
    def toggle_custom_years(period):
        return {"display": "block"} if period == "Benutzerdefiniert" else {"display": "none"}

    @app.callback(
        Output("aa-results-container", "children"),
        Input("aa-backtest-button", "n_clicks"),
        State("aa-assets-store", "data"),
        State("aa-benchmark-store", "data"),
        State("aa-rebalance", "value"),
        State("aa-time-period", "value"),
        State("aa-custom-years", "value"),
        prevent_initial_call=True,
    )
    def run_backtest(_n, assets, benchmark, rebalance, time_period, custom_years):
        assets = assets or []
        if not assets:
            return dmc.Alert("Mindestens ein Wertpapier hinzufügen.", color="red")
        if not benchmark:
            return dmc.Alert("Bitte eine Benchmark auswählen.", color="red")
        weights = np.array([a["weight"] for a in assets], dtype=float)
        if weights.sum() <= 0:
            return dmc.Alert("Die Summe der Gewichte muss größer als 0 sein.", color="red")

        price_series, errors = {}, []
        for asset in assets:
            try:
                series, _ = asset_series_eur(asset["symbol"])
                price_series[asset["symbol"]] = series
            except Exception as exc:
                errors.append(str(exc))
        try:
            benchmark_series, _ = asset_series_eur(benchmark["symbol"])
        except Exception as exc:
            benchmark_series = None
            errors.append(f"Benchmark: {exc}")

        alerts = [dmc.Alert(err, color="yellow", mb=4) for err in errors]
        if len(price_series) != len(assets) or benchmark_series is None:
            return html.Div([*alerts, dmc.Alert("Backtest konnte nicht vollständig geladen werden.", color="red")])

        prices = pd.concat(price_series, axis=1).dropna()
        benchmark_series = benchmark_series.reindex(prices.index).dropna()
        common_index = prices.index.intersection(benchmark_series.index)
        prices = prices.loc[common_index]
        benchmark_series = benchmark_series.loc[common_index]

        if time_period != "Gesamter Datenzeitraum":
            years_back = {"Letzte 1 Jahr": 1, "Letzte 3 Jahre": 3, "Letzte 5 Jahre": 5,
                          "Letzte 10 Jahre": 10}.get(time_period, custom_years or 5)
            cutoff = pd.Timestamp.now() - pd.DateOffset(years=years_back)
            prices = prices[prices.index >= cutoff]
            benchmark_series = benchmark_series[benchmark_series.index >= cutoff]
            common_index = prices.index.intersection(benchmark_series.index)
            prices, benchmark_series = prices.loc[common_index], benchmark_series.loc[common_index]

        if len(prices) < 30:
            return html.Div([*alerts, dmc.Alert("Zu wenig gemeinsamer Datenzeitraum.", color="red")])

        portfolio = backtest_portfolio(prices, weights, rebalance)
        benchmark_indexed = benchmark_series / benchmark_series.iloc[0] * 100.0
        comparison = pd.concat([portfolio.rename("Portfolio"), benchmark_indexed.rename("Benchmark")], axis=1).dropna()

        perf_spec = tv_spec([
            tv_series("Portfolio", comparison["Portfolio"], PALETTE[0]),
            tv_series("Benchmark", comparison["Benchmark"], PALETTE[1], dashed=True),
        ], height=420, log_scale=True, value_format="ratio", rebase_visible=True)

        dd = comparison / comparison.cummax() - 1.0
        dd_spec = tv_spec([
            tv_series("Portfolio", dd["Portfolio"] * 100, PALETTE[0]),
            tv_series("Benchmark", dd["Benchmark"] * 100, PALETTE[1], dashed=True),
        ], height=420, value_format="percent")

        stats = pd.DataFrame({"Portfolio": backtest_metrics(comparison["Portfolio"]),
                               "Benchmark": backtest_metrics(comparison["Benchmark"])}).T

        weights_display = pd.DataFrame({
            "Wertpapier": [a["name"] for a in assets],
            "Ticker": [a["symbol"] for a in assets],
            "Gewicht": [float(w / weights.sum()) for w in weights],
        })

        return html.Div([
            *alerts,
            dmc.Grid([
                dmc.GridCol(_card("Wertentwicklung", [tv_chart("aa-perf-chart", perf_spec)]), span=6),
                dmc.GridCol(_card("Drawdown", [tv_chart("aa-dd-chart", dd_spec)]), span=6),
            ]),
            _card("Kennzahlen", [
                ag_heat_table(stats, reverse_columns={"Volatilität p.a."}),
            ]),
            _card("Backtest-Konfiguration", [
                ag_table(weights_display, formats={"Gewicht": "percent"}),
                dmc.Text(
                    f"Rebalancing: {rebalance} · Zeitraum: {comparison.index.min():%d.%m.%Y} – {comparison.index.max():%d.%m.%Y}",
                    size="xs", c="dimmed", mt="sm",
                ),
            ]),
        ])
