from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import math
import json

import dash_mantine_components as dmc
import pandas as pd
from dash import Input, Output, dcc, html

from src.cache import LONG_TTL, cache
from src.data import download_adjusted_close
from src.metrics import cagr, max_drawdown
from src.ai_summary import generate_summaries, SummaryError
from src.theme import (
    PALETTE, UP, DOWN,
    ag_heat_table, ag_value_formatter, card_header, sparkline_figure, tv_chart, tv_series, tv_spec,
)

ASSET_CLASSES = [
    {"key": "equities", "label": "Aktien (Global)", "sub": "MSCI ACWI", "ticker": "ACWI", "href": "/aktien"},
    {"key": "bonds", "label": "Anleihen", "sub": "US Aggregate Bond", "ticker": "AGG", "href": "/anleihen"},
    {"key": "commodities", "label": "Commodities", "sub": "DB Commodity Index", "ticker": "DBC", "href": "/commodities"},
    {"key": "real_estate", "label": "Immobilien (REITs)", "sub": "US Real Estate", "ticker": "VNQ", "href": "/immobilien"},
    {"key": "hedge_funds", "label": "Hedge Fonds", "sub": "Multi-Strategy (QAI)", "ticker": "QAI", "href": "/hedge-fonds"},
    {"key": "crypto", "label": "Kryptowährungen", "sub": "Bitcoin", "ticker": "BTC-USD", "href": "/krypto"},
    {"key": "cash", "label": "Liquidität / Geldmarkt", "sub": "1-3M T-Bills", "ticker": "BIL", "href": "/geldmarkt"},
]

RANGE_OPTIONS = [
    {"label": "1J", "value": "1"}, {"label": "3J", "value": "3"}, {"label": "5J", "value": "5"},
    {"label": "10J", "value": "10"}, {"label": "Max", "value": "max"},
]


@cache.memoize(timeout=LONG_TTL, response_filter=lambda result: not result.empty)
def _asset_class_series(ticker: str) -> pd.Series:
    try:
        return download_adjusted_close(ticker, start="2000-01-01")
    except Exception:
        return pd.Series(dtype=float)


def _filtered(series: pd.Series, years) -> pd.Series:
    s = series.dropna()
    if s.empty or years == "max":
        return s
    cutoff = pd.Timestamp.now().normalize() - pd.DateOffset(years=int(years))
    return s[s.index >= cutoff]


ASSET_CLASS_COLORS = [PALETTE[0], PALETTE[2], PALETTE[5], PALETTE[3], PALETTE[9], PALETTE[4], PALETTE[7], PALETTE[8]]


def _overview_spec(years, drawdown=False):
    series_list = []
    for i, item in enumerate(ASSET_CLASSES):
        s = _filtered(_asset_class_series(item["ticker"]), years)
        if len(s) < 2:
            continue
        indexed = (s / s.cummax() - 1) * 100 if drawdown else s / s.iloc[0] * 100.0
        series_list.append(tv_series(item["label"], indexed, ASSET_CLASS_COLORS[i % len(ASSET_CLASS_COLORS)]))
    spec = tv_spec(series_list, height=480, log_scale=not drawdown,
                   value_format="percent" if drawdown else "ratio", rebase_visible=not drawdown)
    spec.update({"syncGroup": "overview", "syncKey": str(years)})
    return spec


def _stat_card(item, series):
    s = _filtered(series, "1")
    asset_color = ASSET_CLASS_COLORS[ASSET_CLASSES.index(item)]
    href = item.get("href")
    card_kwargs = dict(p="md", radius="md", withBorder=True,
                        className="stat-card stat-card-clickable" if href else "stat-card")

    if len(s) < 2:
        card = dmc.Paper(dmc.Text(f"{item['label']}: keine Daten", size="xs", c="dimmed"), **card_kwargs)
    else:
        period_return = float(s.iloc[-1] / s.iloc[0] - 1.0)
        card = dmc.Paper(
            [
                dmc.Text(item["label"], className="stat-label", fw=700,
                         style={"color": asset_color}),
                dmc.Group([
                    dmc.Text(f"{period_return:+.1%}", size="lg", fw=700, c=("teal" if period_return >= 0 else "red")),
                    dmc.Text("1 Jahr", size="10px", c="dimmed"),
                ], justify="space-between", align="center"),
                dcc.Graph(figure=sparkline_figure(s, UP if period_return >= 0 else DOWN),
                          responsive=True, config={"staticPlot": True, "responsive": True},
                          style={"height": "40px", "marginTop": "6px"}),
                dmc.Text(f"{item['sub']} · {item['ticker']}", className="overview-proxy",
                         size="10px", c="dimmed", ta="right"),
            ],
            **card_kwargs,
        )

    if href:
        return dcc.Link(card, href=href, className="stat-card-link")
    return card


ANNUAL_METRICS = [
    {"label": "Return p.a.", "value": "return"},
    {"label": "Vola p.a.", "value": "volatility"},
    {"label": "Max. Drawdown", "value": "drawdown"},
    {"label": "Sharpe Ratio", "value": "sharpe"},
    {"label": "Sortino Ratio", "value": "sortino"},
    {"label": "Calmar Ratio", "value": "calmar"},
]


def _statistics(s, item):
    returns = s.pct_change(fill_method=None).dropna()
    periods = 365 if item["ticker"] == "BTC-USD" else 252
    vol = float(returns.std(ddof=1) * math.sqrt(periods))
    annual_mean = float(returns.mean() * periods)
    downside = float(returns.clip(upper=0).pow(2).mean() ** 0.5 * math.sqrt(periods))
    cg, dd = cagr(s), max_drawdown(s)
    return {
        "return": float(s.iloc[-1] / s.iloc[0] - 1),
        "cagr": cg, "volatility": vol, "drawdown": dd,
        "sharpe": annual_mean / vol if vol > 0 else float("nan"),
        "sortino": annual_mean / downside if downside > 0 else float("nan"),
        "calmar": cg / abs(dd) if dd < 0 else float("nan"),
    }


def _metrics_table(years):
    columns = {"Gesamtrendite": "return", "CAGR p.a.": "cagr", "Vola p.a.": "volatility",
               "Max. Drawdown": "drawdown", "Sharpe Ratio": "sharpe",
               "Sortino Ratio": "sortino", "Calmar Ratio": "calmar"}
    rows = {}
    for item in ASSET_CLASSES:
        s = _filtered(_asset_class_series(item["ticker"]), years)
        if len(s) >= 2:
            stats = _statistics(s, item)
            rows[item["label"]] = {label: stats[key] for label, key in columns.items()}
    table = _colored_table(pd.DataFrame.from_dict(rows, orient="index"))
    if hasattr(table, "columnDefs"):
        for col in table.columnDefs[1:]:
            kind = "percent" if columns[col["field"]] in {"return", "cagr", "volatility", "drawdown"} else "ratio"
            col["valueFormatter"] = ag_value_formatter(kind)
    return table


def _annual_table(metric):
    if metric not in {option["value"] for option in ANNUAL_METRICS}:
        metric = "return"
    rows = {}
    for item in ASSET_CLASSES:
        s = _asset_class_series(item["ticker"]).dropna().sort_index()
        values = {}
        for year in sorted(set(s.index.year)):
            part = s[s.index.year == year]
            # Previous year's closing value includes the first trading day's return.
            previous = s[s.index < part.index[0]].tail(1)
            window = pd.concat([previous, part])
            if len(window) >= 2:
                values[str(year)] = _statistics(window, item)[metric]
        rows[item["label"]] = values
    df = pd.DataFrame.from_dict(rows, orient="index")
    df = df.reindex(index=[item["label"] for item in ASSET_CLASSES])
    df = df.reindex(columns=sorted(df.columns, reverse=True))
    table = _colored_table(df)
    if hasattr(table, "columnDefs"):
        for col in table.columnDefs[1:]:
            col["valueFormatter"] = ag_value_formatter("percent" if metric in {"return", "volatility", "drawdown"} else "ratio")
            col["width"] = 110
    return table


def _colored_table(df):
    if df.empty:
        return dmc.Text("Keine Daten vorhanden.")
    table = ag_heat_table(df)
    colors = {item["label"]: ASSET_CLASS_COLORS[i] for i, item in enumerate(ASSET_CLASSES)}
    for row in table.rowData:
        row["__asset_bg"] = colors[row["__index__"]] + "30"
        for col in df.columns:
            row[f"__bg_{col}"] = row["__asset_bg"]
            row[f"__fg_{col}"] = "#16181d"
    table.columnDefs[0]["cellStyle"] = {
        "function": "({fontWeight: '700', color: '#16181d', backgroundColor: params.data.__asset_bg})"
    }
    table.columnDefs[0].update({"headerName": "Anlageklasse", "flex": 1.5, "minWidth": 160})
    table.defaultColDef = {**table.defaultColDef, "flex": 1, "minWidth": 115, "wrapHeaderText": True,
                          "autoHeaderHeight": False, "sortable": False}
    table.dashGridOptions.update({"rowHeight": 42, "headerHeight": 60})
    return table


def _card(title, children):
    return html.Div([card_header(title, html.Div()), *children], className="section-card")


def layout(params=None):
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(_asset_class_series, [item["ticker"] for item in ASSET_CLASSES]))
    return html.Div([
        dmc.Group([
            dmc.Title("Markets Overview", order=3),
            dmc.Button("KI Zusammenfassung", id="overview-ai-button", variant="light"),
        ], justify="space-between", mb="md"),
        dcc.Loading(html.Div(id="overview-ai-result"), type="circle"),
        html.Div(
            [_stat_card(item, _asset_class_series(item["ticker"])) for item in ASSET_CLASSES],
            className="overview-asset-grid",
        ),

        html.Div([
            dmc.SegmentedControl(id="overview-range", data=RANGE_OPTIONS, value="5",
                                 persistence=True, persistence_type="session"),
        ], className="overview-controls"),
        html.Div([
            _card("Wertentwicklung", [tv_chart("overview-chart", _overview_spec("5"))]),
            _card("Drawdown", [tv_chart("overview-drawdown", _overview_spec("5", drawdown=True))]),
        ], className="overview-two-columns"),
        html.Div([
            _card("Periodenkennzahlen", [
                html.Div(id="overview-metrics", children=_metrics_table("5")),
            ]),
            html.Div([
                card_header("Jahreskennzahlen", dmc.Select(
                    id="overview-annual-metric", data=ANNUAL_METRICS, value="return",
                    allowDeselect=False, style={"width": "180px"},
                )),
                html.Div(id="overview-annual", children=_annual_table("return")),
            ], className="section-card"),
        ], className="overview-two-columns"),
    ], className="markets-overview")


def register_callbacks(app):
    @app.callback(
        Output("overview-ai-result", "children"),
        Input("overview-ai-button", "n_clicks"),
        prevent_initial_call=True,
        running=[(Output("overview-ai-button", "loading"), True, False),
                 (Output("overview-ai-button", "disabled"), True, False)],
    )
    def summarize_year(n_clicks):
        if not n_clicks:
            return []
        payload = []
        for item in ASSET_CLASSES:
            s = _filtered(_asset_class_series(item["ticker"]), "1")
            record = {"key": item["key"], "name": item["label"], "proxy": item["sub"], "ticker": item["ticker"]}
            if len(s) >= 2:
                record.update({
                    "start": s.index[0].date().isoformat(), "end": s.index[-1].date().isoformat(),
                    "metrics": {k: v if math.isfinite(v) else None for k, v in _statistics(s, item).items()},
                    "month_end_index": {d.date().isoformat(): float(v / s.iloc[0] * 100)
                                        for d, v in s.groupby(s.index.to_period("M")).tail(1).items()},
                })
            else:
                record["data_status"] = "Nicht genügend Kursdaten im letzten Jahr."
            payload.append(record)
        try:
            summaries = generate_summaries(json.dumps(payload, ensure_ascii=False, allow_nan=False))
        except SummaryError as error:
            return dmc.Alert(str(error), title="KI Zusammenfassung", color="orange", mb="md")
        return html.Div([
            dmc.Text("KI-Jahresrückblick · basierend auf den Kursdaten der letzten zwölf Monate", mb="md"),
            html.Div([
                html.Div([
                    html.H3(item["label"]),
                    dmc.Text(summaries[item["key"]]),
                ], className="section-card") for i, item in enumerate(ASSET_CLASSES)
            ], className="overview-two-columns"),
        ], className="overview-ai-summaries")

    @app.callback(
        Output({"type": "tv-chart-data", "index": "overview-chart"}, "data"),
        Output("overview-metrics", "children"),
        Output({"type": "tv-chart-data", "index": "overview-drawdown"}, "data"),
        Input("overview-range", "value"),
    )
    def update_overview(years):
        return _overview_spec(years), _metrics_table(years), _overview_spec(years, drawdown=True)

    @app.callback(Output("overview-annual", "children"), Input("overview-annual-metric", "value"))
    def update_annual(metric):
        return _annual_table(metric)
