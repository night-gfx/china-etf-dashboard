from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import dash_mantine_components as dmc
import pandas as pd
from dash import Input, Output, dcc, html

from src.cache import LONG_TTL, cache
from src.data import download_adjusted_close
from src.theme import ag_table, card_header

# Representative "main" ETF per country. `region` is None for a dedicated single-country
# ETF; when several countries share one regional ETF (no country-specific fund exists),
# `region` names that regional fund and those countries are drawn with a bold outline.
COUNTRY_ETF_MAP = [
    {"country": "USA", "iso3": "USA", "ticker": "SPY", "etf": "SPDR S&P 500 ETF", "region": None},
    {"country": "Kanada", "iso3": "CAN", "ticker": "EWC", "etf": "iShares MSCI Canada", "region": None},
    {"country": "Mexiko", "iso3": "MEX", "ticker": "EWW", "etf": "iShares MSCI Mexico", "region": None},
    {"country": "Brasilien", "iso3": "BRA", "ticker": "EWZ", "etf": "iShares MSCI Brazil", "region": None},
    {"country": "Chile", "iso3": "CHL", "ticker": "ECH", "etf": "iShares MSCI Chile", "region": None},
    {"country": "Peru", "iso3": "PER", "ticker": "EPU", "etf": "iShares MSCI Peru", "region": None},
    {"country": "Kolumbien", "iso3": "COL", "ticker": "GXG", "etf": "Global X MSCI Colombia", "region": None},
    {"country": "Argentinien", "iso3": "ARG", "ticker": "ARGT", "etf": "Global X MSCI Argentina", "region": None},
    {"country": "Deutschland", "iso3": "DEU", "ticker": "EWG", "etf": "iShares MSCI Germany", "region": None},
    {"country": "Vereinigtes Königreich", "iso3": "GBR", "ticker": "EWU", "etf": "iShares MSCI United Kingdom", "region": None},
    {"country": "Frankreich", "iso3": "FRA", "ticker": "EWQ", "etf": "iShares MSCI France", "region": None},
    {"country": "Italien", "iso3": "ITA", "ticker": "EWI", "etf": "iShares MSCI Italy", "region": None},
    {"country": "Spanien", "iso3": "ESP", "ticker": "EWP", "etf": "iShares MSCI Spain", "region": None},
    {"country": "Schweiz", "iso3": "CHE", "ticker": "EWL", "etf": "iShares MSCI Switzerland", "region": None},
    {"country": "Niederlande", "iso3": "NLD", "ticker": "EWN", "etf": "iShares MSCI Netherlands", "region": None},
    {"country": "Schweden", "iso3": "SWE", "ticker": "EWD", "etf": "iShares MSCI Sweden", "region": None},
    {"country": "Belgien", "iso3": "BEL", "ticker": "EWK", "etf": "iShares MSCI Belgium", "region": None},
    {"country": "Österreich", "iso3": "AUT", "ticker": "EWO", "etf": "iShares MSCI Austria", "region": None},
    {"country": "Polen", "iso3": "POL", "ticker": "EPOL", "etf": "iShares MSCI Poland", "region": None},
    {"country": "Norwegen", "iso3": "NOR", "ticker": "NORW", "etf": "Global X MSCI Norway", "region": None},
    {"country": "Dänemark", "iso3": "DNK", "ticker": "EDEN", "etf": "Global X MSCI Denmark", "region": None},
    {"country": "Finnland", "iso3": "FIN", "ticker": "EFNL", "etf": "Global X MSCI Finland", "region": None},
    {"country": "Griechenland", "iso3": "GRC", "ticker": "GREK", "etf": "Global X MSCI Greece", "region": None},
    {"country": "Japan", "iso3": "JPN", "ticker": "EWJ", "etf": "iShares MSCI Japan", "region": None},
    {"country": "China", "iso3": "CHN", "ticker": "MCHI", "etf": "iShares MSCI China", "region": None},
    {"country": "Indien", "iso3": "IND", "ticker": "INDA", "etf": "iShares MSCI India", "region": None},
    {"country": "Südkorea", "iso3": "KOR", "ticker": "EWY", "etf": "iShares MSCI South Korea", "region": None},
    {"country": "Taiwan", "iso3": "TWN", "ticker": "EWT", "etf": "iShares MSCI Taiwan", "region": None},
    {"country": "Hongkong", "iso3": "HKG", "ticker": "EWH", "etf": "iShares MSCI Hong Kong", "region": None},
    {"country": "Singapur", "iso3": "SGP", "ticker": "EWS", "etf": "iShares MSCI Singapore", "region": None},
    {"country": "Australien", "iso3": "AUS", "ticker": "EWA", "etf": "iShares MSCI Australia", "region": None},
    {"country": "Neuseeland", "iso3": "NZL", "ticker": "ENZL", "etf": "iShares MSCI New Zealand", "region": None},
    {"country": "Thailand", "iso3": "THA", "ticker": "THD", "etf": "iShares MSCI Thailand", "region": None},
    {"country": "Malaysia", "iso3": "MYS", "ticker": "EWM", "etf": "iShares MSCI Malaysia", "region": None},
    {"country": "Indonesien", "iso3": "IDN", "ticker": "EIDO", "etf": "iShares MSCI Indonesia", "region": None},
    {"country": "Philippinen", "iso3": "PHL", "ticker": "EPHE", "etf": "iShares MSCI Philippines", "region": None},
    {"country": "Vietnam", "iso3": "VNM", "ticker": "VNM", "etf": "VanEck Vietnam", "region": None},
    {"country": "Israel", "iso3": "ISR", "ticker": "EIS", "etf": "iShares MSCI Israel", "region": None},
    {"country": "Türkei", "iso3": "TUR", "ticker": "TUR", "etf": "iShares MSCI Turkey", "region": None},
    {"country": "Saudi-Arabien", "iso3": "SAU", "ticker": "KSA", "etf": "iShares MSCI Saudi Arabia", "region": None},
    {"country": "Vereinigte Arabische Emirate", "iso3": "ARE", "ticker": "UAE", "etf": "iShares MSCI UAE", "region": None},
    {"country": "Katar", "iso3": "QAT", "ticker": "QAT", "etf": "iShares MSCI Qatar", "region": None},
    {"country": "Südafrika", "iso3": "ZAF", "ticker": "EZA", "etf": "iShares MSCI South Africa", "region": None},
    {"country": "Ägypten", "iso3": "EGY", "ticker": "EGPT", "etf": "VanEck Egypt", "region": None},
    {"country": "Russland", "iso3": "RUS", "ticker": "RSX", "etf": "VanEck Russia (ausgesetzt)", "region": None},
    # Regional buckets: countries without a dedicated single-country ETF.
    {"country": "Portugal", "iso3": "PRT", "ticker": "VGK", "etf": "Vanguard FTSE Europe", "region": "Europa (Sonstige)"},
    {"country": "Irland", "iso3": "IRL", "ticker": "VGK", "etf": "Vanguard FTSE Europe", "region": "Europa (Sonstige)"},
    {"country": "Luxemburg", "iso3": "LUX", "ticker": "VGK", "etf": "Vanguard FTSE Europe", "region": "Europa (Sonstige)"},
    {"country": "Uruguay", "iso3": "URY", "ticker": "ILF", "etf": "iShares Latin America 40", "region": "Lateinamerika (Sonstige)"},
    {"country": "Ecuador", "iso3": "ECU", "ticker": "ILF", "etf": "iShares Latin America 40", "region": "Lateinamerika (Sonstige)"},
    {"country": "Kuwait", "iso3": "KWT", "ticker": "GAF", "etf": "SPDR S&P Emerging Middle East & Africa", "region": "Naher Osten & Afrika (Sonstige)"},
    {"country": "Marokko", "iso3": "MAR", "ticker": "GAF", "etf": "SPDR S&P Emerging Middle East & Africa", "region": "Naher Osten & Afrika (Sonstige)"},
    {"country": "Nigeria", "iso3": "NGA", "ticker": "GAF", "etf": "SPDR S&P Emerging Middle East & Africa", "region": "Naher Osten & Afrika (Sonstige)"},
    {"country": "Kenia", "iso3": "KEN", "ticker": "GAF", "etf": "SPDR S&P Emerging Middle East & Africa", "region": "Naher Osten & Afrika (Sonstige)"},
    {"country": "Pakistan", "iso3": "PAK", "ticker": "AAXJ", "etf": "iShares MSCI All Country Asia ex Japan", "region": "Asien (Sonstige)"},
    {"country": "Bangladesch", "iso3": "BGD", "ticker": "AAXJ", "etf": "iShares MSCI All Country Asia ex Japan", "region": "Asien (Sonstige)"},
]

# Region-name strings as used by the ECharts world.json basemap (English GeoJSON
# feature names). Taiwan and Hong Kong are not present as separate shapes in
# that basemap (merged into China's polygon), so the map simply cannot color
# them individually - they stay in the table below though.
_ECHARTS_NAME_BY_ISO3 = {
    "USA": "United States", "CAN": "Canada", "MEX": "Mexico", "BRA": "Brazil", "CHL": "Chile",
    "PER": "Peru", "COL": "Colombia", "ARG": "Argentina", "DEU": "Germany", "GBR": "United Kingdom",
    "FRA": "France", "ITA": "Italy", "ESP": "Spain", "CHE": "Switzerland", "NLD": "Netherlands",
    "SWE": "Sweden", "BEL": "Belgium", "AUT": "Austria", "POL": "Poland", "NOR": "Norway",
    "DNK": "Denmark", "FIN": "Finland", "GRC": "Greece", "JPN": "Japan", "CHN": "China",
    "IND": "India", "KOR": "Korea", "SGP": "Singapore", "AUS": "Australia", "NZL": "New Zealand",
    "THA": "Thailand", "MYS": "Malaysia", "IDN": "Indonesia", "PHL": "Philippines", "VNM": "Vietnam",
    "ISR": "Israel", "TUR": "Turkey", "SAU": "Saudi Arabia", "ARE": "United Arab Emirates",
    "QAT": "Qatar", "ZAF": "South Africa", "EGY": "Egypt", "RUS": "Russia", "PRT": "Portugal",
    "IRL": "Ireland", "LUX": "Luxembourg", "URY": "Uruguay", "ECU": "Ecuador", "KWT": "Kuwait",
    "MAR": "Morocco", "NGA": "Nigeria", "KEN": "Kenya", "PAK": "Pakistan", "BGD": "Bangladesh",
}
for _item in COUNTRY_ETF_MAP:
    _item["echarts_name"] = _ECHARTS_NAME_BY_ISO3.get(_item["iso3"])

RANGE_OPTIONS = [
    {"label": "1M", "value": "0.08"}, {"label": "3M", "value": "0.25"}, {"label": "6M", "value": "0.5"},
    {"label": "1J", "value": "1"}, {"label": "3J", "value": "3"}, {"label": "5J", "value": "5"}, {"label": "Max", "value": "max"},
]


@cache.memoize(timeout=LONG_TTL)
def _country_series(ticker: str) -> pd.Series:
    try:
        return download_adjusted_close(ticker, start="2000-01-01")
    except Exception:
        return pd.Series(dtype=float)


def _warm_country_cache():
    """Fetch all distinct tickers in parallel so the first page view doesn't
    serialize ~50 sequential Yahoo Finance calls."""
    tickers = sorted({item["ticker"] for item in COUNTRY_ETF_MAP})
    with ThreadPoolExecutor(max_workers=16) as pool:
        list(pool.map(_country_series, tickers))


def _period_return(ticker: str, years):
    s = _country_series(ticker).dropna()
    if len(s) < 2:
        return None
    if years != "max":
        cutoff = pd.Timestamp.now() - pd.DateOffset(days=int(float(years) * 365.25))
        s = s[s.index >= cutoff]
    if len(s) < 2:
        return None
    return float(s.iloc[-1] / s.iloc[0] - 1.0)


def _map_payload(years):
    rows = []
    all_returns = []
    for item in COUNTRY_ETF_MAP:
        if not item["echarts_name"]:
            continue
        ret = _period_return(item["ticker"], years)
        if ret is not None:
            all_returns.append(ret)
        rows.append({
            "name": item["echarts_name"],
            "value": ret,
            "label": item["country"],
            "etf": item["etf"],
            "ticker": item["ticker"],
            "zuordnung": item["region"] or "Eigener Landes-ETF",
            "itemStyle": {"borderWidth": 2.2, "borderColor": "#e6e8ee"} if item["region"] else {},
        })
    zabs = max([abs(r) for r in all_returns] + [0.01])
    return {"data": rows, "min": -zabs, "max": zabs}


def _card(title, children):
    return html.Div([html.Div(title, className="section-title"), *children], className="section-card")


def layout(params=None):
    _warm_country_cache()
    return html.Div([
        dmc.Title("Aktien – Länder-ETF-Weltkarte", order=3, mb="xs"),
        dmc.Text(
            "Der jeweils gängigste Länder-ETF pro Markt, eingefärbt nach Performance im gewählten Zeitraum. "
            "Dick umrandete Länder haben keinen eigenen Landes-ETF und teilen sich stattdessen einen "
            "regionalen ETF (siehe Tooltip).",
            size="sm", c="dimmed", mb="md",
        ),
        html.Div([
            card_header("Weltkarte", dmc.SegmentedControl(
                id="equities-map-range", data=RANGE_OPTIONS, value="1", size="xs",
                persistence=True, persistence_type="session",
            )),
            html.Div(id="echarts-map", style={"height": "560px", "width": "100%"}),
            dcc.Store(id="echarts-map-data", data=_map_payload("1")),
            dcc.Store(id="echarts-map-dummy"),
            dmc.Text(
                "Hinweis: Taiwan und Hongkong sind in der verwendeten Kartenbasis Teil der Fläche Chinas und "
                "daher auf der Karte nicht separat einfärbbar – in der Tabelle unten sind beide weiterhin "
                "mit eigenem ETF gelistet.",
                size="10px", c="dimmed", mt=8,
            ),
        ], className="section-card"),
        _card("Länder & Zuordnung", [html.Div(id="equities-table", children=_country_table("1"))]),
    ])


def _country_table(years):
    rows = []
    for item in COUNTRY_ETF_MAP:
        ret = _period_return(item["ticker"], years)
        rows.append({
            "Land": item["country"], "ETF": item["etf"], "Ticker": item["ticker"],
            "Zuordnung": item["region"] or "Eigener Landes-ETF",
            "Performance": ret,
        })
    df = pd.DataFrame(rows).sort_values("Land")
    return ag_table(
        df, formats={"Performance": "percent"}, page_size=20,
        get_row_style={"function": "params.data && params.data.Zuordnung !== 'Eigener Landes-ETF' "
                                    "? {fontStyle: 'italic'} : null"},
    )


def register_callbacks(app):
    @app.callback(
        Output("echarts-map-data", "data"),
        Output("equities-table", "children"),
        Input("equities-map-range", "value"),
    )
    def update_map(years):
        return _map_payload(years), _country_table(years)

    app.clientside_callback(
        """
        function(payload) {
            if (payload && window.renderEchartsMap) { window.renderEchartsMap('echarts-map', payload); }
            return '';
        }
        """,
        Output("echarts-map-dummy", "data"),
        Input("echarts-map-data", "data"),
    )
