from __future__ import annotations

import math
from pathlib import Path

import dash
import dash_mantine_components as dmc
import numpy as np
import pandas as pd
from dash import ALL, Input, Output, State, dcc, html

from src.cache import DAY_TTL, LONG_TTL, cache
from src.data import load_registry, resolve_oldest_available_for_index, resolve_selected_rows
from src.metrics import cagr, max_drawdown, sortino, tracking_error_and_ir
from src.tax import effective_german_equity_etf_tax_rate, transform_frame
from src.theme import (
    PALETTE,
    ag_heat_columns_rows, ag_heat_table_placeholder, ag_table,
    echart, sparkline_figure, tv_chart, tv_series, tv_spec,
)

ROOT = Path(__file__).resolve().parents[1]
TECH_PATH = ROOT / "data_tech_etfs.csv"

SHARE_CLASS_ORDER = ["A-Shares", "B-Shares", "H-Shares", "Red Chips", "P-Chips", "Auslandslistings / ADRs"]
INDEX_SCOPE = {
    "MSCI China All Shares Stock Connect Select": "All Shares", "S&P China 500": "All Shares",
    "FTSE China 30/18 Capped": "All Shares", "MSCI China": "All Shares",
    "MSCI China ex A Shares": "Offshore", "Dow Jones China Offshore 50": "Offshore",
    "FTSE China 50": "Offshore", "CSI Overseas China Internet": "Offshore",
    "MSCI China A": "Onshore", "CSI A 500": "Onshore", "MSCI China A Inclusion": "Onshore",
    "CSI 300": "Onshore", "S&P China A 300": "Onshore",
    "SSE Science and Technology Innovation Board 50": "Onshore", "ChiNext 50 Capped": "Onshore",
}
INDEX_INFO = {
    "MSCI China All Shares Stock Connect Select": {"url": "https://www.msci.com/indexes/index/732716/msci-china-all-shares-stock-connect-select-index", "members": "576", "segment": "Breit; Large & Mid Cap", "weight": "Free-Float-Marktkapitalisierung", "rebalance": "4× p.a.", "special": "Breite China-Benchmark mit Onshore- und Offshore-Markt."},
    "S&P China 500": {"url": "https://www.spglobal.com/spdji/en/indices/equity/sp-china-500", "members": "500", "segment": "Breit; Large & Mid Cap", "weight": "Float-adjusted Market Cap", "rebalance": "2× p.a.", "special": "Breite, sektorübergreifende China-Benchmark."},
    "FTSE China 30/18 Capped": {"url": "https://www.lseg.com/en/ftse-russell", "members": "variabel", "segment": "Breit; Large & Mid Cap", "weight": "Free-Float Market Cap; 30/18-Capping", "rebalance": "4× p.a.", "special": "Breite China-Benchmark mit Konzentrationsbegrenzung."},
    "MSCI China": {"url": "https://www.msci.com/indexes/index/302400/msci-china-index", "members": "576", "segment": "Breit; Large & Mid Cap", "weight": "Free-Float-Marktkapitalisierung", "rebalance": "4× p.a.", "special": "Breite Standardbenchmark für chinesische Large- und Mid-Caps."},
    "MSCI China ex A Shares": {"url": "https://www.msci.com/", "members": "variabel", "segment": "Breit Offshore; Large & Mid Cap", "weight": "Free-Float-Marktkapitalisierung", "rebalance": "4× p.a.", "special": "Offshore-China-Benchmark ohne Mainland-A-Aktien."},
    "Dow Jones China Offshore 50": {"url": "https://www.spglobal.com/spdji/tc/documents/methodologies/methodology-dj-china.pdf", "members": "50", "segment": "Offshore Large Cap", "weight": "Float-adjusted Market Cap; 10%-Cap", "rebalance": "4× p.a.", "special": "Large-Cap-Benchmark für chinesische Offshore-Unternehmen."},
    "FTSE China 50": {"url": "https://www.lseg.com/content/dam/ftse-russell/en_us/documents/ground-rules/ftse-china-50-index-english-ground-rules.pdf", "members": "50", "segment": "Hongkong Large Cap", "weight": "Free-Float Market Cap", "rebalance": "4× p.a.", "special": "Hongkong-notierte China-Large-Cap-Benchmark."},
    "CSI Overseas China Internet": {"url": "https://www.csindex.com.cn/", "members": "≈ 30–50", "segment": "Offshore Internet / Tech", "weight": "Free-Float Market Cap", "rebalance": "2× p.a.", "special": "Offshore-Benchmark für chinesische Internetunternehmen."},
    "MSCI China A": {"url": "https://www.msci.com/", "members": "variabel", "segment": "Breit Onshore; Large & Mid Cap", "weight": "Free-Float-Marktkapitalisierung", "rebalance": "4× p.a.", "special": "Breite Mainland-China-Benchmark."},
    "CSI A 500": {"url": "https://www.csindex.com.cn/", "members": "500", "segment": "Breit Onshore; Mid/Large", "weight": "Free-Float Market Cap", "rebalance": "2× p.a.", "special": "Breite Mainland-China-Benchmark mit stärkerer Branchenabdeckung."},
    "MSCI China A Inclusion": {"url": "https://www.msci.com/", "members": "≈ 400", "segment": "Onshore; Stock-Connect A-Shares", "weight": "Free-Float mit Inclusion Factor", "rebalance": "4× p.a.", "special": "Benchmark für die schrittweise MSCI-Integration chinesischer A-Aktien."},
    "CSI 300": {"url": "https://www.csindex.com.cn/", "members": "300", "segment": "Onshore Large & Mid Cap", "weight": "Free-Float Market Cap", "rebalance": "2× p.a.", "special": "Leitbenchmark für große und mittelgroße Mainland-China-Unternehmen."},
    "S&P China A 300": {"url": "https://www.spglobal.com/spdji/", "members": "300", "segment": "Onshore Large & Mid Cap", "weight": "Float-adjusted Market Cap", "rebalance": "2× p.a.", "special": "Mainland-China-Benchmark für liquide Large- und Mid-Caps."},
    "SSE Science and Technology Innovation Board 50": {"url": "https://english.sse.com.cn/indices/indices/list/indexmethods/c/000688_000688hbooken_EN.pdf", "members": "50", "segment": "Onshore Tech; STAR Market", "weight": "Market Cap & Liquidität", "rebalance": "4× p.a.", "special": "Technologie-/Innovationsfokus auf dem STAR Market."},
    "ChiNext 50 Capped": {"url": "http://www.cnindex.com.cn/en/module/pdf-detail.html?pdf=/docs/gz_399673_e.pdf&name=ChiNext%2050", "members": "50", "segment": "Onshore Growth / Tech", "weight": "Free-Float Market Cap; Capped", "rebalance": "4× p.a.", "special": "Wachstums-/Innovationsfokus auf dem ChiNext-Markt."},
}
MARKET_PROXY_BY_SIGNATURE = {
    frozenset(SHARE_CLASS_ORDER): "MSCI China All Shares Stock Connect Select",
    frozenset({"B-Shares", "H-Shares", "Red Chips", "P-Chips", "Auslandslistings / ADRs"}): "MSCI China ex A Shares",
    frozenset({"H-Shares", "Red Chips", "P-Chips", "Auslandslistings / ADRs"}): "Dow Jones China Offshore 50",
    frozenset({"H-Shares", "Red Chips", "P-Chips"}): "FTSE China 50",
    frozenset({"A-Shares"}): "MSCI China A Inclusion",
}
EFFECTIVE_TAX_RATE = effective_german_equity_etf_tax_rate(0.25, 0.055, 0.30)


@cache.memoize(timeout=DAY_TTL)
def registry_cached():
    return load_registry()


@cache.memoize(timeout=DAY_TTL)
def tech_registry_cached():
    df = pd.read_csv(TECH_PATH, parse_dates=["inception"])
    df["label"] = df["etf_name"] + " (" + df["index_name"] + ")"
    return df.sort_values(["universe", "inception", "etf_name"]).reset_index(drop=True)


@cache.memoize(timeout=LONG_TTL)
def resolve_index_cached(index_name):
    try:
        return resolve_oldest_available_for_index(index_name, registry_cached()), None
    except Exception as exc:
        return None, str(exc)


@cache.memoize(timeout=LONG_TTL)
def resolve_tech_cached(etf_name):
    reg = tech_registry_cached()
    sub = reg[reg["etf_name"] == etf_name]
    return resolve_selected_rows([r for _, r in sub.iterrows()])


def parse_share_classes(value):
    result = []
    for item in [x.strip() for x in str(value).split(",") if x.strip()]:
        result.append("Auslandslistings / ADRs" if item in {"ADRs", "Foreign listings", "Auslandslistings"} else item)
    return frozenset(result)


def common_frame(series: dict, effective_tax_rate: float = EFFECTIVE_TAX_RATE) -> pd.DataFrame:
    raw = pd.DataFrame(series).sort_index()
    return transform_frame(raw, after_tax=True, effective_tax_rate=effective_tax_rate, common_start=True)


def _sharpe0(s):
    r = s.dropna().pct_change(fill_method=None).dropna()
    if len(r) < 2 or r.std(ddof=1) == 0:
        return np.nan
    return r.mean() / r.std(ddof=1) * math.sqrt(252)


def yearly_sharpe_matrix(frame, display):
    years = sorted({int(y) for c in frame.columns for y in frame[c].dropna().index.year})
    rows = []
    for col in frame.columns:
        row = {"": display.get(col, col)}
        s = frame[col].dropna()
        for y in years:
            sy = s[s.index.year == y]
            row[str(y)] = _sharpe0(sy) if len(sy) > 2 else np.nan
        rows.append(row)
    return pd.DataFrame(rows).set_index("")


def total_stats(frame, display, benchmark_by_col=None):
    rows = []
    for col in frame.columns:
        s = frame[col].dropna()
        if len(s) < 2:
            continue
        cg, dd = cagr(s), max_drawdown(s)
        r = s.pct_change(fill_method=None).dropna()
        vola = r.std(ddof=1) * math.sqrt(252) if len(r) > 1 else np.nan
        row = {"": display.get(col, col), "CAGR p.a.": cg, "Volatilität p.a.": vola,
               "Sharpe Ratio": _sharpe0(s), "Max. Drawdown": dd, "Sortino": sortino(s, 0.0),
               "Calmar": cg / abs(dd) if dd and not np.isnan(dd) else np.nan}
        if benchmark_by_col and col in benchmark_by_col:
            te, ir, _ = tracking_error_and_ir(s, benchmark_by_col[col])
            row["Tracking Error p.a."] = te
            row["Information Ratio p.a."] = ir
        rows.append(row)
    return pd.DataFrame(rows).set_index("") if rows else pd.DataFrame()


def line_spec(frame, colors, display, focus=None, dd=False, benchmark_map=None):
    series_list = []
    for col in frame.columns:
        if col.startswith("__BENCH__"):
            continue
        s = frame[col].dropna()
        y = (s / s.cummax() - 1) * 100 if dd else s
        label = display.get(col, col)
        width = 3.2 if label == focus else 1.6
        series_list.append(tv_series(label, y, colors.get(col, PALETTE[0]), line_width=width))
        if benchmark_map and col in benchmark_map and benchmark_map[col] in frame.columns:
            b = frame[benchmark_map[col]].dropna()
            by = (b / b.cummax() - 1) * 100 if dd else b
            series_list.append(tv_series(f"Market Proxy ({label})", by, colors.get(col, PALETTE[0]),
                                          dashed=True, show_last_value=False, line_width=1.3))
    return tv_spec(series_list, height=440, log_scale=not dd,
                    value_format="percent" if dd else "ratio", rebase_visible=not dd)


def correlation_option(frame, display, click_store_id=None):
    rets = frame.pct_change(fill_method=None).dropna()
    corr = rets.corr()
    names = [display.get(c, c) for c in corr.columns]
    data = []
    for i, _yname in enumerate(names):
        for j, _xname in enumerate(names):
            v = corr.values[i, j]
            data.append([j, i, None if pd.isna(v) else round(float(v), 2)])
    option = {
        "grid": {"left": 110, "right": 15, "top": 10, "bottom": 90},
        "xAxis": {"type": "category", "data": names, "axisLabel": {"rotate": 45, "fontSize": 9}, "splitArea": {"show": True}},
        "yAxis": {"type": "category", "data": names, "axisLabel": {"fontSize": 9}, "splitArea": {"show": True}},
        "visualMap": {"min": -1, "max": 1, "show": False, "inRange": {"color": ["#c0392b", "#3a3320", "#1f7a4d"]}},
        "tooltip": {"position": "top"},
        "series": [{
            "type": "heatmap", "data": data,
            "label": {"show": True, "fontSize": 9, "color": "#111827"},
            "emphasis": {"itemStyle": {"borderColor": "#e6e8ee", "borderWidth": 1.5}},
        }],
    }
    if click_store_id:
        option["__clickStoreId"] = click_store_id
    return option


def rolling_corr_spec(frame, a, b, display):
    if a not in frame.columns or b not in frame.columns:
        return tv_spec([])
    pair = frame[[a, b]].pct_change(fill_method=None).dropna()
    rolling = pair[a].rolling(252, min_periods=126).corr(pair[b])
    label = f"{display.get(a, a)} ↔ {display.get(b, b)}"
    return tv_spec([tv_series(label, rolling, PALETTE[0])], height=440, value_format="ratio",
                    hlines=[{"value": 0, "label": "0"}])


def _card(title, children, id_=None):
    kwargs = {"className": "section-card"}
    if id_:
        kwargs["id"] = id_
    return html.Div([html.Div(title, className="section-title"), *children], **kwargs)


def _render_outputs_block(key_prefix):
    return html.Div([
        dcc.Store(id=f"{key_prefix}-focus", data=None),
        dcc.Store(id=f"{key_prefix}-corr-pair", data=None),
        dmc.Grid([
            dmc.GridCol(_card("Wertentwicklung", [tv_chart(f"{key_prefix}-perf-chart", tv_spec([]))]), span=6),
            dmc.GridCol(_card("Drawdown", [tv_chart(f"{key_prefix}-dd-chart", tv_spec([]))]), span=6),
        ]),
        dmc.Grid([
            dmc.GridCol(_card("Korrelogramm (Klick = Paar für Rolling-Korrelation)",
                               [echart(f"{key_prefix}-corr-chart", {}, height=440)]), span=6),
            dmc.GridCol(_card("Rollierende 1J-Korrelation", [tv_chart(f"{key_prefix}-rollcorr-chart", tv_spec([]))]), span=6),
        ]),
        dmc.Grid([
            dmc.GridCol(_card("Jahresperformance (Sharpe Ratio, Klick = Fokus)", [
                ag_heat_table_placeholder(f"{key_prefix}-annual-table"),
            ]), span=6),
            dmc.GridCol(_card("Gesamtperformance (Klick = Fokus)", [
                ag_heat_table_placeholder(f"{key_prefix}-total-table"),
            ]), span=6),
        ]),
    ])


def _empty_outputs():
    empty = tv_spec([])
    return empty, empty, {}, empty, [], [], [], []


def _compute_outputs(series, display, colors, focus, pair, benchmark_map=None, benchmark_series=None,
                      effective_tax_rate=EFFECTIVE_TAX_RATE, corr_click_store_id=None):
    """Returns (perf_spec, dd_spec, corr_option, rollcorr_spec,
    annual_columns, annual_rows, total_columns, total_rows)"""
    if not series:
        return _empty_outputs()
    series = dict(series)
    if benchmark_map and benchmark_series:
        for _, bcol in benchmark_map.items():
            if bcol in benchmark_series:
                series[bcol] = benchmark_series[bcol]
    frame = common_frame(series, effective_tax_rate)
    if frame.empty:
        return _empty_outputs()

    perf_spec = line_spec(frame, colors, display, focus, False, benchmark_map)
    dd_spec = line_spec(frame, colors, display, focus, True, benchmark_map)

    corr_cols = [c for c in frame.columns if not c.startswith("__BENCH__")]
    corr_frame = frame[corr_cols]
    corr_option = correlation_option(corr_frame, display, corr_click_store_id)

    resolved_pair = None
    if pair:
        by_label = {display.get(c, c): c for c in corr_cols}
        a, b = by_label.get(pair[0], pair[0]), by_label.get(pair[1], pair[1])
        if a in corr_frame.columns and b in corr_frame.columns and a != b:
            resolved_pair = (a, b)
    if not resolved_pair and len(corr_cols) >= 2:
        resolved_pair = (corr_cols[0], corr_cols[1])
    rollcorr_spec = rolling_corr_spec(corr_frame, *resolved_pair, display) if resolved_pair else tv_spec([])

    annual = yearly_sharpe_matrix(corr_frame, display)
    bench_stats = {}
    if benchmark_map:
        bench_stats = {lab: frame[bcol] for lab, bcol in benchmark_map.items() if lab in corr_frame.columns and bcol in frame.columns}
    total = total_stats(corr_frame, display, bench_stats if benchmark_map else None)

    a_cols, a_rows = ag_heat_columns_rows(annual, focus_row=focus) if not annual.empty else ([], [])
    t_cols, t_rows = ag_heat_columns_rows(total, focus_row=focus) if not total.empty else ([], [])

    return perf_spec, dd_spec, corr_option, rollcorr_spec, a_cols, a_rows, t_cols, t_rows


def register_render_outputs_callbacks(app, key_prefix):
    @app.callback(
        Output(f"{key_prefix}-focus", "data"),
        Input(f"{key_prefix}-annual-table", "cellClicked"),
        Input(f"{key_prefix}-total-table", "cellClicked"),
        State(f"{key_prefix}-focus", "data"),
        prevent_initial_call=True,
    )
    def update_focus(annual_cell, total_cell, current):
        triggered = dash.callback_context.triggered_id
        cell = annual_cell if triggered == f"{key_prefix}-annual-table" else total_cell
        if not cell or not cell.get("data"):
            return dash.no_update
        name = cell["data"].get("__index__")
        return None if name == current else name

    # Correlation-heatmap cell clicks no longer round-trip through a Dash
    # callback: assets/echarts-chart.js pushes [row, col] straight into the
    # f"{key_prefix}-corr-pair" Store via window.dash_clientside.set_props
    # whenever correlation_option(..., click_store_id=...) is used.


# ---------------------------------------------------------------------------
# Market ETFs sub-page
# ---------------------------------------------------------------------------

def _index_order():
    reg = registry_cached()
    return reg[["index_order", "index_name"]].drop_duplicates().sort_values("index_order")["index_name"].tolist()


def _index_color_map():
    order = _index_order()
    return {name: PALETTE[i % len(PALETTE)] for i, name in enumerate(order)}


def _market_select_data():
    order = _index_order()
    groups: dict[str, list[str]] = {}
    for name in order:
        groups.setdefault(INDEX_SCOPE.get(name, "All Shares"), []).append(name)
    return [{"group": scope, "items": [{"value": n, "label": n} for n in names]} for scope, names in groups.items()]


def _market_layout(preselect=None):
    return html.Div([
        dmc.MultiSelect(
            id="market-select", label="Indizes auswählen", placeholder="Index wählen…",
            data=_market_select_data(), value=preselect or [], searchable=True, clearable=True,
            persistence=True, persistence_type="session", mb="md",
        ),
        html.Div(id="market-details"),
        _render_outputs_block("market"),
    ])


def _tech_select_data():
    tech = tech_registry_cached()
    groups: dict[str, list[str]] = {}
    for universe, sub in tech.groupby("universe"):
        groups.setdefault(universe, []).extend(sub["etf_name"].drop_duplicates().tolist())
    return [{"group": scope, "items": [{"value": n, "label": n} for n in names]} for scope, names in groups.items()]


def _tech_color_map():
    tech = tech_registry_cached()
    names = tech["etf_name"].drop_duplicates().tolist()
    return {name: PALETTE[i % len(PALETTE)] for i, name in enumerate(names)}


def _tech_layout(preselect=None):
    return html.Div([
        dmc.MultiSelect(
            id="tech-select", label="Tech-ETFs auswählen", placeholder="ETF wählen…",
            data=_tech_select_data(), value=preselect or [], searchable=True, clearable=True,
            persistence=True, persistence_type="session", mb="md",
        ),
        html.Div(id="tech-details"),
        _render_outputs_block("tech"),
    ])


def layout(params=None):
    params = params or {}
    select = params.get("select")
    market_preselect, tech_preselect, default_tab = None, None, "market"
    if select:
        if select in _index_order():
            market_preselect, default_tab = [select], "market"
        elif select in tech_registry_cached()["etf_name"].values:
            tech_preselect, default_tab = [select], "tech"

    return html.Div([
        dmc.Title("China ETF Dashboard", order=3, mb="md"),
        dmc.Tabs(
            [
                dmc.TabsList([
                    dmc.TabsTab("Market ETFs vergleichen", value="market"),
                    dmc.TabsTab("Tech ETFs vergleichen", value="tech"),
                ]),
                dmc.TabsPanel(_market_layout(market_preselect), value="market", pt="md"),
                dmc.TabsPanel(_tech_layout(tech_preselect), value="tech", pt="md"),
            ],
            value=default_tab, id="china-subpage-tabs", persistence=True, persistence_type="session",
        ),
        dmc.Modal(id="etf-compare-modal", title="ETFs des Index", size="xl", zIndex=1000,
                  children=html.Div(id="etf-compare-modal-body")),
    ])


def _detail_card(name, info, on_click_id, series=None, color=None):
    spark = (
        dcc.Graph(figure=sparkline_figure(series.tail(252), color), config={"staticPlot": True},
                  style={"width": "120px", "height": "44px"})
        if series is not None else None
    )
    text_block = dmc.Stack([
        dmc.Text(name, fw=700, size="sm"),
        dmc.Text(f"Segment: {info['segment']} · Gewichtung: {info['weight']} · Rebalancing: {info['rebalance']}",
                  size="xs", c="dimmed", mt=2),
        dmc.Text(info["special"], size="xs", c="dimmed", mt=2),
        dmc.Group([
            dmc.Anchor(dmc.Button("Methodology", variant="outline", size="xs", color="gray"), href=info["url"], target="_blank"),
            dmc.Button("ETF-Vergleich", id=on_click_id, size="xs", variant="light", color="orange"),
        ], mt=8, gap=8),
    ], gap=0, style={"flex": 1})
    content = dmc.Group([text_block, spark], justify="space-between", align="center", wrap="nowrap") if spark else text_block
    return dmc.Paper([content], p="sm", withBorder=True, mb=8, radius="md")


def _tax_rate_from_inputs(base, soli, teilfreistellung):
    try:
        return effective_german_equity_etf_tax_rate(
            float(base) / 100.0, float(soli) / 100.0, float(teilfreistellung) / 100.0,
        )
    except (TypeError, ValueError):
        return EFFECTIVE_TAX_RATE


def register_callbacks(app):
    register_render_outputs_callbacks(app, "market")
    register_render_outputs_callbacks(app, "tech")

    @app.callback(
        Output("market-details", "children"),
        Output({"type": "tv-chart-data", "index": "market-perf-chart"}, "data"),
        Output({"type": "tv-chart-data", "index": "market-dd-chart"}, "data"),
        Output({"type": "echart-data", "index": "market-corr-chart"}, "data"),
        Output({"type": "tv-chart-data", "index": "market-rollcorr-chart"}, "data"),
        Output("market-annual-table", "columnDefs"), Output("market-annual-table", "rowData"),
        Output("market-total-table", "columnDefs"), Output("market-total-table", "rowData"),
        Input("market-select", "value"),
        Input("market-focus", "data"),
        Input("market-corr-pair", "data"),
        Input("settings-tax-base", "value"),
        Input("settings-tax-soli", "value"),
        Input("settings-tax-teilfreistellung", "value"),
    )
    def update_market(selected, focus, pair, tax_base, tax_soli, tax_teilfreistellung):
        selected = selected or []
        color_map = _index_color_map()
        tax_rate = _tax_rate_from_inputs(tax_base, tax_soli, tax_teilfreistellung)
        details, series, display, colors = [], {}, {}, {}
        for name in selected:
            resolved, error = resolve_index_cached(name)
            if error or resolved is None:
                details.append(dmc.Alert(f"{name}: {error or 'keine Daten'}", color="yellow", mb=6))
                continue
            series[resolved.label] = resolved.series_eur
            display[resolved.label] = name
            colors[resolved.label] = color_map.get(name, PALETTE[0])
            details.append(_detail_card(name, INDEX_INFO[name], {"type": "market-etf-btn", "index": name},
                                         resolved.series_eur, colors[resolved.label]))
        outputs = _compute_outputs(series, display, colors, focus, pair, effective_tax_rate=tax_rate,
                                    corr_click_store_id="market-corr-pair")
        return [details or dmc.Text("Noch keine Indizes ausgewählt.", size="sm", c="dimmed"), *outputs]

    @app.callback(
        Output("tech-details", "children"),
        Output({"type": "tv-chart-data", "index": "tech-perf-chart"}, "data"),
        Output({"type": "tv-chart-data", "index": "tech-dd-chart"}, "data"),
        Output({"type": "echart-data", "index": "tech-corr-chart"}, "data"),
        Output({"type": "tv-chart-data", "index": "tech-rollcorr-chart"}, "data"),
        Output("tech-annual-table", "columnDefs"), Output("tech-annual-table", "rowData"),
        Output("tech-total-table", "columnDefs"), Output("tech-total-table", "rowData"),
        Input("tech-select", "value"),
        Input("tech-focus", "data"),
        Input("tech-corr-pair", "data"),
        Input("settings-tax-base", "value"),
        Input("settings-tax-soli", "value"),
        Input("settings-tax-teilfreistellung", "value"),
    )
    def update_tech(selected, focus, pair, tax_base, tax_soli, tax_teilfreistellung):
        selected = selected or []
        tech = tech_registry_cached().set_index("etf_name")
        color_map = _tech_color_map()
        tax_rate = _tax_rate_from_inputs(tax_base, tax_soli, tax_teilfreistellung)
        details, series, display, colors = [], {}, {}, {}
        benchmark_map, benchmark_series = {}, {}
        for name in selected:
            resolved_list, warnings = resolve_tech_cached(name)
            for warning in warnings:
                details.append(dmc.Alert(warning, color="yellow", mb=6))
            if not resolved_list:
                continue
            item = resolved_list[0]
            series[item.label] = item.series_eur
            display[item.label] = name
            colors[item.label] = color_map.get(name, PALETTE[0])
            row = tech.loc[name]
            proxy = MARKET_PROXY_BY_SIGNATURE.get(parse_share_classes(row["share_classes"]))
            proxy_text = proxy or "–"
            if proxy:
                bench_resolved, bench_error = resolve_index_cached(proxy)
                if bench_resolved is not None:
                    bcol = f"__BENCH__{item.label}"
                    benchmark_map[item.label] = bcol
                    benchmark_series[bcol] = bench_resolved.series_eur
            details.append(dmc.Paper([
                dmc.Group([
                    dmc.Stack([
                        dmc.Text(name, fw=700, size="sm"),
                        dmc.Text(f"Index: {row['index_name']} · TER: {row['ter']:.2f}%", size="xs", c="dimmed", mt=2),
                        dmc.Text(f"Market Proxy (Benchmark für IR/TE): {proxy_text}", size="xs", c="dimmed", mt=2),
                        dmc.Anchor(dmc.Button("ETF / Methodology", variant="outline", size="xs", color="gray", mt=8),
                                    href=row["source_url"], target="_blank"),
                    ], gap=0, style={"flex": 1}),
                    dcc.Graph(figure=sparkline_figure(item.series_eur.tail(252), colors[item.label]),
                              config={"staticPlot": True}, style={"width": "120px", "height": "44px"}),
                ], justify="space-between", align="center", wrap="nowrap"),
            ], p="sm", withBorder=True, mb=8, radius="md"))
        outputs = _compute_outputs(series, display, colors, focus, pair, benchmark_map, benchmark_series, tax_rate,
                                    corr_click_store_id="tech-corr-pair")
        return [details or dmc.Text("Noch keine Tech-ETFs ausgewählt.", size="sm", c="dimmed"), *outputs]

    @app.callback(
        Output("etf-compare-modal", "opened"),
        Output("etf-compare-modal-body", "children"),
        Output("etf-compare-modal", "title"),
        Input({"type": "market-etf-btn", "index": ALL}, "n_clicks"),
        prevent_initial_call=True,
    )
    def open_etf_dialog(clicks):
        if not clicks or not any(clicks):
            return dash.no_update, dash.no_update, dash.no_update
        triggered = dash.callback_context.triggered_id
        index_name = triggered["index"]
        reg = registry_cached()
        sub = reg[reg["index_name"] == index_name].sort_values("inception").copy()
        if sub.empty:
            return True, dmc.Text("Keine ETFs hinterlegt.", size="sm", c="dimmed"), index_name

        table = sub.copy()
        table["Auflage"] = table["inception"].dt.strftime("%d.%m.%Y")
        table["TER"] = table["ter"].map(lambda x: f"{x:.2f}%")
        show = table[["etf_name", "isin", "Auflage", "TER", "distribution"]].rename(
            columns={"etf_name": "ETF", "isin": "ISIN", "distribution": "Ertragsverwendung"})
        listing = ag_table(show)

        resolved, warnings = resolve_selected_rows([r for _, r in sub.iterrows()])
        body = [listing, *[dmc.Alert(w, color="yellow", mt=8) for w in warnings]]
        if resolved:
            series = {x.label: x.series_eur for x in resolved}
            display = {x.label: x.etf_name for x in resolved}
            colors = {x.label: PALETTE[i % len(PALETTE)] for i, x in enumerate(resolved)}
            frame = common_frame(series)
            if not frame.empty:
                body.append(dmc.Grid([
                    dmc.GridCol(tv_chart("etf-dialog-perf-chart", line_spec(frame, colors, display, None, False)), span=6),
                    dmc.GridCol(tv_chart("etf-dialog-dd-chart", line_spec(frame, colors, display, None, True)), span=6),
                ], mt="md"))
        return True, html.Div(body), f"ETFs — {index_name}"
