import sys
sys.path.insert(0, ".")
from pages import overview as ov
from src.theme import ag_heat_columns_rows
import pandas as pd

rows = {}
for item in ov.ASSET_CLASSES:
    s = ov._filtered(ov._asset_class_series.uncached(item["ticker"]), "5").dropna()
    if len(s) < 2:
        continue
    from src.metrics import cagr, max_drawdown, annual_volatility
    cg = cagr(s)
    dd = max_drawdown(s)
    rows[item["label"]] = {
        "Gesamtrendite": float(s.iloc[-1] / s.iloc[0] - 1.0),
        "CAGR p.a.": cg,
        "Volatilität p.a.": annual_volatility(s),
        "Max. Drawdown": dd,
        "Calmar": cg / abs(dd) if dd and dd == dd and dd != 0 else None,
    }
df = pd.DataFrame.from_dict(rows, orient="index")
print(df)
print(df.dtypes)

cols, rowdata = ag_heat_columns_rows(df, reverse_columns={"Volatilität p.a.", "Max. Drawdown"})
for r in rowdata:
    print(r)
