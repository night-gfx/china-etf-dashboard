(function () {
  const ITEMS = [
    { group: "Seiten", label: "Aktien", sub: "Länder und Sektoren", href: "/aktien" },
    { group: "Seiten", label: "Overview", sub: "Anlageklassen im Vergleich", href: "/" },
    { group: "Seiten", label: "Aktien / Länder", sub: "Länder-ETF-Weltkarte", href: "/laender" },
    { group: "Seiten", label: "Aktien / China Markets", sub: "Market & Tech ETFs", href: "/china-markets" },
    { group: "Seiten", label: "Aktien / S&P 500 Sectors", sub: "Sektor-Rotation", href: "/sp500-sectors" },
    { group: "Seiten", label: "Anleihen", sub: "AGG, TLT, HYG", href: "/anleihen" },
    { group: "Seiten", label: "Commodities", sub: "Rohstoff-Index & Beta", href: "/commodities" },
    { group: "Seiten", label: "Immobilien", sub: "REITs USA & International", href: "/immobilien" },
    { group: "Seiten", label: "Hedge Fonds", sub: "Liquid-Alternatives-Proxy", href: "/hedge-fonds" },
    { group: "Seiten", label: "Krypto", sub: "Bitcoin, Ethereum", href: "/krypto" },
    { group: "Seiten", label: "Geldmarkt", sub: "T-Bills, Ultrashort Bond", href: "/geldmarkt" },
    { group: "Seiten", label: "Backtesting / Asset Allocation", sub: "Backtesting Tool", href: "/asset-allocation" },

    { group: "China-Indizes", label: "MSCI China All Shares Stock Connect Select", href: "/china-markets?select=" + encodeURIComponent("MSCI China All Shares Stock Connect Select") },
    { group: "China-Indizes", label: "S&P China 500", href: "/china-markets?select=" + encodeURIComponent("S&P China 500") },
    { group: "China-Indizes", label: "FTSE China 30/18 Capped", href: "/china-markets?select=" + encodeURIComponent("FTSE China 30/18 Capped") },
    { group: "China-Indizes", label: "MSCI China", href: "/china-markets?select=" + encodeURIComponent("MSCI China") },
    { group: "China-Indizes", label: "MSCI China ex A Shares", href: "/china-markets?select=" + encodeURIComponent("MSCI China ex A Shares") },
    { group: "China-Indizes", label: "Dow Jones China Offshore 50", href: "/china-markets?select=" + encodeURIComponent("Dow Jones China Offshore 50") },
    { group: "China-Indizes", label: "FTSE China 50", href: "/china-markets?select=" + encodeURIComponent("FTSE China 50") },
    { group: "China-Indizes", label: "CSI Overseas China Internet", href: "/china-markets?select=" + encodeURIComponent("CSI Overseas China Internet") },
    { group: "China-Indizes", label: "MSCI China A", href: "/china-markets?select=" + encodeURIComponent("MSCI China A") },
    { group: "China-Indizes", label: "CSI A 500", href: "/china-markets?select=" + encodeURIComponent("CSI A 500") },
    { group: "China-Indizes", label: "MSCI China A Inclusion", href: "/china-markets?select=" + encodeURIComponent("MSCI China A Inclusion") },
    { group: "China-Indizes", label: "CSI 300", href: "/china-markets?select=" + encodeURIComponent("CSI 300") },
    { group: "China-Indizes", label: "S&P China A 300", href: "/china-markets?select=" + encodeURIComponent("S&P China A 300") },
    { group: "China-Indizes", label: "SSE Science and Technology Innovation Board 50", href: "/china-markets?select=" + encodeURIComponent("SSE Science and Technology Innovation Board 50") },
    { group: "China-Indizes", label: "ChiNext 50 Capped", href: "/china-markets?select=" + encodeURIComponent("ChiNext 50 Capped") },

    { group: "S&P 500 Sektoren", label: "Communication Services (XLC)", href: "/sp500-sectors?sector=" + encodeURIComponent("Communication Services (XLC)") },
    { group: "S&P 500 Sektoren", label: "Consumer Discretionary (XLY)", href: "/sp500-sectors?sector=" + encodeURIComponent("Consumer Discretionary (XLY)") },
    { group: "S&P 500 Sektoren", label: "Consumer Staples (XLP)", href: "/sp500-sectors?sector=" + encodeURIComponent("Consumer Staples (XLP)") },
    { group: "S&P 500 Sektoren", label: "Energy (XLE)", href: "/sp500-sectors?sector=" + encodeURIComponent("Energy (XLE)") },
    { group: "S&P 500 Sektoren", label: "Financials (XLF)", href: "/sp500-sectors?sector=" + encodeURIComponent("Financials (XLF)") },
    { group: "S&P 500 Sektoren", label: "Health Care (XLV)", href: "/sp500-sectors?sector=" + encodeURIComponent("Health Care (XLV)") },
    { group: "S&P 500 Sektoren", label: "Industrials (XLI)", href: "/sp500-sectors?sector=" + encodeURIComponent("Industrials (XLI)") },
    { group: "S&P 500 Sektoren", label: "Information Technology (XLK)", href: "/sp500-sectors?sector=" + encodeURIComponent("Information Technology (XLK)") },
    { group: "S&P 500 Sektoren", label: "Materials (XLB)", href: "/sp500-sectors?sector=" + encodeURIComponent("Materials (XLB)") },
    { group: "S&P 500 Sektoren", label: "Utilities (XLU)", href: "/sp500-sectors?sector=" + encodeURIComponent("Utilities (XLU)") },

    { group: "Commodities", label: "Gold", sub: "Metalle", href: "/commodities?class=" + encodeURIComponent("Metalle") },
    { group: "Commodities", label: "Silber", sub: "Metalle", href: "/commodities?class=" + encodeURIComponent("Metalle") },
    { group: "Commodities", label: "Kupfer", sub: "Metalle", href: "/commodities?class=" + encodeURIComponent("Metalle") },
    { group: "Commodities", label: "WTI Rohöl", sub: "Energie", href: "/commodities?class=" + encodeURIComponent("Energie") },
    { group: "Commodities", label: "Brent Rohöl", sub: "Energie", href: "/commodities?class=" + encodeURIComponent("Energie") },
    { group: "Commodities", label: "Erdgas", sub: "Energie", href: "/commodities?class=" + encodeURIComponent("Energie") },
    { group: "Commodities", label: "Mais", sub: "Getreide & Ölsaaten", href: "/commodities?class=" + encodeURIComponent("Getreide & Ölsaaten") },
    { group: "Commodities", label: "Weizen", sub: "Getreide & Ölsaaten", href: "/commodities?class=" + encodeURIComponent("Getreide & Ölsaaten") },
    { group: "Commodities", label: "Kaffee", sub: "Soft Commodities", href: "/commodities?class=" + encodeURIComponent("Soft Commodities") },
    { group: "Commodities", label: "Kakao", sub: "Soft Commodities", href: "/commodities?class=" + encodeURIComponent("Soft Commodities") },
    { group: "Commodities", label: "Live Cattle", sub: "Vieh", href: "/commodities?class=" + encodeURIComponent("Vieh") },
  ];

  let activeIndex = 0;

  function overlayEl() { return document.getElementById("cmdk-overlay"); }
  function inputEl() { return document.getElementById("cmdk-input"); }
  function resultsEl() { return document.getElementById("cmdk-results"); }

  function isOpen() {
    const el = overlayEl();
    return !!el && el.classList.contains("cmdk-visible");
  }

  function openPalette() {
    const el = overlayEl();
    if (!el) return;
    el.classList.add("cmdk-visible");
    render("");
    setTimeout(() => { const i = inputEl(); if (i) { i.value = ""; i.focus(); } }, 20);
  }

  function closePalette() {
    const el = overlayEl();
    if (el) el.classList.remove("cmdk-visible");
  }

  function render(query) {
    const results = resultsEl();
    if (!results) return;
    const q = (query || "").trim().toLowerCase();
    const filtered = q
      ? ITEMS.filter((it) => it.label.toLowerCase().includes(q) || it.group.toLowerCase().includes(q))
      : ITEMS;

    if (!filtered.length) {
      results.innerHTML = '<div class="cmdk-empty">Keine Treffer.</div>';
      return;
    }

    let html = "";
    let lastGroup = null;
    let idx = 0;
    filtered.slice(0, 60).forEach((it) => {
      if (it.group !== lastGroup) {
        html += `<div class="cmdk-group-label">${it.group}</div>`;
        lastGroup = it.group;
      }
      html += `<div class="cmdk-item" data-idx="${idx}" data-href="${it.href}">` +
        `<span>${it.label}</span>` +
        (it.sub ? `<span class="cmdk-item-sub">${it.sub}</span>` : "") +
        `</div>`;
      idx += 1;
    });
    results.innerHTML = html;
    activeIndex = 0;
    highlight();

    results.querySelectorAll(".cmdk-item").forEach((el) => {
      el.addEventListener("click", () => navigate(el.getAttribute("data-href")));
      el.addEventListener("mouseenter", () => {
        activeIndex = parseInt(el.getAttribute("data-idx"), 10);
        highlight();
      });
    });
  }

  function highlight() {
    const results = resultsEl();
    if (!results) return;
    results.querySelectorAll(".cmdk-item").forEach((el) => {
      el.classList.toggle("cmdk-active", parseInt(el.getAttribute("data-idx"), 10) === activeIndex);
    });
    const active = results.querySelector(".cmdk-item.cmdk-active");
    if (active) active.scrollIntoView({ block: "nearest" });
  }

  function navigate(href) {
    if (!href) return;
    closePalette();
    window.location.href = href;
  }

  document.addEventListener("keydown", (e) => {
    const meta = e.ctrlKey || e.metaKey;
    if (meta && (e.key === "k" || e.key === "K")) {
      e.preventDefault();
      if (isOpen()) { closePalette(); } else { openPalette(); }
      return;
    }
    if (!isOpen()) return;
    if (e.key === "Escape") {
      e.preventDefault();
      closePalette();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const count = resultsEl() ? resultsEl().querySelectorAll(".cmdk-item").length : 0;
      if (count) { activeIndex = (activeIndex + 1) % count; highlight(); }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const count = resultsEl() ? resultsEl().querySelectorAll(".cmdk-item").length : 0;
      if (count) { activeIndex = (activeIndex - 1 + count) % count; highlight(); }
    } else if (e.key === "Enter") {
      const active = resultsEl() ? resultsEl().querySelector(".cmdk-item.cmdk-active") : null;
      if (active) navigate(active.getAttribute("data-href"));
    }
  });

  document.addEventListener("click", (e) => {
    if (e.target && e.target.id === "cmdk-backdrop") closePalette();
    const trigger = e.target && e.target.closest ? e.target.closest("#cmdk-open-btn") : null;
    if (trigger) {
      e.preventDefault();
      if (isOpen()) { closePalette(); } else { openPalette(); }
    }
  });

  document.addEventListener("input", (e) => {
    if (e.target && e.target.id === "cmdk-input") render(e.target.value);
  });
})();
