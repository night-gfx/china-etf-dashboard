(function () {
  const instances = {};
  let syncing = false;

  function syncRange(source, range) {
    if (syncing || source.rendering || source.disposed || !range || !source.spec.syncGroup) return;
    syncing = true;
    try {
      Object.values(instances).forEach(function (target) {
        if (target === source || target.rendering || target.disposed ||
            target.spec.syncGroup !== source.spec.syncGroup || target.spec.syncKey !== source.spec.syncKey) return;
        const current = target.chart.timeScale().getVisibleLogicalRange();
        if (!current || Math.abs(current.from - range.from) > 0.001 || Math.abs(current.to - range.to) > 0.001) {
          target.chart.timeScale().setVisibleLogicalRange(range);
        }
      });
    } finally { syncing = false; }
  }

  function timeKey(time) {
    if (typeof time !== "object") return time;
    return `${time.year}-${String(time.month).padStart(2, "0")}-${String(time.day).padStart(2, "0")}`;
  }

  function scheduleRebase(inst) {
    if (inst.rebaseFrame || !inst.spec.rebaseVisible) return;
    inst.rebaseFrame = requestAnimationFrame(function () {
      inst.rebaseFrame = null;
      if (inst.disposed || inst.rendering || !inst.container.isConnected) return;
      const range = inst.chart.timeScale().getVisibleRange();
      if (!range) return;
      const from = timeKey(range.from);
      const to = timeKey(range.to);
      (inst.spec.series || []).forEach(function (s) {
        const series = inst.series[s.name];
        if (!series) return;
        const data = s.data || [];
        // Use the original values on every change to avoid cumulative rounding.
        // A series with missing dates starts at its first available visible point.
        const base = data.find(d => timeKey(d.time) >= from && timeKey(d.time) <= to && Number.isFinite(d.value));
        if (!base || base.value === 0 || inst.bases[s.name] === base.time) return;
        inst.bases[s.name] = base.time;
        series.setData(data.map(d => ({ ...d, value: d.value / base.value * 100 })));
      });
    });
  }

  function colors() {
    // Charts always render on a solid white plate regardless of the app's
    // dark/light shell theme - keeps every chart's palette/labeling uniform.
    return { bg: "#ffffff", text: "#16181d", muted: "#6b7280", border: "#e3e5ea" };
  }

  function fmtValue(v, fmt) {
    if (v === null || v === undefined || isNaN(v)) return "–";
    if (fmt === "percent") return (v >= 0 ? "+" : "") + v.toFixed(2) + " %";
    if (fmt === "pp") return (v >= 0 ? "+" : "") + v.toFixed(2) + " %-Pkt.";
    if (fmt === "ratio") return v.toFixed(2);
    return v.toLocaleString("de-DE", { maximumFractionDigits: 2 });
  }

  function buildLegend(container) {
    const legend = document.createElement("div");
    legend.className = "tv-legend";
    container.style.position = "relative";
    container.appendChild(legend);
    return legend;
  }

  function render(divId, spec) {
    const container = document.getElementById(divId);
    if (!container || !window.LightweightCharts) return;
    container._lastSpec = spec;
    const c = colors();

    let inst = instances[divId];
    // A period change can remove dates still referenced by the old visible
    // range. Recreate the chart atomically instead of removing its last series
    // while Lightweight Charts is dispatching time-range events.
    if (inst) {
      inst.disposed = true;
      cancelAnimationFrame(inst.rebaseFrame);
      inst.observer.disconnect();
      inst.chart.remove();
      delete instances[divId];
      inst = null;
    }
    if (!inst || inst.disposed) {
      container.innerHTML = "";
      const chart = LightweightCharts.createChart(container, {
        width: container.clientWidth || 400,
        height: container.clientHeight || spec.height || 420,
        layout: { background: { type: "solid", color: c.bg }, textColor: c.muted, fontFamily: "Arial, sans-serif", fontSize: 14 },
        grid: { vertLines: { visible: false }, horzLines: { visible: false } },
        rightPriceScale: { borderColor: c.border, mode: spec.logScale ? 1 : 0, minimumWidth: spec.syncGroup ? 100 : 0 },
        timeScale: { borderColor: c.border, fixLeftEdge: true, fixRightEdge: true, rightOffset: 2 },
        crosshair: { mode: 0, vertLine: { color: c.muted, width: 1, style: 3, labelBackgroundColor: c.bg }, horzLine: { visible: false, labelVisible: false } },
        handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
        handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: false },
      });
      const legend = buildLegend(container);
      inst = { chart, container, spec, series: {}, bases: {}, legend, disposed: false, rendering: true };
      instances[divId] = inst;
      chart.timeScale().subscribeVisibleTimeRangeChange(function () { scheduleRebase(inst); });
      chart.timeScale().subscribeVisibleLogicalRangeChange(function (range) { syncRange(inst, range); });

      chart.subscribeCrosshairMove(function (param) {
        if (!param || !param.time) {
          legend.innerHTML = inst.defaultLegendHtml || "";
          return;
        }
        let html = inst.dateLabel ? `<div class="tv-legend-date">${param.time}</div>` : "";
        (inst.spec.series || []).forEach(function (s) {
          const ser = inst.series[s.name];
          if (!ser) return;
          const d = param.seriesData.get(ser);
          const v = d ? (d.value !== undefined ? d.value : d.close) : null;
          html += `<div class="tv-legend-row"><span class="tv-dot" style="background:${s.color}"></span>${s.name}: <b>${fmtValue(v, inst.spec.valueFormat)}</b></div>`;
        });
        legend.innerHTML = html;
      });

      inst.observer = new ResizeObserver(function () {
        if (container.clientWidth > 0) chart.resize(container.clientWidth, container.clientHeight || inst.spec.height || 420);
      });
      inst.observer.observe(container);
    } else {
      inst.chart.applyOptions({
        layout: { textColor: c.muted },
        rightPriceScale: { borderColor: c.border },
        timeScale: { borderColor: c.border },
      });
    }
    inst.spec = spec;
    inst.rendering = true;
    inst.bases = {};

    // Rebuild series from scratch each render - simplest correct way to
    // handle series being added/removed/re-colored between updates.
    Object.values(inst.series).forEach(function (s) { try { inst.chart.removeSeries(s); } catch (e) {} });
    inst.series = {};

    let legendHtml = "";
    (spec.series || []).forEach(function (s) {
      const seriesOptions = {
        color: s.color,
        lineWidth: s.lineWidth || 2,
        lineStyle: s.dashed ? 2 : 0,
        priceLineVisible: false,
        lastValueVisible: !!s.showLastValue,
        crosshairMarkerRadius: 3,
        priceFormat: spec.valueFormat === "percent" || spec.valueFormat === "pp"
          ? { type: "custom", formatter: function (v) { return fmtValue(v, spec.valueFormat); } }
          : { type: "price", precision: 2, minMove: 0.01 },
      };
      let series;
      if (s.type === "area") {
        series = inst.chart.addAreaSeries(Object.assign(seriesOptions, {
          topColor: s.areaTop || s.color + "55",
          bottomColor: s.areaBottom || s.color + "03",
          lineWidth: s.lineWidth || 1.5,
        }));
      } else {
        series = inst.chart.addLineSeries(seriesOptions);
      }
      series.setData(s.data || []);
      if (s.markers && s.markers.length && series.setMarkers) {
        series.setMarkers(s.markers.map(function (m) {
          return {
            time: m.time, position: m.position || "inBar", color: m.color || s.color,
            shape: m.shape || "circle", text: m.text || "",
          };
        }));
      }
      inst.series[s.name] = series;
      legendHtml += `<div class="tv-legend-row"><span class="tv-dot" style="background:${s.color}"></span>${s.name}</div>`;
    });

    const firstSeries = Object.values(inst.series)[0];
    if (firstSeries) {
      (spec.hlines || []).forEach(function (h) {
        firstSeries.createPriceLine({ price: h.value, color: h.color || c.muted, lineWidth: 1, lineStyle: 3, axisLabelVisible: false, title: h.label || "" });
      });
    }
    inst.defaultLegendHtml = spec.showLegend === false ? "" : legendHtml;
    inst.legend.innerHTML = inst.defaultLegendHtml;
    inst.legend.className = "tv-legend" + (spec.legendPosition === "bottom" ? " tv-legend-bottom" : "");

    inst.chart.timeScale().fitContent();
    inst.rendering = false;
    scheduleRebase(inst);
    requestAnimationFrame(function () {
      if (!inst.disposed) syncRange(inst, inst.chart.timeScale().getVisibleLogicalRange());
    });
  }

  window.renderTVChart = render;
  new MutationObserver(function () {
    Object.keys(instances).forEach(function (id) {
      const inst = instances[id];
      if (!inst.container.isConnected) {
        inst.disposed = true;
        cancelAnimationFrame(inst.rebaseFrame);
        inst.observer.disconnect();
        inst.chart.remove();
        delete instances[id];
      }
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
