import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1400, "height": 1000})
        await page.goto("http://127.0.0.1:8050/commodities", wait_until="load", timeout=60000)
        await page.wait_for_timeout(4000)
        loc = page.locator("#commodity-index-chart")
        await loc.scroll_into_view_if_needed()
        await page.wait_for_timeout(1000)
        await loc.screenshot(path="scratch_index_chart.png")
        info = await page.evaluate("""
            () => {
                const el = document.getElementById('commodity-index-chart');
                if (!el) return 'no element';
                return JSON.stringify({children: el.children.length, canvases: el.querySelectorAll('canvas').length, html: el.innerHTML.slice(0,150)});
            }
        """)
        print(info)
        await browser.close()

asyncio.run(main())
