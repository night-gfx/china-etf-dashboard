(function () {
  "use strict";

  const roots = new Map();
  const h = window.React && window.React.createElement;

  function formatValue(value, kind) {
    if (value === null || value === undefined || !Number.isFinite(Number(value))) return "–";
    const number = Number(value);
    if (kind === "percent") return `${number >= 0 ? "+" : ""}${number.toFixed(2)} %`;
    if (kind === "ratio") return number.toFixed(2);
    return number.toLocaleString("de-DE", { maximumFractionDigits: 2 });
  }

  function combineSeries(series) {
    const rowsByDate = new Map();
    const metadata = (series || []).map(function (item, index) {
      const key = `series_${index}`;
      (item.data || []).forEach(function (point) {
        const row = rowsByDate.get(point.time) || { time: point.time };
        row[key] = point.value;
        rowsByDate.set(point.time, row);
      });
      const last = (item.data || [])[Math.max(0, (item.data || []).length - 1)];
      return {
        key: key,
        name: item.name,
        color: item.color,
        lineWidth: item.lineWidth || 2,
        lastValue: last ? last.value : null,
      };
    });
    const rows = Array.from(rowsByDate.values()).sort(function (a, b) {
      return a.time.localeCompare(b.time);
    });
    return { rows: rows, metadata: metadata };
  }

  function tooltipFactory(valueFormat) {
    return function RechartsTooltip(props) {
      if (!props.active || !props.payload || !props.payload.length) return null;
      return h("div", { className: "overview-recharts-tooltip" }, [
        h("div", { className: "overview-recharts-tooltip-date", key: "date" }, props.label),
        ...props.payload.filter(function (entry) {
          return entry.value !== null && entry.value !== undefined;
        }).map(function (entry) {
          return h("div", { className: "overview-recharts-tooltip-row", key: entry.dataKey }, [
            h("span", {
              className: "overview-recharts-tooltip-dot",
              style: { backgroundColor: entry.color },
              key: "dot",
            }),
            h("span", { key: "name" }, entry.name),
            h("strong", { key: "value" }, formatValue(entry.value, valueFormat)),
          ]);
        }),
      ]);
    };
  }

  function legendFactory(metadata, valueFormat) {
    return function RechartsLegend() {
      return h("div", { className: "overview-recharts-legend" }, metadata.map(function (item) {
        return h("div", { className: "overview-recharts-legend-item", key: item.key }, [
          h("span", {
            className: "overview-recharts-legend-dot",
            style: { backgroundColor: item.color },
            key: "dot",
          }),
          h("span", { key: "name" }, item.name),
          h("strong", { key: "value" }, formatValue(item.lastValue, valueFormat)),
        ]);
      }));
    };
  }

  function dateFormatter(value) {
    const parts = /^(\d{4})-(\d{2})-\d{2}$/.exec(String(value));
    return parts ? `${parts[2]}.${parts[1].slice(-2)}` : value;
  }

  const SPARK_UP = "#16865c";
  const SPARK_DOWN = "#c54848";

  function sparkline(spec, rows, metadata, width, height) {
    const R = window.Recharts;
    const item = metadata[0];
    const ref = spec.referenceValue;
    const hasRef = Number.isFinite(ref);
    // Split the series into an "above previous close" and a "below previous
    // close" track, each clamped to the reference value on the other side -
    // stacked as two Areas sharing that baseline this draws a green fill
    // above / red fill below the dashed reference line instead of one flat
    // color, the classic "vs. previous close" ticker look.
    const dataRows = hasRef ? rows.map(function (row) {
      const v = row[item.key];
      if (!Number.isFinite(v)) return Object.assign({}, row, { __pos: null, __neg: null });
      return Object.assign({}, row, {
        __pos: v >= ref ? v : ref,
        __neg: v <= ref ? v : ref,
      });
    }) : rows;
    const children = [
      h(R.XAxis, { key: "x", dataKey: "time", hide: true }),
      h(R.YAxis, { key: "y", hide: true, domain: ["dataMin", "dataMax"] }),
    ];
    if (hasRef) {
      children.push(h(R.ReferenceLine, {
        key: "prev-close", y: ref, stroke: "#9ca3af", strokeDasharray: "2 2", strokeWidth: 1,
      }));
      children.push(h(R.Area, {
        key: "pos", type: "linear", dataKey: "__pos", baseValue: ref,
        stroke: "none", fill: SPARK_UP, fillOpacity: 0.16,
        connectNulls: true, isAnimationActive: false,
      }));
      children.push(h(R.Area, {
        key: "neg", type: "linear", dataKey: "__neg", baseValue: ref,
        stroke: "none", fill: SPARK_DOWN, fillOpacity: 0.16,
        connectNulls: true, isAnimationActive: false,
      }));
    }
    children.push(h(R.Line, {
      key: item.key,
      type: "linear",
      dataKey: item.key,
      stroke: item.color,
      strokeWidth: item.lineWidth,
      dot: false,
      activeDot: false,
      connectNulls: true,
      isAnimationActive: false,
    }));
    // Explicit pixel size instead of ResponsiveContainer: with very few points
    // (e.g. an intraday series early in the session) the async ResizeObserver
    // measurement it relies on could still be pending on first paint, leaving
    // the sparkline blank. The container is already a fixed/definite size, so
    // there's nothing to gain from measuring asynchronously.
    return h(R.ComposedChart, { width: width, height: height, data: dataRows, margin: { top: 3, right: 4, bottom: 3, left: 1 } }, children);
  }

  function TimeSeriesChart(props) {
    const R = window.Recharts;
    const { useState, useEffect, useRef } = window.React;
    const spec = props.spec, rows = props.rows, metadata = props.metadata;
    const valueFormat = spec.valueFormat || "plain";
    const [zoomRange, setZoomRange] = useState(null);
    const [dragState, setDragState] = useState(null);
    const draggingRef = useRef(false);
    const dragLeftRef = useRef(null);
    const dragRightRef = useRef(null);

    useEffect(function () {
      setZoomRange(null);
      setDragState(null);
      draggingRef.current = false;
      dragLeftRef.current = null;
      dragRightRef.current = null;
    }, [rows]);

    const visibleRows = zoomRange
      ? rows.filter(function (row) { return row.time >= zoomRange.left && row.time <= zoomRange.right; })
      : rows;

    function handleMouseDown(e) {
      draggingRef.current = true;
      const label = e && e.activeLabel !== undefined ? e.activeLabel : null;
      dragLeftRef.current = label;
      dragRightRef.current = label;
      setDragState(label !== null ? { left: label, right: label } : null);
    }
    function handleMouseMove(e) {
      if (!draggingRef.current || !e || e.activeLabel === undefined) return;
      if (dragLeftRef.current === null) dragLeftRef.current = e.activeLabel;
      dragRightRef.current = e.activeLabel;
      setDragState({ left: dragLeftRef.current, right: dragRightRef.current });
    }
    function handleMouseUp() {
      if (!draggingRef.current) return;
      draggingRef.current = false;
      let left = dragLeftRef.current, right = dragRightRef.current;
      dragLeftRef.current = null;
      dragRightRef.current = null;
      setDragState(null);
      if (left === null || right === null || left === right) return;
      if (left > right) { const tmp = left; left = right; right = tmp; }
      if (spec.rangeStoreId && window.dash_clientside && window.dash_clientside.set_props) {
        window.dash_clientside.set_props(spec.rangeStoreId, { data: { start: left, end: right } });
      } else {
        setZoomRange({ left: left, right: right });
      }
    }
    function handleDoubleClick() {
      if (spec.rangeStoreId && spec.resetRange && window.dash_clientside && window.dash_clientside.set_props) {
        window.dash_clientside.set_props(spec.rangeStoreId, { data: { ...spec.resetRange, reset: true } });
      }
      setZoomRange(null);
      draggingRef.current = false;
      dragLeftRef.current = null;
      dragRightRef.current = null;
      setDragState(null);
    }

    const children = [
      h(R.CartesianGrid, { key: "grid", vertical: false, stroke: "#e3e5ea", strokeDasharray: "3 3" }),
      h(R.XAxis, {
        key: "x",
        dataKey: "time",
        tickFormatter: dateFormatter,
        minTickGap: 42,
        tick: { fill: "#6b7280", fontSize: 12 },
        tickLine: false,
        axisLine: { stroke: "#e3e5ea" },
        allowDataOverflow: true,
      }),
      h(R.YAxis, {
        key: "y",
        orientation: "right",
        width: 68,
        scale: spec.logScale ? "log" : "auto",
        domain: spec.logScale ? ["auto", "auto"] : ["auto", "auto"],
        tickFormatter: function (value) { return formatValue(value, valueFormat); },
        tick: { fill: "#6b7280", fontSize: 12 },
        tickLine: false,
        axisLine: false,
        allowDataOverflow: true,
      }),
      h(R.Tooltip, {
        key: "tooltip",
        content: h(tooltipFactory(valueFormat)),
        cursor: { stroke: "#9ca3af", strokeDasharray: "3 3" },
        isAnimationActive: false,
      }),
    ];

    if (valueFormat === "percent") {
      children.push(h(R.ReferenceLine, { key: "zero", y: 0, stroke: "#8bd17c", strokeWidth: 1.2 }));
    }
    if (spec.showLegend !== false) {
      children.push(h(R.Legend, {
        key: "legend",
        verticalAlign: "top",
        align: "left",
        content: h(legendFactory(metadata, valueFormat)),
      }));
    }
    metadata.forEach(function (item) {
      children.push(h(R.Line, {
        key: item.key,
        type: "linear",
        dataKey: item.key,
        name: item.name,
        stroke: item.color,
        strokeWidth: item.lineWidth,
        dot: false,
        activeDot: { r: 3.5, strokeWidth: 0 },
        connectNulls: true,
        isAnimationActive: false,
      }));
    });

    if (dragState && dragState.left !== dragState.right) {
      const left = dragState.left < dragState.right ? dragState.left : dragState.right;
      const right = dragState.left < dragState.right ? dragState.right : dragState.left;
      children.push(h(R.ReferenceArea, {
        key: "zoom-selection", x1: left, x2: right,
        strokeOpacity: 0.4, fill: "#7c9cff", fillOpacity: 0.15,
      }));
    }

    return h(R.ResponsiveContainer, { width: "100%", height: "100%" },
      h(R.LineChart, {
        data: visibleRows,
        syncId: spec.syncId || undefined,
        syncMethod: "value",
        margin: { top: 8, right: 8, bottom: 4, left: 8 },
        accessibilityLayer: true,
        onMouseDown: handleMouseDown,
        onMouseMove: handleMouseMove,
        onMouseUp: handleMouseUp,
        onDoubleClick: handleDoubleClick,
      }, children)
    );
  }

  function mount(container, node) {
    let root = roots.get(container);
    if (!root) {
      root = window.ReactDOM.createRoot(container);
      roots.set(container, root);
    }
    root.render(node);
  }

  function render(chartId, spec) {
    const container = document.getElementById(chartId);
    if (!container) return;
    if (!h || !window.ReactDOM || !window.Recharts) {
      container.innerHTML = '<div class="overview-chart-error">Diagramm konnte nicht geladen werden.</div>';
      return;
    }
    const combined = combineSeries(spec.series || []);
    container._lastSpec = spec;
    mount(
      container,
      spec.sparkline
        ? sparkline(spec, combined.rows, combined.metadata,
            container.clientWidth || 100, container.clientHeight || spec.height || 68)
        : h(TimeSeriesChart, { spec: spec, rows: combined.rows, metadata: combined.metadata })
    );
  }

  window.renderRecharts = render;

  new MutationObserver(function () {
    roots.forEach(function (root, container) {
      if (!container.isConnected) {
        root.unmount();
        roots.delete(container);
      }
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
