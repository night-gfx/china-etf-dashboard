(function () {
  function colors() {
    const light = document.documentElement.getAttribute("data-theme") === "light";
    return light
      ? { bg: "#ffffff", text: "#16181d", muted: "#6b7280", grid: "#e3e5ea" }
      : { bg: "#12161f", text: "#e6e8ee", muted: "#8a93a6", grid: "#242b3a" };
  }

  function isSparkline(gd) {
    const xa = gd.layout && gd.layout.xaxis;
    const ya = gd.layout && gd.layout.yaxis;
    return !!((xa && xa.visible === false) || (ya && ya.visible === false));
  }

  function dateBounds(gd) {
    const xType = gd._fullLayout && gd._fullLayout.xaxis && gd._fullLayout.xaxis.type;
    if (xType !== "date") return null;
    let minT = Infinity;
    let maxT = -Infinity;
    (gd.data || []).forEach(function (trace) {
      if (!trace.x || !trace.x.length) return;
      [trace.x[0], trace.x[trace.x.length - 1]].forEach(function (v) {
        const t = new Date(v).getTime();
        if (!isNaN(t)) {
          if (t < minT) minT = t;
          if (t > maxT) maxT = t;
        }
      });
    });
    if (!isFinite(minT) || !isFinite(maxT) || minT === maxT) return null;
    return [new Date(minT).toISOString(), new Date(maxT).toISOString()];
  }

  function styleGraph(gd) {
    if (!gd || !window.Plotly || !gd.layout || !gd.data) return;
    const c = colors();
    const sparkline = isSparkline(gd);
    const bg = sparkline ? "rgba(0,0,0,0)" : c.bg;
    const update = {
      paper_bgcolor: bg,
      plot_bgcolor: bg,
      "font.color": c.text,
      "legend.font.color": c.muted,
      "legend.bgcolor": "rgba(0,0,0,0)",
      "xaxis.color": c.muted,
      "xaxis.linecolor": c.grid,
      "xaxis.gridcolor": c.grid,
      "yaxis.color": c.muted,
      "yaxis.linecolor": c.grid,
      "yaxis.gridcolor": c.grid,
      "hoverlabel.bgcolor": c.bg,
      "hoverlabel.bordercolor": c.grid,
      "hoverlabel.font.color": c.text,
    };
    if (!sparkline) {
      update["xaxis.showspikes"] = true;
      update["xaxis.spikemode"] = "across";
      update["xaxis.spikedash"] = "solid";
      update["xaxis.spikethickness"] = 1;
      update["xaxis.spikecolor"] = c.muted;
      update["yaxis.showspikes"] = false;

      const bounds = dateBounds(gd);
      if (bounds) {
        update["xaxis.minallowed"] = bounds[0];
        update["xaxis.maxallowed"] = bounds[1];
      }
    }
    if (gd.layout.geo) {
      update["geo.bgcolor"] = "rgba(0,0,0,0)";
      update["geo.landcolor"] = c.grid;
      update["geo.oceancolor"] = bg;
      update["geo.lakecolor"] = bg;
      update["geo.subunitcolor"] = c.grid;
      update["geo.showocean"] = true;
    }

    gd._restyling = true;
    Plotly.relayout(gd, update)
      .then(function () { gd._restyling = false; })
      .catch(function () { gd._restyling = false; });
  }

  function attachAndStyle(gd) {
    if (gd._themeHooked) return;
    gd._themeHooked = true;
    styleGraph(gd);
    if (gd.on) {
      gd.on("plotly_afterplot", function () {
        if (gd._restyling) return;
        styleGraph(gd);
      });
    }
  }

  function styleAll() {
    document.querySelectorAll(".js-plotly-plot").forEach(attachAndStyle);
  }

  let pending = false;
  function scheduleStyleAll() {
    if (pending) return;
    pending = true;
    setTimeout(function () { pending = false; styleAll(); }, 40);
  }

  // Plotly mounts an empty wrapper div first and adds the "js-plotly-plot"
  // class to it once rendering starts, so watching only for newly *added*
  // nodes misses it. React to any DOM/class churn instead and let the
  // (idempotent, debounced) styleAll() sort out what actually needs styling.
  const domObserver = new MutationObserver(scheduleStyleAll);
  domObserver.observe(document.body, {
    childList: true, subtree: true, attributes: true, attributeFilter: ["class"],
  });

  // On a theme toggle, every already-hooked graph needs a fresh relayout too.
  const themeObserver = new MutationObserver(function () {
    document.querySelectorAll(".js-plotly-plot").forEach(styleGraph);
  });
  themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });

  document.addEventListener("DOMContentLoaded", scheduleStyleAll);
  setTimeout(scheduleStyleAll, 400);
  setTimeout(scheduleStyleAll, 1200);
})();
