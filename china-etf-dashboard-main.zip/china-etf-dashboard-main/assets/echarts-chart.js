(function () {
  const instances = {};

  function themeColors() {
    // Charts always render on a solid white plate regardless of the app's
    // dark/light shell theme - keeps every chart's palette/labeling uniform.
    return { bg: "#ffffff", text: "#16181d", muted: "#6b7280", grid: "#e3e5ea" };
  }

  function applyTheme(option) {
    const c = themeColors();
    const themed = JSON.parse(JSON.stringify(option));
    themed.backgroundColor = c.bg;
    themed.textStyle = Object.assign({ color: c.text }, themed.textStyle || {});
    if (themed.legend) {
      themed.legend = Object.assign({}, themed.legend, {
        textStyle: Object.assign({ color: c.muted, fontSize: 11 }, themed.legend.textStyle || {}),
      });
    }
    if (themed.tooltip) {
      themed.tooltip = Object.assign({}, themed.tooltip, {
        backgroundColor: c.bg, borderColor: c.grid, textStyle: { color: c.text, fontSize: 12 },
      });
    }
    if (themed.visualMap) {
      themed.visualMap = Object.assign({}, themed.visualMap, {
        textStyle: Object.assign({ color: c.muted, fontSize: 10 }, themed.visualMap.textStyle || {}),
      });
    }
    ["xAxis", "yAxis"].forEach(function (key) {
      if (!themed[key]) return;
      const axes = Array.isArray(themed[key]) ? themed[key] : [themed[key]];
      axes.forEach(function (ax) {
        ax.axisLine = Object.assign({}, ax.axisLine, { lineStyle: Object.assign({ color: c.grid }, (ax.axisLine || {}).lineStyle || {}) });
        ax.axisLabel = Object.assign({ color: c.muted, fontSize: 10 }, ax.axisLabel || {});
        // No background gridlines on any chart - only splitArea (heatmap cell
        // shading) is a deliberate exception, left untouched below.
        ax.splitLine = { show: false };
      });
      themed[key] = Array.isArray(themed[key]) ? axes : axes[0];
    });
    return themed;
  }

  function render(divId, option) {
    const dom = document.getElementById(divId);
    if (!dom || !window.echarts) return;
    dom._lastOption = option;
    let inst = instances[divId];
    if (!inst || inst.isDisposed()) {
      inst = echarts.init(dom);
      instances[divId] = inst;
      new ResizeObserver(function () { if (dom.clientWidth > 0) inst.resize(); }).observe(dom);
    }
    inst.setOption(applyTheme(option), true);

    // Heatmap/scatter cell clicks feed straight into a Dash Store via
    // set_props, bypassing the need for a bespoke clientside callback per
    // chart - option.__clickStoreId names which Store to push [row, col]
    // category names into (see correlation charts).
    if (option.__clickStoreId && !inst._clickBound) {
      inst._clickBound = true;
      inst.on("click", function (params) {
        if (params.componentType !== "series" || !params.data) return;
        const opt = dom._lastOption || {};
        const xData = opt.xAxis && opt.xAxis.data;
        const yData = opt.yAxis && opt.yAxis.data;
        const xName = xData ? xData[params.data[0]] : null;
        const yName = yData ? yData[params.data[1]] : null;
        if (xName && yName && xName !== yName && opt.__clickStoreId && window.dash_clientside && window.dash_clientside.set_props) {
          window.dash_clientside.set_props(opt.__clickStoreId, { data: [yName, xName] });
        }
      });
    }
  }

  window.renderEChart = render;
})();
