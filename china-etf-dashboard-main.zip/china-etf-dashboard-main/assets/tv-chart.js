(function () {
  // Lightweight Charts renders its canvases at CSS-size * devicePixelRatio.
  // Below 100% browser zoom that ratio drops under 1 (e.g. ~0.6 at 60% zoom),
  // so the canvas gets fewer physical pixels than its CSS size and looks
  // soft/blurry - the browser then has to upscale it. Force a floor of 1 so
  // charts always render at (at least) "normal" density and get scaled
  // *down* by zoom instead, which stays crisp. Best-effort: falls through
  // silently if the browser doesn't allow redefining the property.
  try {
    const proto = window.Window && window.Window.prototype;
    const desc = proto && Object.getOwnPropertyDescriptor(proto, "devicePixelRatio");
    if (desc && typeof desc.get === "function" && desc.configurable) {
      const nativeGet = desc.get;
      Object.defineProperty(window, "devicePixelRatio", {
        configurable: true,
        enumerable: desc.enumerable,
        get: function () { return Math.max(1, nativeGet.call(window)); },
      });
    }
  } catch (e) { /* not supported here - charts just use the native ratio */ }

  const instances = {};
  const lastStoreRanges = {};
  let syncing = false;

  function syncRange(source, range) {
    if (syncing || source.rendering || source.transforming || source.disposed || !range || !source.spec.syncGroup) return;
    syncing = true;
    try {
      Object.values(instances).forEach(function (target) {
        if (target === source || target.rendering || target.disposed ||
            target.spec.syncGroup !== source.spec.syncGroup || target.spec.syncKey !== source.spec.syncKey) return;
        const current = target.chart.timeScale().getVisibleLogicalRange();
        if (!current || Math.abs(current.from - range.from) > 0.001 || Math.abs(current.to - range.to) > 0.001) {
          target.chart.timeScale().setVisibleLogicalRange(range);
        }
      });
    } finally { syncing = false; }
  }

  function timeKey(time) {
    if (typeof time !== "object") return time;
    return `${time.year}-${String(time.month).padStart(2, "0")}-${String(time.day).padStart(2, "0")}`;
  }

  function scheduleVisibleTransform(inst) {
    const transform = inst.spec.visibleTransform || (inst.spec.rebaseVisible ? "indexed" : null);
    if (!transform || inst.transforming) return;
    if (inst.transformRAF) return;
    inst.transformRAF = window.requestAnimationFrame(function () {
      inst.transformRAF = null;
      if (inst.disposed || inst.rendering || inst.transforming || !inst.container.isConnected) return;
      const range = inst.chart.timeScale().getVisibleRange();
      if (!range || range.from === undefined || range.to === undefined) return;
      const from = timeKey(range.from);
      const to = timeKey(range.to);
      inst.transforming = true;
      (inst.spec.series || []).forEach(function (s) {
        const series = inst.series[s.name];
        if (!series) return;
        const data = s.data || [];
        const base = data.find(d => timeKey(d.time) >= from && timeKey(d.time) <= to && Number.isFinite(d.value));
        if (!base || base.value === 0) return;
        const transformKey = `${transform}:${timeKey(base.time)}`;
        if (inst.bases[s.name] === transformKey) return;
        inst.bases[s.name] = transformKey;
        if (transform === "drawdown") {
          let runningMaximum = -Infinity;
          let started = false;
          series.setData(data.map(function (d) {
            if (!Number.isFinite(d.value) || timeKey(d.time) < timeKey(base.time)) {
              return { ...d, value: 0 };
            }
            started = true;
            runningMaximum = Math.max(runningMaximum, d.value);
            return { ...d, value: started && runningMaximum > 0 ? (d.value / runningMaximum - 1) * 100 : 0 };
          }));
        } else if (transform === "return") {
          series.setData(data.map(d => ({ ...d, value: (d.value / base.value - 1) * 100 })));
        } else {
          series.setData(data.map(d => ({ ...d, value: d.value / base.value * 100 })));
        }
      });
      inst.chart.timeScale().setVisibleRange({ from: range.from, to: range.to });
      inst.transforming = false;
      updateValueLabels(inst);
    });
  }

  function reportVisibleRange(inst) {
    if (inst.rendering || inst.ignoreRangeEvents || !inst.spec.rangeStoreId || !window.dash_clientside || !window.dash_clientside.set_props) return;
    const range = inst.chart.timeScale().getVisibleRange();
    if (!range || !range.from || !range.to) return;
    const asDate = function (value) {
      if (typeof value === "string") return value;
      if (typeof value === "number") return new Date(value * 1000).toISOString().slice(0, 10);
      return `${value.year}-${String(value.month).padStart(2, "0")}-${String(value.day).padStart(2, "0")}`;
    };
    let start = asDate(range.from), end = asDate(range.to);
    if (!start || !end || start >= end) return;
    const data = { start: start, end: end };
    if (inst.lastReportedRange && inst.lastReportedRange.start === data.start &&
        inst.lastReportedRange.end === data.end) return;
    const sharedLastRange = lastStoreRanges[inst.spec.rangeStoreId];
    if (sharedLastRange && sharedLastRange.start === data.start && sharedLastRange.end === data.end) return;
    inst.lastReportedRange = data;
    lastStoreRanges[inst.spec.rangeStoreId] = data;
    window.dash_clientside.set_props(inst.spec.rangeStoreId, { data });
  }

  function scheduleRangeReport(inst) {
    if (inst.rendering || inst.ignoreRangeEvents || inst.disposed) return;
    if (inst.rangeReportTimer) window.clearTimeout(inst.rangeReportTimer);
    inst.rangeReportTimer = window.setTimeout(function () {
      inst.rangeReportTimer = null;
      reportVisibleRange(inst);
    }, 320);
  }

  function colors() {
    // Charts always render on a solid white plate regardless of the app's
    // dark/light shell theme - keeps every chart's palette/labeling uniform.
    return { bg: "#ffffff", text: "#16181d", muted: "#6b7280", border: "#e3e5ea" };
  }

  function fmtValue(v, fmt) {
    if (v === null || v === undefined || isNaN(v)) return "–";
    if (fmt === "percent") return (v > 0 ? "+" : "") + v.toFixed(2) + " %";
    if (fmt === "pp") return (v >= 0 ? "+" : "") + v.toFixed(2) + " %-Pkt.";
    if (fmt === "ratio") return v.toFixed(2);
    return v.toLocaleString("de-DE", { maximumFractionDigits: 2 });
  }

  function buildLegend(container, position) {
    // Lives in normal flow directly above or below the chart - never an
    // overlay on the plot area - so it never covers the lines and never
    // needs to move out of the way of the data.
    const legend = document.createElement("div");
    legend.className = "tv-legend";
    if (position === "bottom") {
      container.parentNode.insertBefore(legend, container.nextSibling);
    } else {
      container.parentNode.insertBefore(legend, container);
    }
    return legend;
  }

  function buildValueLabels(container) {
    const wrap = document.createElement("div");
    wrap.className = "tv-value-labels";
    container.appendChild(wrap);
    return wrap;
  }

  function updateValueLabels(inst) {
    if (!inst.valueLabels || inst.disposed || !inst.spec.rightValueLabels) return;
    const visibleRange = inst.chart.timeScale().getVisibleRange();
    const visibleToKey = visibleRange && visibleRange.to !== undefined && visibleRange.to !== null
      ? timeKey(visibleRange.to) : null;
    const items = [];
    (inst.spec.series || []).forEach(function (s) {
      const series = inst.series[s.name];
      if (!series) return;
      const data = series.data();
      if (!data || !data.length) return;
      let last = null;
      for (let i = data.length - 1; i >= 0; i--) {
        const d = data[i];
        if (!Number.isFinite(d.value)) continue;
        if (visibleToKey !== null && timeKey(d.time) > visibleToKey) continue;
        last = d;
        break;
      }
      if (!last) return;
      const y = series.priceToCoordinate(last.value);
      if (y === null || y === undefined) return;
      items.push({ color: s.color, y: y, text: fmtValue(last.value, inst.spec.valueFormat) });
    });
    inst.valueLabels.innerHTML = items.map(function (it) {
      return `<div class="tv-value-label" style="top:${it.y}px;background-color:${it.color}">${it.text}</div>`;
    }).join("");
  }

  const VALUE_LABEL_GUTTER = 62;

  function render(divId, spec) {
    const container = document.getElementById(divId);
    if (!container || !window.LightweightCharts) return;
    container._lastSpec = spec;
    const c = colors();
    const drawdownScale = spec.visibleTransform === "drawdown";
    const useLeftAxis = !!spec.leftAxis;
    const axisWidth = spec.syncGroup ? (container.clientWidth < 520 ? 72 : 100) : 0;
    const labelGutter = spec.rightValueLabels ? VALUE_LABEL_GUTTER : 0;
    const chartWidth = Math.round(Math.max(0, (container.clientWidth || 400) - labelGutter));

    let inst = instances[divId];
    // A period change can remove dates still referenced by the old visible
    // range. Recreate the chart atomically instead of removing its last series
    // while Lightweight Charts is dispatching time-range events.
    if (inst) {
      inst.disposed = true;
      if (inst.transformRAF) window.cancelAnimationFrame(inst.transformRAF);
      if (inst.rangeReportTimer) window.clearTimeout(inst.rangeReportTimer);
      if (inst.doubleClickHandler) container.removeEventListener("dblclick", inst.doubleClickHandler);
      if (inst.legend) inst.legend.remove();
      inst.observer.disconnect();
      inst.chart.remove();
      delete instances[divId];
      inst = null;
    }
    if (!inst || inst.disposed) {
      container.innerHTML = "";
      const chart = LightweightCharts.createChart(container, {
        width: chartWidth,
        height: Math.round(container.clientHeight || spec.height || 420),
        layout: { background: { type: "solid", color: c.bg }, textColor: c.text, fontFamily: "Arial, sans-serif", fontSize: 14 },
        grid: { vertLines: { visible: false }, horzLines: { visible: false } },
        rightPriceScale: {
          visible: !useLeftAxis,
          borderColor: c.border,
          ticksVisible: true,
          mode: spec.logScale ? 1 : 0,
          minimumWidth: useLeftAxis ? 0 : axisWidth,
          scaleMargins: (!useLeftAxis && drawdownScale) ? { top: 0.06, bottom: 0.08 } : undefined,
        },
        leftPriceScale: {
          visible: useLeftAxis,
          borderColor: c.border,
          ticksVisible: true,
          mode: spec.logScale ? 1 : 0,
          minimumWidth: useLeftAxis ? axisWidth : 0,
          scaleMargins: (useLeftAxis && drawdownScale) ? { top: 0.06, bottom: 0.08 } : undefined,
        },
        timeScale: {
          borderColor: c.border, fixLeftEdge: true, fixRightEdge: true, rightOffset: 2, ticksVisible: true,
          tickMarkFormatter: function (time, tickMarkType) {
            const date = typeof time === "number"
              ? new Date(time * 1000).toISOString().slice(0, 10)
              : timeKey(time);
            const parts = String(date).split("-");
            return tickMarkType === LightweightCharts.TickMarkType.Year
              ? parts[0]
              : `${parts[1]}.${parts[0].slice(-2)}`;
          },
        },
        crosshair: { mode: 0, vertLine: { color: c.muted, width: 1, style: 3, labelBackgroundColor: c.bg }, horzLine: { visible: false, labelVisible: false } },
        handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
        handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: false },
      });
      const legend = buildLegend(container, spec.legendPosition);
      container.style.position = "relative";
      const valueLabels = buildValueLabels(container);
      inst = { chart, container, spec, series: {}, bases: {}, legend, valueLabels, disposed: false,
        rendering: true, ignoreRangeEvents: true, transforming: false };
      instances[divId] = inst;
      chart.timeScale().subscribeVisibleTimeRangeChange(function () {
        if (inst.transforming) return;
        scheduleVisibleTransform(inst);
        scheduleRangeReport(inst);
        updateValueLabels(inst);
      });
      chart.timeScale().subscribeVisibleLogicalRangeChange(function (range) { syncRange(inst, range); });

      inst.doubleClickHandler = function () {
        if (!inst.spec.resetRange) return;
        inst.chart.timeScale().setVisibleRange({
          from: inst.spec.resetRange.start,
          to: inst.spec.resetRange.end,
        });
        scheduleVisibleTransform(inst);
        scheduleRangeReport(inst);
      };
      container.addEventListener("dblclick", inst.doubleClickHandler);

      inst.observer = new ResizeObserver(function () {
        if (container.clientWidth > 0) {
          const visibleRange = chart.timeScale().getVisibleRange();
          const gutter = inst.spec.rightValueLabels ? VALUE_LABEL_GUTTER : 0;
          chart.resize(Math.round(Math.max(0, container.clientWidth - gutter)), Math.round(container.clientHeight || inst.spec.height || 420));
          if (inst.spec.syncGroup) {
            const w = container.clientWidth < 520 ? 72 : 100;
            const scaleKey = inst.spec.leftAxis ? "leftPriceScale" : "rightPriceScale";
            chart.applyOptions({ [scaleKey]: { minimumWidth: w } });
          }
          if (visibleRange) chart.timeScale().setVisibleRange(visibleRange);
          updateValueLabels(inst);
        }
      });
      inst.observer.observe(container);
    } else {
      inst.chart.applyOptions({
        layout: { textColor: c.text },
        rightPriceScale: { borderColor: c.border },
        timeScale: { borderColor: c.border },
      });
    }
    inst.spec = spec;
    inst.rendering = true;
    inst.bases = {};

    // Rebuild series from scratch each render - simplest correct way to
    // handle series being added/removed/re-colored between updates.
    Object.values(inst.series).forEach(function (s) { try { inst.chart.removeSeries(s); } catch (e) {} });
    inst.series = {};

    let legendHtml = "";
    (spec.series || []).forEach(function (s) {
      const seriesOptions = {
        color: s.color,
        lineWidth: s.lineWidth || 2,
        lineStyle: s.dashed ? 2 : 0,
        priceLineVisible: false,
        lastValueVisible: !!s.showLastValue,
        crosshairMarkerRadius: 3,
        priceScaleId: spec.leftAxis ? "left" : "right",
        priceFormat: spec.valueFormat === "percent" || spec.valueFormat === "pp"
          ? { type: "custom", formatter: function (v) { return fmtValue(v, spec.valueFormat); } }
          : { type: "price", precision: 2, minMove: 0.01 },
      };
      let series;
      if (s.type === "area") {
        series = inst.chart.addAreaSeries(Object.assign(seriesOptions, {
          topColor: s.areaTop || s.color + "55",
          bottomColor: s.areaBottom || s.color + "03",
          lineWidth: s.lineWidth || 1.5,
        }));
      } else {
        series = inst.chart.addLineSeries(seriesOptions);
      }
      series.setData(s.data || []);
      if (s.markers && s.markers.length && series.setMarkers) {
        series.setMarkers(s.markers.map(function (m) {
          return {
            time: m.time, position: m.position || "inBar", color: m.color || s.color,
            shape: m.shape || "circle", text: m.text || "",
          };
        }));
      }
      inst.series[s.name] = series;
      legendHtml += `<div class="tv-legend-row"><span class="tv-dot" style="background:${s.color}"></span>${s.name}</div>`;
    });

    const firstSeries = Object.values(inst.series)[0];
    if (firstSeries) {
      (spec.hlines || []).forEach(function (h) {
        firstSeries.createPriceLine({ price: h.value, color: h.color || c.muted, lineWidth: 1, lineStyle: 3, axisLabelVisible: false, title: h.label || "" });
      });
    }
    inst.defaultLegendHtml = spec.showLegend === false ? "" : legendHtml;
    inst.legend.innerHTML = inst.defaultLegendHtml;
    inst.legend.className = "tv-legend" + (spec.showLegend === false ? " tv-legend-hidden" : "")
      + (spec.legendPosition === "bottom" ? " tv-legend-bottom" : "");

    if (spec.visibleRange && spec.visibleRange.start && spec.visibleRange.end) {
      inst.chart.timeScale().setVisibleRange({ from: spec.visibleRange.start, to: spec.visibleRange.end });
    } else {
      inst.chart.timeScale().fitContent();
    }
    inst.rendering = false;
    window.setTimeout(function () {
      if (!inst.disposed) inst.ignoreRangeEvents = false;
    }, 250);
    scheduleVisibleTransform(inst);
    requestAnimationFrame(function () {
      if (!inst.disposed) syncRange(inst, inst.chart.timeScale().getVisibleLogicalRange());
      if (!inst.disposed) updateValueLabels(inst);
    });
  }

  window.renderTVChart = render;

  new MutationObserver(function () {
    Object.keys(instances).forEach(function (id) {
      const inst = instances[id];
      if (!inst.container.isConnected) {
        inst.disposed = true;
        if (inst.transformRAF) window.cancelAnimationFrame(inst.transformRAF);
        if (inst.rangeReportTimer) window.clearTimeout(inst.rangeReportTimer);
        if (inst.doubleClickHandler) inst.container.removeEventListener("dblclick", inst.doubleClickHandler);
        if (inst.legend) inst.legend.remove();
        inst.observer.disconnect();
        inst.chart.remove();
        delete instances[id];
      }
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
