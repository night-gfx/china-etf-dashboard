(function () {
  const instances = {};

  function colors() {
    // Charts always render on a solid white plate regardless of the app's
    // dark/light shell theme - keeps every chart's palette/labeling uniform.
    return { bg: "#ffffff", text: "#16181d", muted: "#6b7280", border: "#e3e5ea" };
  }

  function fmtValue(v, fmt) {
    if (v === null || v === undefined || isNaN(v)) return "–";
    if (fmt === "percent") return (v >= 0 ? "+" : "") + v.toFixed(2) + " %";
    if (fmt === "pp") return (v >= 0 ? "+" : "") + v.toFixed(2) + " %-Pkt.";
    if (fmt === "ratio") return v.toFixed(2);
    return v.toLocaleString("de-DE", { maximumFractionDigits: 2 });
  }

  function buildLegend(container) {
    const legend = document.createElement("div");
    legend.className = "tv-legend";
    container.style.position = "relative";
    container.appendChild(legend);
    return legend;
  }

  function render(divId, spec) {
    const container = document.getElementById(divId);
    if (!container || !window.LightweightCharts) return;
    container._lastSpec = spec;
    const c = colors();

    let inst = instances[divId];
    if (!inst || inst.disposed) {
      container.innerHTML = "";
      const chart = LightweightCharts.createChart(container, {
        width: container.clientWidth || 400,
        height: spec.height || 420,
        layout: { background: { type: "solid", color: c.bg }, textColor: c.muted, fontFamily: "'Inter', sans-serif", fontSize: 11 },
        grid: { vertLines: { visible: false }, horzLines: { visible: false } },
        rightPriceScale: { borderColor: c.border, mode: spec.logScale ? 1 : 0 },
        timeScale: { borderColor: c.border, fixLeftEdge: true, fixRightEdge: true, rightOffset: 2 },
        crosshair: { mode: 0, vertLine: { color: c.muted, width: 1, style: 3, labelBackgroundColor: c.bg }, horzLine: { visible: false, labelVisible: false } },
        handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
        handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: false },
      });
      const legend = buildLegend(container);
      inst = { chart, series: {}, legend, disposed: false };
      instances[divId] = inst;

      chart.subscribeCrosshairMove(function (param) {
        if (!param || !param.time) {
          legend.innerHTML = inst.defaultLegendHtml || "";
          return;
        }
        let html = inst.dateLabel ? `<div class="tv-legend-date">${param.time}</div>` : "";
        (spec.series || []).forEach(function (s) {
          const ser = inst.series[s.name];
          if (!ser) return;
          const d = param.seriesData.get(ser);
          const v = d ? (d.value !== undefined ? d.value : d.close) : null;
          html += `<div class="tv-legend-row"><span class="tv-dot" style="background:${s.color}"></span>${s.name}: <b>${fmtValue(v, spec.valueFormat)}</b></div>`;
        });
        legend.innerHTML = html;
      });

      new ResizeObserver(function () {
        if (container.clientWidth > 0) chart.resize(container.clientWidth, spec.height || 420);
      }).observe(container);
    } else {
      inst.chart.applyOptions({
        layout: { textColor: c.muted },
        rightPriceScale: { borderColor: c.border },
        timeScale: { borderColor: c.border },
      });
    }

    // Rebuild series from scratch each render - simplest correct way to
    // handle series being added/removed/re-colored between updates.
    Object.values(inst.series).forEach(function (s) { try { inst.chart.removeSeries(s); } catch (e) {} });
    inst.series = {};

    let legendHtml = "";
    (spec.series || []).forEach(function (s) {
      const seriesOptions = {
        color: s.color,
        lineWidth: s.lineWidth || 2,
        lineStyle: s.dashed ? 2 : 0,
        priceLineVisible: !!s.showLastValue,
        lastValueVisible: !!s.showLastValue,
        crosshairMarkerRadius: 3,
        priceFormat: spec.valueFormat === "percent" || spec.valueFormat === "pp"
          ? { type: "custom", formatter: function (v) { return fmtValue(v, spec.valueFormat); } }
          : { type: "price", precision: 2, minMove: 0.01 },
      };
      let series;
      if (s.type === "area") {
        series = inst.chart.addAreaSeries(Object.assign(seriesOptions, {
          topColor: s.areaTop || s.color + "55",
          bottomColor: s.areaBottom || s.color + "03",
          lineWidth: s.lineWidth || 1.5,
        }));
      } else {
        series = inst.chart.addLineSeries(seriesOptions);
      }
      series.setData(s.data || []);
      if (s.markers && s.markers.length && series.setMarkers) {
        series.setMarkers(s.markers.map(function (m) {
          return {
            time: m.time, position: m.position || "inBar", color: m.color || s.color,
            shape: m.shape || "circle", text: m.text || "",
          };
        }));
      }
      inst.series[s.name] = series;
      legendHtml += `<div class="tv-legend-row"><span class="tv-dot" style="background:${s.color}"></span>${s.name}</div>`;
    });

    const firstSeries = Object.values(inst.series)[0];
    if (firstSeries) {
      (spec.hlines || []).forEach(function (h) {
        firstSeries.createPriceLine({ price: h.value, color: h.color || c.muted, lineWidth: 1, lineStyle: 3, axisLabelVisible: false, title: h.label || "" });
      });
    }
    inst.defaultLegendHtml = spec.showLegend === false ? "" : legendHtml;
    inst.legend.innerHTML = inst.defaultLegendHtml;
    inst.legend.className = "tv-legend" + (spec.legendPosition === "bottom" ? " tv-legend-bottom" : "");

    inst.chart.timeScale().fitContent();
  }

  window.renderTVChart = render;
})();
