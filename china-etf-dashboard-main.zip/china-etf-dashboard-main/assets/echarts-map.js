(function () {
  let worldMapReady = null;
  let mapInstance = null;

  function ensureWorldMap() {
    if (worldMapReady) return worldMapReady;
    worldMapReady = fetch("/assets/world_geo.json")
      .then((r) => r.json())
      .then((geo) => {
        echarts.registerMap("world", geo);
      });
    return worldMapReady;
  }

  function themeColors() {
    // Charts always render on a solid white plate regardless of the app's
    // dark/light shell theme - keeps every chart's palette/labeling uniform.
    return { bg: "#ffffff", text: "#16181d", muted: "#6b7280", border: "#e3e5ea" };
  }

  function buildOption(payload) {
    const c = themeColors();
    return {
      backgroundColor: c.bg,
      tooltip: {
        trigger: "item",
        backgroundColor: c.bg,
        borderColor: c.border,
        textStyle: { color: c.text, fontSize: 12 },
        formatter: function (params) {
          const d = params.data;
          if (!d || d.value === undefined || d.value === null || isNaN(d.value)) {
            return "<b>" + params.name + "</b><br/>keine Daten";
          }
          const pct = (d.value * 100).toFixed(1) + " %";
          return (
            "<b>" + (d.label || params.name) + "</b><br/>" +
            "ETF: " + (d.etf || "") + " (" + (d.ticker || "") + ")<br/>" +
            "Zuordnung: " + (d.zuordnung || "") + "<br/>" +
            "Performance: " + pct
          );
        },
      },
      visualMap: {
        min: payload.min,
        max: payload.max,
        left: 10,
        bottom: 10,
        calculable: true,
        text: ["Outperformance", "Underperformance"],
        inRange: { color: ["#c0392b", "#e8c97a", "#1f7a4d"] },
        textStyle: { color: c.muted, fontSize: 10 },
      },
      series: [
        {
          type: "map",
          map: "world",
          roam: true,
          scaleLimit: { min: 1, max: 8 },
          emphasis: {
            label: { show: false },
            itemStyle: { areaColor: c.muted },
          },
          itemStyle: { borderColor: c.border, borderWidth: 0.4, areaColor: c.bg },
          data: payload.data,
        },
      ],
    };
  }

  function render(divId, payload) {
    const dom = document.getElementById(divId);
    if (!dom) return;
    dom._lastPayload = payload;
    ensureWorldMap().then(() => {
      if (!mapInstance || mapInstance.getDom() !== dom) {
        if (mapInstance) {
          try { mapInstance.dispose(); } catch (e) {}
        }
        mapInstance = echarts.init(dom);
        window.addEventListener("resize", function () {
          if (mapInstance) mapInstance.resize();
        });
      }
      mapInstance.setOption(buildOption(payload), true);
    });
  }

  window.renderEchartsMap = render;
})();
