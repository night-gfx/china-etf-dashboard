import unittest
from types import SimpleNamespace
from unittest.mock import patch

import pandas as pd
from dash import Dash, html, no_update
from dash.exceptions import PreventUpdate

from pages import overview


class OverviewZoomTests(unittest.TestCase):
    def setUp(self):
        # The pre-window peak must not affect drawdowns in the zoomed window.
        self.prices = pd.Series(
            [200., 80., 100., 90., 110.],
            index=pd.date_range("2024-01-01", periods=5),
        )
        self.source = patch.object(overview, "_asset_class_series", return_value=self.prices)
        self.source.start()
        self.addCleanup(self.source.stop)
        app = Dash(__name__)
        app.layout = html.Div()
        overview.register_callbacks(app)
        self.app = app
        self.chart_update = self._find_callback("overview-chart-zoom-base.data")
        self.drawdown_update = self._find_callback("overview-drawdown-zoom-base.data")
        self.annual = self._find_callback("overview-annual.children")
        self.base = {"start": "2024-01-01", "end": "2024-01-05"}
        self.zoom = {"start": "2024-01-03", "end": "2024-01-05"}

    def _find_callback(self, output_key_fragment):
        key, entry = next((k, e) for k, e in self.app.callback_map.items() if output_key_fragment in k)
        return entry["callback"].__wrapped__

    def call(self, fn, trigger, zoom=None, years="5", start=None, end=None, base=None):
        with patch.object(overview, "ctx", SimpleNamespace(triggered_id=trigger)):
            return fn(zoom, years, start, end, base or self.base)

    def test_zoom_rebases_chart_and_updates_dates(self):
        result = self.call(self.chart_update, "overview-chart-zoom-range", self.zoom)
        self.assertEqual(result[:3], ("2024-01-03", "2024-01-05", None))
        spec = result[3]
        self.assertEqual(spec["resetRange"], self.base)
        self.assertEqual(spec["rangeStoreId"], "overview-chart-zoom-range")
        self.assertEqual(spec["visibleRange"], self.zoom)
        self.assertEqual(len(spec["series"][0]["data"]), 5)
        self.assertEqual(spec["visibleTransform"], "indexed")
        self.assertEqual(spec["series"][0]["data"][0]["value"], 200)
        self.assertIn("03.01.2024", result[4])
        self.assertIs(result[5], no_update)

    def test_charts_are_independent_and_do_not_sync(self):
        # Zooming the Rendite chart must not affect the Drawdown chart's spec.
        chart_result = self.call(self.chart_update, "overview-chart-zoom-range", self.zoom)
        drawdown_result = self.call(self.drawdown_update, "overview-drawdown-range", years="max")
        self.assertEqual(chart_result[3]["visibleRange"], self.zoom)
        self.assertEqual(drawdown_result[2], "max")
        self.assertNotEqual(drawdown_result[3]["visibleRange"], self.zoom)
        self.assertEqual(chart_result[3]["syncGroup"], "overview-chart")
        self.assertEqual(drawdown_result[3]["syncGroup"], "overview-drawdown")

    def test_repeated_zoom_preserves_original_reset_bounds(self):
        nested = {"start": "2024-01-04", "end": "2024-01-05"}
        result = self.call(self.chart_update, "overview-chart-zoom-range", nested, years=None)
        self.assertEqual(result[3]["resetRange"], self.base)
        self.assertEqual(result[3]["visibleRange"], nested)
        self.assertEqual(result[3]["series"][0]["data"][0]["value"], 200)
        restored = self.call(self.chart_update, "overview-chart-zoom-range", {**self.base, "reset": True}, years=None)
        self.assertEqual(restored[:2], (self.base["start"], self.base["end"]))
        self.assertEqual(len(restored[3]["series"][0]["data"]), 5)

    def test_manual_range_and_preset_replace_reset_bounds(self):
        result = self.call(self.chart_update, "overview-chart-custom-range",
                            start=self.zoom["start"], end=self.zoom["end"])
        self.assertEqual(result[5], self.zoom)
        self.assertEqual(result[3]["resetRange"], self.zoom)
        result = self.call(self.chart_update, "overview-chart-range", years="max", base=self.zoom)
        self.assertEqual(result[2], "max")
        self.assertEqual(result[5], self.base)

    def test_invalid_ranges_do_not_change_state(self):
        for value in [None, {}, {"start": "bad", "end": "2024-01-05"},
                      {"start": "2024-01-05", "end": "2024-01-03"}]:
            with self.subTest(value=value), self.assertRaises(PreventUpdate):
                self.call(self.chart_update, "overview-chart-zoom-range", value)

    def test_later_series_starts_at_its_first_available_price(self):
        with patch.object(overview, "_asset_class_series", return_value=self.prices.iloc[3:]):
            spec = overview._overview_spec(self.zoom, chart_id="overview-chart")
            dd = overview._overview_spec(self.zoom, drawdown=True, chart_id="overview-drawdown")
        self.assertEqual(spec["series"][0]["data"][0]["time"], "2024-01-04")
        self.assertEqual(spec["series"][0]["data"][0]["value"], 90)
        self.assertEqual(dd["series"][0]["data"][0]["value"], 90)
        self.assertEqual(spec["visibleTransform"], "indexed")
        self.assertEqual(dd["visibleTransform"], "drawdown")

    def test_annual_metrics_ignore_selected_window(self):
        result = self.annual("cagr")
        self.assertIn("2024", result.rowData[0])
        result = self.annual("drawdown")
        self.assertAlmostEqual(result.rowData[0]["2024"], -.6)

    def test_period_metrics_table_always_uses_max_range(self):
        # Periodenkennzahlen no longer follows any selection - it's always
        # computed over the full available history.
        result = overview._metrics_table("max")
        self.assertAlmostEqual(result.rowData[0]["Max. Drawdown"], -.6)

    def test_downside_deviation_is_available_and_annualized(self):
        stats = overview._statistics(self.prices, overview.ASSET_CLASSES[0])
        daily_returns = self.prices.pct_change(fill_method=None).dropna()
        expected = daily_returns.clip(upper=0).pow(2).mean() ** 0.5 * 252 ** 0.5
        self.assertAlmostEqual(stats["downside_deviation"], expected)
        result = overview._metrics_table("max")
        self.assertIn("Downside Deviation", result.rowData[0])

    def test_dash_dispatch_returns_chart_and_date_fields(self):
        key, entry = next((key, entry) for key, entry in self.app.callback_map.items()
                          if "overview-chart-zoom-base.data" in key)
        response = self.app.server.test_client().post("/_dash-update-component", json={
            "output": key,
            "outputs": [{"id": out.component_id, "property": out.component_property}
                        for out in entry["output"]],
            "changedPropIds": ["overview-chart-zoom-range.data"],
            "inputs": [
                {"id": "overview-chart-zoom-range", "property": "data", "value": self.zoom},
                {"id": "overview-chart-range", "property": "value", "value": "5"},
                {"id": "overview-chart-custom-range", "property": "start_date", "value": self.base["start"]},
                {"id": "overview-chart-custom-range", "property": "end_date", "value": self.base["end"]},
            ],
            "state": [{"id": "overview-chart-zoom-base", "property": "data", "value": self.base}],
        })
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        result = response.get_json()["response"]
        self.assertEqual(result["overview-chart-custom-range"],
                         {"start_date": self.zoom["start"], "end_date": self.zoom["end"]})
        chart = next(value["data"] for key, value in result.items() if "tv-chart-data" in key)
        self.assertEqual(chart["visibleTransform"], "indexed")
        self.assertEqual(chart["visibleRange"], self.zoom)


if __name__ == "__main__":
    unittest.main()
