from __future__ import annotations

import math
from concurrent.futures import ThreadPoolExecutor, as_completed

import dash
import dash_mantine_components as dmc
import numpy as np
import pandas as pd
import yfinance as yf
from dash import ALL, MATCH, Input, Output, State, dcc, html

from src.cache import LONG_TTL, SHORT_TTL, cache
from src.data import convert_to_eur, detect_currency, download_adjusted_close
from src.metrics import cagr, max_drawdown, sortino
from src.theme import (
    ACCENT, PALETTE,
    ag_heat_table, ag_table, echart, tv_chart, tv_series, tv_spec,
)


@cache.memoize(timeout=SHORT_TTL)
def yahoo_search(query: str):
    query = str(query or "").strip()
    if not query:
        return []
    results = []
    try:
        search = yf.Search(query, max_results=10)
        for item in (getattr(search, "quotes", None) or []):
            symbol = str(item.get("symbol") or "").strip()
            if not symbol:
                continue
            quote_type = str(item.get("quoteType") or item.get("typeDisp") or "")
            if quote_type.upper() not in {"EQUITY", "ETF", "MUTUALFUND", "INDEX", "CRYPTOCURRENCY"}:
                continue
            results.append({
                "symbol": symbol,
                "name": str(item.get("longname") or item.get("shortname") or item.get("name") or symbol),
                "exchange_code": str(item.get("exchange") or "").strip(),
                "exchange_name": str(item.get("exchDisp") or item.get("fullExchangeName") or item.get("exchangeName") or "").strip(),
                "type": quote_type,
            })
    except Exception:
        pass
    if not results:
        results.append({"symbol": query.upper(), "name": query, "exchange_code": "", "exchange_name": "", "type": "Direkteingabe"})
    seen, unique = set(), []
    for item in results:
        if item["symbol"] not in seen:
            seen.add(item["symbol"])
            unique.append(item)
    return unique[:10]


@cache.memoize(timeout=LONG_TTL)
def asset_series_eur(symbol: str):
    prices = download_adjusted_close(symbol, start="2000-01-01")
    if len(prices) < 30:
        raise RuntimeError(f"{symbol}: zu wenig Kursdaten")
    currency = detect_currency(symbol, "EUR")
    eur, detected = convert_to_eur(prices, currency)
    if len(eur) < 30:
        raise RuntimeError(f"{symbol}: zu wenig EUR-Daten")
    return eur.rename(symbol), detected


def rebalance_key(date, frequency):
    if frequency == "Monatlich":
        return (date.year, date.month)
    if frequency == "Quartalsweise":
        return (date.year, (date.month - 1) // 3)
    if frequency == "Halbjährlich":
        return (date.year, (date.month - 1) // 6)
    if frequency == "Jährlich":
        return (date.year,)
    return None


def backtest_portfolio(prices, weights, frequency):
    returns = prices.pct_change(fill_method=None).fillna(0.0)
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.sum()
    values = weights.copy()
    output = []
    last_key = None
    for date, row in returns.iterrows():
        key = rebalance_key(pd.Timestamp(date), frequency)
        if frequency != "Kein Rebalancing" and key != last_key and len(output) > 0:
            total = float(values.sum())
            values = total * weights
        values = values * (1.0 + row.to_numpy(dtype=float))
        output.append(float(values.sum()))
        last_key = key
    return pd.Series(output, index=returns.index, name="Portfolio") * 100.0


def backtest_metrics(series):
    series = series.dropna()
    if len(series) < 2:
        return {}
    returns = series.pct_change(fill_method=None).dropna()
    cg = cagr(series)
    vola = returns.std(ddof=1) * math.sqrt(252) if len(returns) > 1 else np.nan
    shp = (returns.mean() / returns.std(ddof=1) * math.sqrt(252)
           if len(returns) > 1 and returns.std(ddof=1) != 0 else np.nan)
    dd = max_drawdown(series)
    srt = sortino(series, 0.0)
    calmar = cg / abs(dd) if dd and not np.isnan(dd) else np.nan
    return {"CAGR p.a.": cg, "Volatilität p.a.": vola, "Sharpe Ratio": shp,
            "Max. Drawdown": dd, "Sortino": srt, "Calmar": calmar}


REBALANCE_OPTIONS = ["Monatlich", "Quartalsweise", "Halbjährlich", "Jährlich", "Kein Rebalancing"]
TIME_PERIOD_OPTIONS = ["Gesamter Datenzeitraum", "Letzte 1 Jahr", "Letzte 3 Jahre", "Letzte 5 Jahre", "Letzte 10 Jahre", "Benutzerdefiniert"]
EXPLORER_METRICS = {
    "baseline": "Baseline-CAGR (15. Perzentil)",
    "withdrawal": "Nachhaltige Entnahmerate",
    "ulcer": "Ulcer Index",
}
EXPLORER_STEPS = [
    {"value": "10", "label": "10 % (detailliert)"},
    {"value": "20", "label": "20 % (schnell)"},
    {"value": "25", "label": "25 % (sehr schnell)"},
]
MAX_EXPLORER_PORTFOLIOS = 10_000


# Canonical Germany allocations published by Portfolio Charts.  The source
# works with proprietary long-run asset-class series; this dashboard maps the
# same weights to liquid public ETF proxies so every model can be tested with
# the existing Yahoo/EUR data pipeline.
MODEL_PORTFOLIOS = {
    "Golden Butterfly": "EUR-LCB:20,EUR-SCV:20,EUR-LTT:20,EUR-STT:20,GLO-GLD:20",
    "Golden Ratio Portfolio": "EUR-LCG:21,EUR-SCV:21,EUR-LTT:26,EUR-BIL:6,GLO-COM:10,GLO-GLD:16",
    "Weird Portfolio": "EUR-SCV:20,USA-SCB:20,EUR-LTT:20,USA-REI:20,GLO-GLD:20",
    "Permanent Portfolio": "DEU-LCB:25,DEU-ITT:25,DEU-BIL:25,GLO-GLD:25",
    "Pinwheel Portfolio": "EUR-LCB:15,EUR-SCV:10,USA-LCB:15,EMT-LCB:10,EUR-ITT:15,EUR-BIL:10,USA-REI:15,GLO-GLD:10",
    "All Seasons Portfolio": "DEU-LCB:30,DEU-ITT:55,GLO-COM:7,GLO-GLD:8",
    "Coffeehouse Portfolio": "EUR-LCB:10,EUR-LCV:10,EUR-SCB:10,EUR-SCV:10,USA-LCB:10,EUR-ITT:40,USA-REI:10",
    "Ultimate Buy & Hold": "EUR-LCB:6,EUR-LCV:6,EUR-SCB:6,EUR-SCV:6,USA-LCB:6,USA-LCV:6,USA-SCB:6,USA-SCV:6,EMT-LCB:6,EUR-ITT:20,EUR-STT:20,USA-REI:6",
    "7Twelve Portfolio": "EUR-LCB:13,EUR-SCB:12,USA-LCB:8,EMT-LCB:8,EUR-ITT:17,EUR-BIL:9,USA-ITT:8,USA-REI:8,GLO-COM:17",
    "Ivy Portfolio": "DEU-LCB:20,DEV-LCB:20,DEU-ITT:20,USA-REI:20,GLO-COM:20",
    "Sandwich Portfolio": "EUR-LCB:20,EUR-SCB:8,USA-LCB:6,USA-SCB:10,EMT-LCB:6,EUR-ITT:30,EUR-BIL:4,USA-ITT:11,USA-REI:5",
    "No-Brainer Portfolio": "EUR-LCB:25,EUR-SCB:25,USA-SCB:25,EUR-STT:25",
    "Larry Portfolio": "EUR-SCV:15,USA-SCV:8,EMT-LCB:7,EUR-ITT:70",
    "Richer Retirement": "EUR-LCB:22,EUR-SCB:22,USA-LCB:11,EUR-ITT:40,EUR-BIL:5",
    "Global Market Portfolio": "DEV-LCB:38,DEV-SCB:7,EMT-LCB:5,DEV-ITT:44,USA-REI:4,GLO-GLD:2",
    "Ideal Index Portfolio": "EUR-LCB:7,EUR-LCV:9,EUR-SCV:9,EUR-SCG:6,USA-LCB:31,EUR-STT:30,USA-REI:8",
    "Swensen Portfolio": "DEU-LCB:30,DEV-LCB:15,EMT-LCB:5,DEU-ITT:30,USA-REI:20",
    "Core Four Portfolio": "DEU-LCB:48,DEV-LCB:24,DEU-ITT:20,USA-REI:8",
    "Classic 60-40 Portfolio": "DEU-LCB:60,DEU-ITT:40",
    "Three-Fund Portfolio": "DEU-LCB:64,DEV-LCB:16,DEU-ITT:20",
    "Total Stock Market": "DEU-LCB:100",
}

ASSET_CLASS_PROXIES = {
    "DEU-LCB": ("EWG", "Deutschland Aktien"),
    "DEU-ITT": ("EXHD.DE", "Deutschland Staatsanleihen 5,5–10,5J"),
    "DEU-BIL": ("XEON.DE", "EUR Geldmarkt"),
    "EUR-LCB": ("VGK", "Europa Large Cap Blend"),
    "EUR-LCV": ("EFV", "Europa/Developed Large Cap Value"),
    "EUR-LCG": ("EFG", "Europa/Developed Large Cap Growth"),
    "EUR-SCB": ("DFE", "Europa Small Cap Blend"),
    "EUR-SCV": ("DFE", "Europa Small Cap Value"),
    "EUR-SCG": ("DFE", "Europa Small Cap Growth"),
    "EUR-LTT": ("IBGL.L", "Euro-Staatsanleihen 15–30J"),
    "EUR-ITT": ("IBGM.L", "Euro-Staatsanleihen 7–10J"),
    "EUR-STT": ("IBGS.L", "Euro-Staatsanleihen 1–3J"),
    "EUR-BIL": ("XEON.DE", "EUR Geldmarkt"),
    "USA-LCB": ("VTI", "USA Aktienmarkt"),
    "USA-LCV": ("VTV", "USA Large Cap Value"),
    "USA-SCB": ("VB", "USA Small Cap Blend"),
    "USA-SCV": ("VBR", "USA Small Cap Value"),
    "USA-ITT": ("IEF", "USA Staatsanleihen 7–10J"),
    "DEV-LCB": ("VEA", "Industrieländer Aktien"),
    "DEV-SCB": ("SCZ", "Industrieländer Small Caps"),
    "DEV-ITT": ("BWX", "Internationale Staatsanleihen"),
    "EMT-LCB": ("VWO", "Schwellenländer Aktien"),
    "USA-REI": ("VNQ", "US-REITs"),
    "GLO-COM": ("DBC", "Rohstoffe"),
    "GLO-GLD": ("GLD", "Gold"),
}

MODEL_SCORE_LABELS = {
    "cagr": "CAGR p.a.",
    "average": "Ø Rendite p.a.",
    "withdrawal": "Entnahmerate (10J)",
    "volatility": "Volatilität p.a.",
    "ulcer": "Ulcer Index",
    "drawdown": "Max. Drawdown",
    "sensitivity": "Startzeit-Sensitivität",
}
MODEL_MINIMIZE = {"volatility", "ulcer", "drawdown", "sensitivity"}


def allocation_grid(asset_count: int, step_percent: int) -> np.ndarray:
    """Return every long-only allocation that sums to 100 percent."""
    units = 100 // step_percent
    count = math.comb(units + asset_count - 1, asset_count - 1)
    if count > MAX_EXPLORER_PORTFOLIOS:
        raise ValueError(
            f"{count:,} Kombinationen überschreiten das Limit von "
            f"{MAX_EXPLORER_PORTFOLIOS:,}. Bitte einen größeren Gewichtsschritt wählen."
        )

    rows = []

    def build(prefix, remaining, slots):
        if slots == 1:
            rows.append([*prefix, remaining])
            return
        for value in range(remaining + 1):
            build([*prefix, value], remaining - value, slots - 1)

    build([], units, asset_count)
    return np.asarray(rows, dtype=float) / units


def explorer_portfolio_values(monthly_prices: pd.DataFrame, allocations: np.ndarray) -> np.ndarray:
    """Calculate annually rebalanced portfolio paths for many allocations at once."""
    returns = monthly_prices.pct_change(fill_method=None).fillna(0.0).to_numpy(dtype=float)
    weights = np.asarray(allocations, dtype=float)
    holdings = weights.copy()
    paths = np.empty((len(monthly_prices), len(weights)), dtype=float)
    previous_year = None
    for row_number, (date, monthly_return) in enumerate(zip(monthly_prices.index, returns)):
        year = pd.Timestamp(date).year
        if row_number and year != previous_year:
            holdings = holdings.sum(axis=1, keepdims=True) * weights
        holdings *= 1.0 + monthly_return
        paths[row_number] = holdings.sum(axis=1)
        previous_year = year
    return paths


def explorer_scores(paths: np.ndarray, metric: str, horizon_years: int, inflation_rate: float) -> np.ndarray:
    """Score paths using a conservative rolling-window portfolio metric."""
    months = int(horizon_years) * 12
    if metric == "ulcer":
        real_deflator = np.power(1.0 + inflation_rate, np.arange(len(paths)) / 12.0)[:, None]
        real_paths = paths / real_deflator
        drawdowns = real_paths / np.maximum.accumulate(real_paths, axis=0) - 1.0
        return np.sqrt(np.mean(np.square(np.minimum(drawdowns, 0.0)), axis=0))

    if len(paths) <= months:
        raise ValueError(f"Für {horizon_years} Jahre ist der gemeinsame Kurszeitraum zu kurz.")

    if metric == "baseline":
        real_deflator = np.power(1.0 + inflation_rate, np.arange(len(paths)) / 12.0)[:, None]
        real_paths = paths / real_deflator
        rolling_growth = real_paths[months:] / real_paths[:-months]
        rolling_cagr = np.power(rolling_growth, 1.0 / horizon_years) - 1.0
        return np.nanpercentile(rolling_cagr, 15, axis=0)

    if metric == "withdrawal":
        inflation_factors = np.power(1.0 + inflation_rate, np.arange(1, months + 1) / 12.0)[:, None]
        safe_rates = np.full(paths.shape[1], np.inf, dtype=float)
        for start in range(len(paths) - months):
            relative_path = paths[start + 1:start + months + 1] / paths[start]
            # With end-of-month withdrawals, this is the exact initial annual
            # rate that leaves a zero terminal balance for the selected path.
            rate = 12.0 / np.sum(inflation_factors / relative_path, axis=0)
            safe_rates = np.minimum(safe_rates, rate)
        return safe_rates

    raise ValueError(f"Unbekannte Explorer-Kennzahl: {metric}")


def model_proxy_weights(portfolio_name: str) -> dict[str, float]:
    """Translate a canonical asset-class allocation into aggregated ETF weights."""
    result = {}
    for item in MODEL_PORTFOLIOS[portfolio_name].split(","):
        asset_code, raw_weight = item.split(":")
        ticker = ASSET_CLASS_PROXIES[asset_code][0]
        result[ticker] = result.get(ticker, 0.0) + float(raw_weight) / 100.0
    return result


def model_portfolio_statistics(series: pd.Series, inflation_rate: float) -> dict[str, float]:
    """Portfolio-Matrix-style real-return and risk statistics."""
    series = series.dropna()
    elapsed_years = (series.index - series.index[0]).days / 365.25
    real_series = series / np.power(1.0 + inflation_rate, elapsed_years)
    monthly = real_series.resample("ME").last().dropna()
    annual_returns = real_series.resample("YE").last().pct_change(fill_method=None).dropna()
    monthly_returns = monthly.pct_change(fill_method=None).dropna()

    withdrawal = np.nan
    if len(monthly) > 120:
        withdrawal = float(explorer_scores(
            series.resample("ME").last().dropna().to_numpy(dtype=float)[:, None],
            "withdrawal", 10, inflation_rate,
        )[0])

    sensitivity = np.nan
    if len(monthly) > 60:
        values = monthly.to_numpy(dtype=float)
        rolling_cagr = np.power(values[60:] / values[:-60], 1.0 / 5.0) - 1.0
        sensitivity = float(np.nanstd(rolling_cagr, ddof=1)) if len(rolling_cagr) > 1 else np.nan

    drawdown = real_series / real_series.cummax() - 1.0
    ulcer = float(np.sqrt(np.mean(np.square(np.minimum(drawdown, 0.0)))))
    volatility = float(monthly_returns.std(ddof=1) * math.sqrt(12)) if len(monthly_returns) > 1 else np.nan
    return {
        "cagr": float(cagr(real_series)),
        "average": float(annual_returns.mean()) if len(annual_returns) else np.nan,
        "withdrawal": withdrawal,
        "volatility": volatility,
        "ulcer": ulcer,
        "drawdown": abs(float(drawdown.min())),
        "sensitivity": sensitivity,
    }


def weighted_model_scores(stats: pd.DataFrame, metric_weights: dict[str, float]) -> pd.Series:
    """Combine per-metric percentile ranks into a transparent 0–100 score."""
    weighted = pd.Series(0.0, index=stats.index)
    total_weight = 0.0
    for metric, weight in metric_weights.items():
        weight = max(0.0, float(weight or 0.0))
        if not weight or metric not in stats:
            continue
        values = pd.to_numeric(stats[metric], errors="coerce")
        ranks = values.rank(pct=True, ascending=metric not in MODEL_MINIMIZE) * 100.0
        weighted = weighted.add(ranks.fillna(0.0) * weight, fill_value=0.0)
        total_weight += weight
    if total_weight <= 0:
        raise ValueError("Mindestens ein Kennzahlengewicht muss größer als 0 sein.")
    return weighted / total_weight


def _card(title, children):
    return html.Div([html.Div(title, className="section-title"), *children], className="section-card")


def layout(params=None):
    return html.Div([
        dmc.Title("Asset Allocation Backtesting Tool", order=3, mb="xs"),
        dmc.Text(
            "Freie Wertpapiersuche über Yahoo Finance. Name, Ticker oder ISIN eingeben; "
            "bei nicht eindeutig auflösbaren ISINs funktioniert der Yahoo-Ticker am zuverlässigsten.",
            size="sm", c="dimmed", mb="md",
        ),
        dcc.Store(id="aa-assets-store", storage_type="session", data=[]),
        dcc.Store(id="aa-benchmark-store", storage_type="session", data=None),
        dcc.Store(id="aa-search-results-store", data=[]),

        html.Div([
            html.Div("Wertpapier hinzufügen", className="section-title"),
            dmc.Grid([
                dmc.GridCol(dmc.TextInput(id="aa-search-input", placeholder="z. B. Apple, AAPL oder US0378331005",
                                           label="Name, Ticker oder ISIN"), span=8),
                dmc.GridCol(dmc.Button("Suchen", id="aa-search-button", fullWidth=True, mt=24, color="orange"), span=4),
            ]),
            html.Div(id="aa-search-results-container", style={"marginTop": "12px"}),
        ], className="section-card"),

        html.Div(id="aa-portfolio-container", className="section-card"),

        html.Div([
            html.Div("Backtesting-Einstellungen", className="section-title"),
            dmc.Grid([
                dmc.GridCol(dmc.Select(id="aa-rebalance", label="Rebalancing", data=REBALANCE_OPTIONS,
                                        value="Quartalsweise", allowDeselect=False), span=4),
                dmc.GridCol(dmc.Select(id="aa-time-period", label="Zeitraum", data=TIME_PERIOD_OPTIONS,
                                        value="Gesamter Datenzeitraum", allowDeselect=False), span=4),
                dmc.GridCol(dmc.NumberInput(id="aa-custom-years", label="Jahre zurück", min=1, max=50, value=5,
                                             style={"display": "none"}), span=4, id="aa-custom-years-col"),
            ]),
            dmc.Button("Backtest starten", id="aa-backtest-button", color="orange", fullWidth=True, mt="md"),
        ], className="section-card"),

        html.Div(id="aa-results-container"),

        html.Div([
            html.Div("Modellportfolio-Vergleich", className="section-title"),
            dmc.Text(
                "Vergleicht die 21 Portfolios aus der Portfolio-Matrix mit festen ETF-Proxys, "
                "einem gemeinsamen EUR-Zeitraum und frei gewichtbaren Rendite-/Risikokennzahlen.",
                size="sm", c="dimmed", mb="md",
            ),
            dmc.MultiSelect(
                id="aa-model-portfolios", label="Portfolios",
                data=list(MODEL_PORTFOLIOS), value=list(MODEL_PORTFOLIOS),
                searchable=True, clearable=True,
            ),
            dmc.Grid([
                dmc.GridCol(dmc.Select(
                    id="aa-model-period", label="Zeitraum",
                    data=["Gesamter Datenzeitraum", "Letzte 5 Jahre", "Letzte 10 Jahre", "Letzte 15 Jahre"],
                    value="Gesamter Datenzeitraum", allowDeselect=False,
                ), span=4),
                dmc.GridCol(dmc.Select(
                    id="aa-model-rebalance", label="Rebalancing", data=REBALANCE_OPTIONS,
                    value="Jährlich", allowDeselect=False,
                ), span=3),
                dmc.GridCol(dmc.NumberInput(
                    id="aa-model-inflation", label="Inflation p.a.", min=0, max=15,
                    value=2, step=0.25, suffix=" %",
                ), span=3),
                dmc.GridCol(dmc.NumberInput(
                    id="aa-model-top-count", label="Portfolios im Chart", min=2, max=10,
                    value=5, step=1,
                ), span=2),
            ], mt="md"),
            dmc.Text("Gewichtung des Gesamtscores", size="sm", fw=600, mt="md", mb=6),
            dmc.SimpleGrid(cols=7, spacing="xs", children=[
                dmc.NumberInput(
                    id={"type": "aa-model-weight", "metric": metric},
                    label=label, min=0, max=10, value=5, step=1,
                )
                for metric, label in MODEL_SCORE_LABELS.items()
            ]),
            dmc.Button(
                "Modellportfolios vergleichen", id="aa-model-run-button",
                color="orange", fullWidth=True, mt="md",
            ),
            dmc.Text(
                "Die Allokationen entsprechen der Deutschland-Variante von Portfolio Charts. "
                "Ergebnisse basieren auf den unten ausgewiesenen ETF-Proxys und können deshalb "
                "von den Indexdaten der Vorlage abweichen.",
                size="xs", c="dimmed", mt="sm",
            ),
        ], className="section-card"),

        dcc.Loading(html.Div(id="aa-model-results"), type="circle"),

        html.Div([
            html.Div("Portfolio Explorer", className="section-title"),
            dmc.Text(
                "Durchsucht alle Gewichtskombinationen der oben ausgewählten Wertpapiere und zeigt, "
                "welche Allokationen über viele historische Startzeitpunkte robust waren.",
                size="sm", c="dimmed", mb="md",
            ),
            dmc.Grid([
                dmc.GridCol(dmc.Select(
                    id="aa-explorer-metric", label="Optimieren nach",
                    data=[{"value": key, "label": label} for key, label in EXPLORER_METRICS.items()],
                    value="baseline", allowDeselect=False,
                ), span=4),
                dmc.GridCol(dmc.Select(
                    id="aa-explorer-step", label="Gewichtsschritte", data=EXPLORER_STEPS,
                    value="10", allowDeselect=False,
                ), span=3),
                dmc.GridCol(dmc.NumberInput(
                    id="aa-explorer-horizon", label="Horizont CAGR/Entnahme",
                    min=3, max=30, value=10, step=1,
                ), span=3),
                dmc.GridCol(dmc.NumberInput(
                    id="aa-explorer-inflation", label="Inflation p.a.",
                    min=0, max=15, value=2, step=0.25, suffix=" %",
                ), span=2),
            ]),
            dmc.Button(
                "Alle Allokationen untersuchen", id="aa-explorer-button",
                color="orange", fullWidth=True, mt="md",
            ),
            dmc.Text(
                "Methodischer Hinweis: Die Idee folgt dem Global Explorer von Portfolio Charts. "
                "Hier werden jedoch die gewählten Yahoo-Finance-Kursreihen in EUR, jährliches "
                "Rebalancing und eine einheitliche Inflationsannahme verwendet – keine "
                "länderübergreifenden Indexreihen seit 1970.",
                size="xs", c="dimmed", mt="sm",
            ),
        ], className="section-card"),

        dcc.Loading(html.Div(id="aa-explorer-results"), type="circle"),
    ])


def _search_result_option(item):
    exch = item.get("exchange_name") or item.get("exchange_code") or ""
    label = f"{item['name']} · {item['symbol']}" + (f" · {exch}" if exch else "")
    return {"value": item["symbol"], "label": label}


def register_callbacks(app):
    @app.callback(
        Output("aa-search-results-container", "children"),
        Output("aa-search-results-store", "data"),
        Input("aa-search-button", "n_clicks"),
        Input("aa-search-input", "n_submit"),
        State("aa-search-input", "value"),
        prevent_initial_call=True,
    )
    def do_search(_clicks, _submit, query):
        results = yahoo_search(query)
        if not results:
            return dmc.Text("Keine Treffer.", size="sm", c="dimmed"), []
        options = [_search_result_option(r) for r in results]
        content = dmc.Stack([
            dmc.Select(id="aa-search-select", data=options, value=options[0]["value"], allowDeselect=False),
            dmc.Group([
                dmc.Button("Zum Portfolio hinzufügen", id="aa-add-button", color="orange", variant="light"),
                dmc.Button("Als Benchmark verwenden", id="aa-benchmark-button", variant="outline", color="orange"),
            ], mt="sm"),
        ])
        return content, results

    @app.callback(
        Output("aa-assets-store", "data"),
        Input("aa-add-button", "n_clicks"),
        State("aa-search-select", "value"),
        State("aa-search-results-store", "data"),
        State("aa-assets-store", "data"),
        prevent_initial_call=True,
    )
    def add_asset(_n, selected_symbol, results, assets):
        assets = list(assets or [])
        if not _n or not selected_symbol or any(a["symbol"] == selected_symbol for a in assets):
            return assets
        match = next((r for r in results if r["symbol"] == selected_symbol), None)
        if not match:
            return assets
        assets.append({"symbol": match["symbol"], "name": match["name"], "weight": 0.0})
        equal = 100.0 / len(assets)
        for a in assets:
            a["weight"] = equal
        return assets

    @app.callback(
        Output("aa-benchmark-store", "data"),
        Input("aa-benchmark-button", "n_clicks"),
        State("aa-search-select", "value"),
        State("aa-search-results-store", "data"),
        prevent_initial_call=True,
    )
    def set_benchmark(_n, selected_symbol, results):
        if not _n:
            return dash.no_update
        match = next((r for r in results if r["symbol"] == selected_symbol), None)
        return match

    @app.callback(
        Output("aa-assets-store", "data", allow_duplicate=True),
        Input({"type": "aa-remove", "symbol": ALL}, "n_clicks"),
        State("aa-assets-store", "data"),
        prevent_initial_call=True,
    )
    def remove_asset(_clicks, assets):
        triggered = dash.callback_context.triggered_id
        if not triggered or not any(_clicks):
            return dash.no_update
        symbol = triggered["symbol"]
        assets = [a for a in (assets or []) if a["symbol"] != symbol]
        if assets:
            equal = 100.0 / len(assets)
            for a in assets:
                a["weight"] = equal
        return assets

    @app.callback(
        Output("aa-assets-store", "data", allow_duplicate=True),
        Input({"type": "aa-weight", "symbol": ALL}, "value"),
        State({"type": "aa-weight", "symbol": ALL}, "id"),
        State("aa-assets-store", "data"),
        prevent_initial_call=True,
    )
    def update_weights(values, ids, assets):
        weight_by_symbol = {i["symbol"]: v for i, v in zip(ids, values)}
        assets = list(assets or [])
        for a in assets:
            if a["symbol"] in weight_by_symbol and weight_by_symbol[a["symbol"]] is not None:
                a["weight"] = float(weight_by_symbol[a["symbol"]])
        return assets

    @app.callback(
        Output("aa-portfolio-container", "children"),
        Input("aa-assets-store", "data"),
        Input("aa-benchmark-store", "data"),
    )
    def render_portfolio(assets, benchmark):
        assets = assets or []
        rows = []
        if assets:
            for asset in assets:
                rows.append(
                    dmc.Grid([
                        dmc.GridCol(dmc.Text([
                            dmc.Text(asset["name"], fw=600, span=True), " ",
                            dmc.Text(f"({asset['symbol']})", c="dimmed", span=True, size="sm"),
                        ]), span=6),
                        dmc.GridCol(dmc.NumberInput(
                            id={"type": "aa-weight", "symbol": asset["symbol"]},
                            value=round(float(asset["weight"]), 2), min=0, max=100, step=1, suffix=" %",
                        ), span=4),
                        dmc.GridCol(dmc.Button("Entfernen", id={"type": "aa-remove", "symbol": asset["symbol"]},
                                                color="red", variant="subtle", size="xs", fullWidth=True), span=2),
                    ], align="center", mb=6)
                )
            total_weight = sum(a["weight"] for a in assets)
            rows.append(dmc.Text(f"Summe Gewichte: {total_weight:.2f} %", size="xs", c="dimmed", mt="xs"))
        else:
            rows.append(dmc.Text("Noch keine Wertpapiere im Portfolio.", size="sm", c="dimmed"))

        if benchmark:
            rows.append(dmc.Text([
                dmc.Text("Benchmark: ", fw=600, span=True),
                f"{benchmark['name']} ({benchmark['symbol']})",
            ], mt="sm", size="sm"))

        return [html.Div("Portfolio", className="section-title"), *rows]

    @app.callback(
        Output("aa-custom-years-col", "style"),
        Input("aa-time-period", "value"),
    )
    def toggle_custom_years(period):
        return {"display": "block"} if period == "Benutzerdefiniert" else {"display": "none"}

    @app.callback(
        Output("aa-results-container", "children"),
        Input("aa-backtest-button", "n_clicks"),
        State("aa-assets-store", "data"),
        State("aa-benchmark-store", "data"),
        State("aa-rebalance", "value"),
        State("aa-time-period", "value"),
        State("aa-custom-years", "value"),
        prevent_initial_call=True,
    )
    def run_backtest(_n, assets, benchmark, rebalance, time_period, custom_years):
        assets = assets or []
        if not assets:
            return dmc.Alert("Mindestens ein Wertpapier hinzufügen.", color="red")
        if not benchmark:
            return dmc.Alert("Bitte eine Benchmark auswählen.", color="red")
        weights = np.array([a["weight"] for a in assets], dtype=float)
        if weights.sum() <= 0:
            return dmc.Alert("Die Summe der Gewichte muss größer als 0 sein.", color="red")

        price_series, errors = {}, []
        for asset in assets:
            try:
                series, _ = asset_series_eur(asset["symbol"])
                price_series[asset["symbol"]] = series
            except Exception as exc:
                errors.append(str(exc))
        try:
            benchmark_series, _ = asset_series_eur(benchmark["symbol"])
        except Exception as exc:
            benchmark_series = None
            errors.append(f"Benchmark: {exc}")

        alerts = [dmc.Alert(err, color="yellow", mb=4) for err in errors]
        if len(price_series) != len(assets) or benchmark_series is None:
            return html.Div([*alerts, dmc.Alert("Backtest konnte nicht vollständig geladen werden.", color="red")])

        prices = pd.concat(price_series, axis=1).dropna()
        benchmark_series = benchmark_series.reindex(prices.index).dropna()
        common_index = prices.index.intersection(benchmark_series.index)
        prices = prices.loc[common_index]
        benchmark_series = benchmark_series.loc[common_index]

        if time_period != "Gesamter Datenzeitraum":
            years_back = {"Letzte 1 Jahr": 1, "Letzte 3 Jahre": 3, "Letzte 5 Jahre": 5,
                          "Letzte 10 Jahre": 10}.get(time_period, custom_years or 5)
            cutoff = pd.Timestamp.now() - pd.DateOffset(years=years_back)
            prices = prices[prices.index >= cutoff]
            benchmark_series = benchmark_series[benchmark_series.index >= cutoff]
            common_index = prices.index.intersection(benchmark_series.index)
            prices, benchmark_series = prices.loc[common_index], benchmark_series.loc[common_index]

        if len(prices) < 30:
            return html.Div([*alerts, dmc.Alert("Zu wenig gemeinsamer Datenzeitraum.", color="red")])

        portfolio = backtest_portfolio(prices, weights, rebalance)
        benchmark_indexed = benchmark_series / benchmark_series.iloc[0] * 100.0
        comparison = pd.concat([portfolio.rename("Portfolio"), benchmark_indexed.rename("Benchmark")], axis=1).dropna()

        perf_spec = tv_spec([
            tv_series("Portfolio", comparison["Portfolio"], PALETTE[0]),
            tv_series("Benchmark", comparison["Benchmark"], PALETTE[1], dashed=True),
        ], height=420, log_scale=True, value_format="ratio", rebase_visible=True)

        dd = comparison / comparison.cummax() - 1.0
        dd_spec = tv_spec([
            tv_series("Portfolio", dd["Portfolio"] * 100, PALETTE[0]),
            tv_series("Benchmark", dd["Benchmark"] * 100, PALETTE[1], dashed=True),
        ], height=420, value_format="percent")

        stats = pd.DataFrame({"Portfolio": backtest_metrics(comparison["Portfolio"]),
                               "Benchmark": backtest_metrics(comparison["Benchmark"])}).T

        weights_display = pd.DataFrame({
            "Wertpapier": [a["name"] for a in assets],
            "Ticker": [a["symbol"] for a in assets],
            "Gewicht": [float(w / weights.sum()) for w in weights],
        })

        return html.Div([
            *alerts,
            dmc.Grid([
                dmc.GridCol(_card("Wertentwicklung", [tv_chart("aa-perf-chart", perf_spec)]), span=6),
                dmc.GridCol(_card("Drawdown", [tv_chart("aa-dd-chart", dd_spec)]), span=6),
            ]),
            _card("Kennzahlen", [
                ag_heat_table(stats, reverse_columns={"Volatilität p.a."}),
            ]),
            _card("Backtest-Konfiguration", [
                ag_table(weights_display, formats={"Gewicht": "percent"}),
                dmc.Text(
                    f"Rebalancing: {rebalance} · Zeitraum: {comparison.index.min():%d.%m.%Y} – {comparison.index.max():%d.%m.%Y}",
                    size="xs", c="dimmed", mt="sm",
                ),
            ]),
        ])

    @app.callback(
        Output("aa-model-results", "children"),
        Input("aa-model-run-button", "n_clicks"),
        State("aa-model-portfolios", "value"),
        State("aa-model-period", "value"),
        State("aa-model-rebalance", "value"),
        State("aa-model-inflation", "value"),
        State("aa-model-top-count", "value"),
        State({"type": "aa-model-weight", "metric": ALL}, "value"),
        State({"type": "aa-model-weight", "metric": ALL}, "id"),
        prevent_initial_call=True,
    )
    def compare_model_portfolios(
        _n, selected_models, time_period, rebalance, inflation_percent, top_count,
        metric_weight_values, metric_weight_ids,
    ):
        selected_models = [name for name in (selected_models or []) if name in MODEL_PORTFOLIOS]
        if len(selected_models) < 2:
            return dmc.Alert("Bitte mindestens zwei Modellportfolios auswählen.", color="red")

        metric_weights = {
            item["metric"]: value
            for item, value in zip(metric_weight_ids or [], metric_weight_values or [])
        }
        if not any(float(value or 0) > 0 for value in metric_weights.values()):
            return dmc.Alert("Mindestens ein Kennzahlengewicht muss größer als 0 sein.", color="red")

        model_weights = {name: model_proxy_weights(name) for name in selected_models}
        required_tickers = sorted({ticker for weights in model_weights.values() for ticker in weights})
        loaded, load_errors = {}, {}
        with ThreadPoolExecutor(max_workers=min(8, len(required_tickers))) as executor:
            futures = {executor.submit(asset_series_eur, ticker): ticker for ticker in required_tickers}
            for future in as_completed(futures):
                ticker = futures[future]
                try:
                    loaded[ticker] = future.result()[0].rename(ticker)
                except Exception as exc:
                    load_errors[ticker] = str(exc)

        valid_models = [
            name for name in selected_models
            if all(ticker in loaded for ticker in model_weights[name])
        ]
        skipped_models = [name for name in selected_models if name not in valid_models]
        alerts = []
        if skipped_models:
            missing = ", ".join(sorted(load_errors))
            alerts.append(dmc.Alert(
                f"Übersprungen wegen fehlender Kursdaten: {', '.join(skipped_models)}. "
                f"Betroffene Proxys: {missing}.", color="yellow", mb="sm",
            ))
        if len(valid_models) < 2:
            return html.Div([*alerts, dmc.Alert("Für einen Vergleich sind nicht genügend Portfolios verfügbar.", color="red")])

        used_tickers = sorted({ticker for name in valid_models for ticker in model_weights[name]})
        prices = pd.concat({ticker: loaded[ticker] for ticker in used_tickers}, axis=1).dropna()
        years_back = {
            "Letzte 5 Jahre": 5,
            "Letzte 10 Jahre": 10,
            "Letzte 15 Jahre": 15,
        }.get(time_period)
        if years_back:
            prices = prices[prices.index >= prices.index.max() - pd.DateOffset(years=years_back)]
        if len(prices) < 252:
            return html.Div([*alerts, dmc.Alert("Der gemeinsame Kurszeitraum ist kürzer als ein Jahr.", color="red")])

        portfolio_series = {}
        stats_rows = {}
        inflation_rate = float(inflation_percent or 0.0) / 100.0
        for name in valid_models:
            weights = model_weights[name]
            tickers = list(weights)
            series = backtest_portfolio(prices[tickers], [weights[ticker] for ticker in tickers], rebalance)
            portfolio_series[name] = series
            stats_rows[name] = model_portfolio_statistics(series, inflation_rate)

        stats = pd.DataFrame.from_dict(stats_rows, orient="index")
        try:
            stats["score"] = weighted_model_scores(stats, metric_weights)
        except ValueError as exc:
            return html.Div([*alerts, dmc.Alert(str(exc), color="red")])
        stats = stats.sort_values("score", ascending=False)

        ordered_names = list(stats.index)
        top_count = max(2, min(int(top_count or 5), 10, len(ordered_names)))
        chart_names = ordered_names[:top_count]
        real_series = {}
        for name in chart_names:
            series = portfolio_series[name]
            elapsed_years = (series.index - series.index[0]).days / 365.25
            real = series / np.power(1.0 + inflation_rate, elapsed_years)
            real_series[name] = real / real.iloc[0] * 100.0

        performance_spec = tv_spec([
            tv_series(name, real_series[name], PALETTE[index % len(PALETTE)])
            for index, name in enumerate(chart_names)
        ], height=450, log_scale=True, value_format="ratio", rebase_visible=True)
        drawdowns = {name: series / series.cummax() - 1.0 for name, series in real_series.items()}
        drawdown_spec = tv_spec([
            tv_series(name, drawdowns[name] * 100.0, PALETTE[index % len(PALETTE)])
            for index, name in enumerate(chart_names)
        ], height=450, value_format="percent")

        score_names = list(reversed(ordered_names))
        score_chart = {
            "animation": False,
            "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"}},
            "grid": {"left": 190, "right": 55, "top": 12, "bottom": 30},
            "xAxis": {"type": "value", "min": 0, "max": 100, "name": "Score"},
            "yAxis": {"type": "category", "data": score_names, "axisLabel": {"fontSize": 11}},
            "series": [{
                "name": "Gewichteter Score", "type": "bar", "barMaxWidth": 22,
                "data": [round(float(stats.loc[name, "score"]), 2) for name in score_names],
                "itemStyle": {"color": PALETTE[2], "borderRadius": [0, 3, 3, 0]},
                "label": {"show": True, "position": "right", "formatter": "{c}"},
            }],
        }

        display = pd.DataFrame(index=stats.index)
        display["Rang"] = np.arange(1, len(stats) + 1)
        display["Portfolio"] = display.index
        display["Score"] = stats["score"]
        for metric, label in MODEL_SCORE_LABELS.items():
            display[label] = stats[metric]
        display = display.reset_index(drop=True)
        table_formats = {"Score": "ratio", **{label: "percent" for label in MODEL_SCORE_LABELS.values()}}

        allocation_rows = []
        for name in ordered_names:
            parts = []
            for item in MODEL_PORTFOLIOS[name].split(","):
                asset_code, weight = item.split(":")
                ticker, _ = ASSET_CLASS_PROXIES[asset_code]
                parts.append(f"{weight}% {asset_code} ({ticker})")
            allocation_rows.append({"Portfolio": name, "Allokation / Proxy": " · ".join(parts)})

        used_codes = sorted({
            item.split(":")[0]
            for name in valid_models
            for item in MODEL_PORTFOLIOS[name].split(",")
        })
        proxy_rows = pd.DataFrame([
            {"Code": code, "Anlageklasse": ASSET_CLASS_PROXIES[code][1], "ETF-Proxy": ASSET_CLASS_PROXIES[code][0]}
            for code in used_codes
        ])

        return html.Div([
            *alerts,
            dmc.Grid([
                dmc.GridCol(_card("Reale Wertentwicklung", [
                    tv_chart("aa-model-performance-chart", performance_spec),
                ]), span=6),
                dmc.GridCol(_card("Realer Drawdown", [
                    tv_chart("aa-model-drawdown-chart", drawdown_spec),
                ]), span=6),
            ]),
            _card("Gewichtetes Gesamtranking", [
                echart("aa-model-score-chart", score_chart, height=max(430, len(ordered_names) * 29)),
            ]),
            _card("Portfolio-Matrix", [
                ag_table(display, formats=table_formats, height=560, page_size=25),
                dmc.Text(
                    "Der Score ist der gewichtete Mittelwert der Perzentilränge. Bei Rendite und "
                    "Entnahmerate ist mehr besser; bei Volatilität, Ulcer Index, Verlusttiefe und "
                    "Startzeit-Sensitivität ist weniger besser.",
                    size="xs", c="dimmed", mt="sm",
                ),
            ]),
            _card("Modellallokationen", [
                ag_table(pd.DataFrame(allocation_rows), height=480, page_size=10),
            ]),
            _card("Verwendete ETF-Proxys", [
                ag_table(proxy_rows, height=480, page_size=15),
                dmc.Text(
                    f"Gemeinsamer Zeitraum: {prices.index.min():%d.%m.%Y} – {prices.index.max():%d.%m.%Y} · "
                    f"Rebalancing: {rebalance} · Inflation: {inflation_rate:.2%}",
                    size="xs", c="dimmed", mt="sm",
                ),
            ]),
        ])

    @app.callback(
        Output("aa-explorer-results", "children"),
        Input("aa-explorer-button", "n_clicks"),
        State("aa-assets-store", "data"),
        State("aa-explorer-metric", "value"),
        State("aa-explorer-step", "value"),
        State("aa-explorer-horizon", "value"),
        State("aa-explorer-inflation", "value"),
        prevent_initial_call=True,
    )
    def run_explorer(_n, assets, metric, step, horizon_years, inflation_percent):
        assets = assets or []
        if len(assets) < 2:
            return dmc.Alert("Für den Portfolio Explorer mindestens zwei Wertpapiere hinzufügen.", color="red")

        try:
            allocations = allocation_grid(len(assets), int(step))
        except ValueError as exc:
            return dmc.Alert(str(exc), color="yellow")

        price_series, errors = {}, []
        for asset in assets:
            try:
                series, _ = asset_series_eur(asset["symbol"])
                price_series[asset["symbol"]] = series
            except Exception as exc:
                errors.append(str(exc))
        alerts = [dmc.Alert(error, color="yellow", mb=4) for error in errors]
        if len(price_series) != len(assets):
            return html.Div([*alerts, dmc.Alert("Nicht alle Kursreihen konnten geladen werden.", color="red")])

        prices = pd.concat(price_series, axis=1).dropna()
        monthly_prices = prices.resample("ME").last().dropna()
        horizon_years = int(horizon_years or 10)
        inflation_rate = float(inflation_percent or 0.0) / 100.0
        available_years = max(0, (len(monthly_prices) - 1) // 12)
        if metric != "ulcer" and horizon_years > available_years:
            return html.Div([
                *alerts,
                dmc.Alert(
                    f"Der gemeinsame Kurszeitraum reicht nur für {available_years} volle Jahre. "
                    "Bitte den Analysezeitraum verkürzen oder ältere Wertpapiere auswählen.",
                    color="yellow",
                ),
            ])

        current_weights = np.asarray([float(asset.get("weight", 0.0)) for asset in assets], dtype=float)
        if current_weights.sum() <= 0:
            return dmc.Alert("Die aktuellen Portfoliogewichte müssen in Summe größer als 0 sein.", color="red")
        current_weights /= current_weights.sum()

        try:
            all_allocations = np.vstack([allocations, current_weights])
            paths = explorer_portfolio_values(monthly_prices, all_allocations)
            all_scores = explorer_scores(paths, metric, horizon_years, inflation_rate)
        except (ValueError, FloatingPointError) as exc:
            return html.Div([*alerts, dmc.Alert(str(exc), color="red")])

        scores = all_scores[:-1]
        current_score = float(all_scores[-1])
        finite = np.flatnonzero(np.isfinite(scores))
        if not len(finite) or not np.isfinite(current_score):
            return html.Div([*alerts, dmc.Alert("Für diese Einstellung konnten keine Kennzahlen berechnet werden.", color="red")])

        maximize = metric != "ulcer"
        order = finite[np.argsort(-scores[finite] if maximize else scores[finite])]
        top = order[:100]
        current_rank = 1 + int(np.sum(scores[finite] > current_score if maximize else scores[finite] < current_score))
        percentile = 100.0 * (1.0 - (current_rank - 1) / max(1, len(finite)))

        symbols = [asset["symbol"] for asset in assets]
        metric_label = EXPLORER_METRICS.get(metric, metric)
        rows = []
        for rank, allocation_index in enumerate(top, start=1):
            row = {"Rang": rank, metric_label: float(scores[allocation_index])}
            row.update({symbol: float(weight) for symbol, weight in zip(symbols, allocations[allocation_index])})
            rows.append(row)
        ranking = pd.DataFrame(rows)
        percent_columns = {metric_label: "percent", **{symbol: "percent" for symbol in symbols}}

        allocation_chart = {
            "animation": False,
            "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"}},
            "legend": {"data": symbols, "top": 4},
            "grid": {"left": 48, "right": 16, "top": 48, "bottom": 42},
            "xAxis": {
                "type": "category",
                "data": [f"#{rank}" for rank in range(1, len(top) + 1)],
                "name": "Rang",
                "axisLabel": {"interval": 9},
            },
            "yAxis": {
                "type": "value", "min": 0, "max": 100, "name": "Allokation",
                "axisLabel": {"formatter": "{value} %"},
            },
            "series": [
                {
                    "name": symbol,
                    "type": "bar",
                    "stack": "allocation",
                    "barWidth": "92%",
                    "itemStyle": {"color": PALETTE[index % len(PALETTE)]},
                    "data": [round(float(allocations[row, index] * 100.0), 6) for row in top],
                }
                for index, symbol in enumerate(symbols)
            ],
        }

        score_text = f"{current_score * 100:.2f} %"
        direction_text = "höher ist besser" if maximize else "niedriger ist besser"
        horizon_text = (f"Horizont: {horizon_years} Jahre" if metric != "ulcer"
                        else "Ulcer Index: gesamter gemeinsamer Zeitraum")
        return html.Div([
            *alerts,
            dmc.SimpleGrid(cols=3, spacing="md", children=[
                _card("Untersuchte Allokationen", [dmc.Title(f"{len(finite):,}", order=3)]),
                _card("Rang des aktuellen Portfolios", [dmc.Title(f"#{current_rank}", order=3)]),
                _card("Perzentil / Ergebnis", [
                    dmc.Title(f"{percentile:.1f}. Perzentil", order=3),
                    dmc.Text(f"{score_text} · {direction_text}", size="xs", c="dimmed"),
                ]),
            ]),
            _card("Top-100-Allokationen", [
                echart("aa-explorer-allocation-chart", allocation_chart, height=440),
            ]),
            _card("Rangliste", [
                ag_table(ranking, formats=percent_columns, height=520, page_size=25),
                dmc.Text(
                    f"Gemeinsamer Zeitraum: {monthly_prices.index.min():%d.%m.%Y} – "
                    f"{monthly_prices.index.max():%d.%m.%Y} · {horizon_text} · "
                    f"Inflation: {inflation_rate:.2%} · jährliches Rebalancing",
                    size="xs", c="dimmed", mt="sm",
                ),
            ]),
        ])
