from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import dash_mantine_components as dmc
import pandas as pd
from dash import Input, Output, dcc, html

from src.cache import LONG_TTL, cache
from src.data import download_adjusted_close
from src.metrics import cagr, max_drawdown, annual_volatility
from src.theme import (
    DOWN, PALETTE, UP,
    ag_heat_table, card_header, sparkline_figure, tv_chart, tv_series, tv_spec,
)

ASSET_CLASSES = [
    {"key": "equities", "label": "Aktien (Global)", "sub": "MSCI ACWI", "ticker": "ACWI", "href": "/laender"},
    {"key": "bonds", "label": "Anleihen", "sub": "US Aggregate Bond", "ticker": "AGG", "href": "/anleihen"},
    {"key": "commodities", "label": "Commodities", "sub": "DB Commodity Index", "ticker": "DBC", "href": "/commodities"},
    {"key": "real_estate", "label": "Immobilien (REITs)", "sub": "US Real Estate", "ticker": "VNQ", "href": "/immobilien"},
    {"key": "hedge_funds", "label": "Hedge Fonds", "sub": "Multi-Strategy (QAI)", "ticker": "QAI", "href": "/hedge-fonds"},
    {"key": "crypto", "label": "Kryptowährungen", "sub": "Bitcoin", "ticker": "BTC-USD", "href": "/krypto"},
    {"key": "cash", "label": "Liquidität / Geldmarkt", "sub": "1-3M T-Bills", "ticker": "BIL", "href": "/geldmarkt"},
]

RANGE_OPTIONS = [
    {"label": "1J", "value": "1"}, {"label": "3J", "value": "3"}, {"label": "5J", "value": "5"},
    {"label": "10J", "value": "10"}, {"label": "Max", "value": "max"},
]


@cache.memoize(timeout=LONG_TTL)
def _asset_class_series(ticker: str) -> pd.Series:
    try:
        return download_adjusted_close(ticker, start="2000-01-01")
    except Exception:
        return pd.Series(dtype=float)


def _filtered(series: pd.Series, years) -> pd.Series:
    s = series.dropna()
    if s.empty or years == "max":
        return s
    cutoff = pd.Timestamp.now() - pd.DateOffset(years=int(years))
    return s[s.index >= cutoff]


ASSET_CLASS_COLORS = [PALETTE[0], PALETTE[2], PALETTE[5], PALETTE[3], PALETTE[9], PALETTE[4], PALETTE[7], PALETTE[8]]


def _overview_spec(years):
    series_list = []
    for i, item in enumerate(ASSET_CLASSES):
        s = _filtered(_asset_class_series(item["ticker"]), years)
        if len(s) < 2:
            continue
        indexed = s / s.iloc[0] * 100.0
        series_list.append(tv_series(item["label"], indexed, ASSET_CLASS_COLORS[i % len(ASSET_CLASS_COLORS)]))
    return tv_spec(series_list, height=480, log_scale=True, value_format="ratio")


def _stat_card(item, series):
    s = series.dropna()
    href = item.get("href")
    card_kwargs = dict(p="md", radius="md", withBorder=True,
                        className="stat-card stat-card-clickable" if href else "stat-card")

    if len(s) < 2:
        card = dmc.Paper(dmc.Text(f"{item['label']}: keine Daten", size="xs", c="dimmed"), **card_kwargs)
    else:
        period_return = float(s.iloc[-1] / s.iloc[0] - 1.0)
        color = UP if period_return >= 0 else DOWN
        card = dmc.Paper(
            [
                dmc.Group([
                    dmc.Stack([
                        dmc.Text(item["label"].upper(), className="stat-label"),
                        dmc.Text(item["sub"], size="10px", c="dimmed"),
                    ], gap=0),
                    dmc.Text(f"{period_return:+.1%}", size="lg", fw=700, c=("teal" if period_return >= 0 else "red")),
                ], justify="space-between", align="flex-start"),
                dcc.Graph(figure=sparkline_figure(s.tail(252), color), config={"staticPlot": True},
                          style={"height": "40px", "marginTop": "6px"}),
            ],
            **card_kwargs,
        )

    if href:
        return dcc.Link(card, href=href, className="stat-card-link")
    return card


def _metrics_table(years):
    rows = {}
    for item in ASSET_CLASSES:
        s = _filtered(_asset_class_series(item["ticker"]), years).dropna()
        if len(s) < 2:
            continue
        cg = cagr(s)
        dd = max_drawdown(s)
        rows[item["label"]] = {
            "Gesamtrendite": float(s.iloc[-1] / s.iloc[0] - 1.0),
            "CAGR p.a.": cg,
            "Volatilität p.a.": annual_volatility(s),
            "Max. Drawdown": dd,
            "Calmar": cg / abs(dd) if dd and dd == dd and dd != 0 else None,
        }
    df = pd.DataFrame.from_dict(rows, orient="index")
    if df.empty:
        return dmc.Text("Keine Daten verfügbar.", size="sm", c="dimmed")
    return ag_heat_table(df, reverse_columns={"Volatilität p.a.", "Max. Drawdown"})


def _card(title, children):
    return html.Div([html.Div(title, className="section-title"), *children], className="section-card")


def layout(params=None):
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(_asset_class_series, [item["ticker"] for item in ASSET_CLASSES]))
    return html.Div([
        dmc.Title("Markets Overview", order=3, mb="xs"),
        dmc.Text(
            "Ein Blick über alle wichtigen Anlageklassen hinweg – bevor es ins Detail geht "
            "(China Markets, Sektor-Rotation, Commodities, Asset Allocation).",
            size="sm", c="dimmed", mb="md",
        ),

        dmc.SimpleGrid(
            [_stat_card(item, _filtered(_asset_class_series(item["ticker"]), "1")) for item in ASSET_CLASSES],
            cols={"base": 2, "sm": 3, "md": 4, "lg": 7}, spacing="sm", mb="md",
        ),

        html.Div([
            card_header("Wertentwicklung nach Anlageklasse", dmc.SegmentedControl(
                id="overview-range", data=RANGE_OPTIONS, value="5", size="xs",
                persistence=True, persistence_type="session",
            )),
            tv_chart("overview-chart", _overview_spec("5")),
        ], className="section-card"),

        _card("Kennzahlen je Anlageklasse", [html.Div(id="overview-metrics", children=_metrics_table("5"))]),
    ])


def register_callbacks(app):
    @app.callback(
        Output({"type": "tv-chart-data", "index": "overview-chart"}, "data"),
        Output("overview-metrics", "children"),
        Input("overview-range", "value"),
    )
    def update_overview(years):
        return _overview_spec(years), _metrics_table(years)
