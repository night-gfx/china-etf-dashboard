from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import math

import dash_mantine_components as dmc
import pandas as pd
from dash import Input, Output, State, ctx, dcc, html, no_update
from dash.exceptions import PreventUpdate

from src.cache import INTRADAY_TTL, LONG_TTL, cache
from src.data import download_adjusted_close, download_intraday_close
from src.metrics import cagr, max_drawdown
from src.theme import (
    PALETTE,
    ag_heat_table, ag_value_formatter, card_header,
    recharts_sparkline,
    tv_chart, tv_series, tv_spec,
)

ASSET_CLASSES = [
    {"key": "equities", "label": "Aktien", "description": "Globale Aktienmärkte vergleichen und Entwicklungen einordnen.", "sub": "MSCI ACWI", "ticker": "ACWI", "href": "/aktien", "icon": "tabler:chart-line"},
    {"key": "bonds", "label": "Anleihen", "description": "Staats- und Unternehmensanleihen vergleichen und Zinsmärkte analysieren.", "sub": "US Aggregate Bond", "ticker": "AGG", "href": "/anleihen", "icon": "tabler:certificate"},
    {"key": "commodities", "label": "Commodities", "description": "Rohstoffmärkte und ihre langfristige Entwicklung untersuchen.", "sub": "DB Commodity Index", "ticker": "DBC", "href": "/commodities", "icon": "tabler:flask"},
    {"key": "real_estate", "label": "Immobilien", "description": "Globale Immobilienmärkte und börsennotierte REITs vergleichen.", "sub": "US Real Estate", "ticker": "VNQ", "href": "/immobilien", "icon": "tabler:building-estate"},
    {"key": "hedge_funds", "label": "Hedge Fonds", "description": "Alternative Strategien und ihre Wertentwicklung vergleichen.", "sub": "Multi-Strategy (QAI)", "ticker": "QAI", "href": "/hedge-funds", "icon": "tabler:chart-arrows"},
    {"key": "crypto", "label": "Krypto", "description": "Digitale Vermögenswerte und ihre Marktentwicklung verfolgen.", "sub": "Bitcoin", "ticker": "BTC-USD", "href": "/krypto", "icon": "tabler:currency-bitcoin"},
    {"key": "cash", "label": "Geldmarkt", "description": "Kurzfristige Zinsen und risikoarme Geldmarktanlagen vergleichen.", "sub": "1-3M T-Bills", "ticker": "BIL", "href": "/geldmarkt", "icon": "tabler:cash"},
]

RANGE_OPTIONS = [
    {"label": html.Span("1J", className="overview-range-option overview-range-1"), "value": "1"},
    {"label": html.Span("3J", className="overview-range-option overview-range-3"), "value": "3"},
    {"label": html.Span("5J", className="overview-range-option overview-range-5"), "value": "5"},
    {"label": html.Span("10J", className="overview-range-option overview-range-10"), "value": "10"},
    {"label": html.Span("Max", className="overview-range-option overview-range-max"), "value": "max"},
]


@cache.memoize(timeout=LONG_TTL, response_filter=lambda result: not result.empty)
def _asset_class_series(ticker: str) -> pd.Series:
    try:
        return download_adjusted_close(ticker, start="2000-01-01")
    except Exception:
        return pd.Series(dtype=float)


@cache.memoize(timeout=INTRADAY_TTL, response_filter=lambda result: not result.empty)
def _intraday_series(ticker: str) -> pd.Series:
    """Today's ~15min intraday prices (free via Yahoo, ~15min delayed). Falls
    back to the most recent trading day found in a wider window when today's
    session hasn't produced enough bars yet (e.g. right after the open, or
    market closed)."""
    try:
        s = download_intraday_close(ticker, period="1d", interval="15m")
        if len(s) >= 2:
            return s
        wider = download_intraday_close(ticker, period="5d", interval="15m")
        if wider.empty:
            return wider
        last_day = wider.index.normalize().max()
        return wider[wider.index.normalize() == last_day]
    except Exception:
        return pd.Series(dtype=float)


def _filtered(series: pd.Series, years) -> pd.Series:
    s = series.dropna().sort_index()
    if s.empty:
        return s
    if isinstance(years, dict):
        start = pd.to_datetime(years.get("start"), errors="coerce")
        end = pd.to_datetime(years.get("end"), errors="coerce")
        if pd.isna(start) or pd.isna(end):
            return s
        return s[(s.index >= start) & (s.index <= end)]
    if years == "max":
        return s
    cutoff = pd.Timestamp.now().normalize() - pd.DateOffset(years=int(years))
    return s[s.index >= cutoff]


ASSET_CLASS_COLORS = [PALETTE[0], PALETTE[2], PALETTE[5], PALETTE[3], PALETTE[9], PALETTE[4], PALETTE[7], PALETTE[8]]


def _overview_spec(years, drawdown=False, reset_range=None, chart_id="overview-chart"):
    selected_start, selected_end = _period_bounds(years)
    base_period = reset_range or {"start": selected_start, "end": selected_end}
    series_list = []
    for i, item in enumerate(ASSET_CLASSES):
        # Always load full history so users can freely zoom/scroll out past the
        # initially selected period (1J/3J/.../custom) without hitting a wall
        # of missing data - only the *visible* range is limited to the
        # selection below.
        s = _filtered(_asset_class_series(item["ticker"]), "max")
        if len(s) < 2:
            continue
        series_list.append(tv_series(
            item["label"], s, ASSET_CLASS_COLORS[i % len(ASSET_CLASS_COLORS)],
            show_last_value=False,
        ))
    spec = tv_spec(
        series_list,
        height=480,
        log_scale=False,
        value_format="percent",
        show_legend=True,
        legend_position="bottom",
    )
    spec["ariaLabel"] = "Drawdown der Anlageklassen" if drawdown else "Kumulierte Rendite der Anlageklassen"
    spec["rangeStoreId"] = f"{chart_id}-zoom-range"
    spec["resetRange"] = base_period
    spec["visibleRange"] = {"start": selected_start, "end": selected_end}
    spec["visibleTransform"] = "drawdown" if drawdown else "return"
    # Each chart gets its own sync group (its id) so it never syncs with the
    # other chart - they're independent now, but tv-chart.js still uses a
    # truthy syncGroup to size-reserve the left price scale consistently.
    spec["syncGroup"] = chart_id
    spec["syncKey"] = chart_id
    spec["leftAxis"] = True
    spec["rightValueLabels"] = True
    return spec


def _period_bounds(period):
    period = period or "5"
    if isinstance(period, dict):
        return period.get("start"), period.get("end")
    series = [_asset_class_series(item["ticker"]).dropna() for item in ASSET_CLASSES]
    available = [s for s in series if not s.empty]
    if not available:
        return None, None
    end_timestamp = max(s.index[-1] for s in available).normalize()
    end = end_timestamp.date().isoformat()
    if period == "max":
        start = min(s.index[0] for s in available).date().isoformat()
    else:
        start = (end_timestamp - pd.DateOffset(years=int(period))).date().isoformat()
    return start, end


def _display_date(value):
    if not value:
        return "-"
    return pd.to_datetime(value).strftime("%d.%m.%Y")


def _period_descriptions(period):
    start, end = _period_bounds(period)
    start_label, end_label = _display_date(start), _display_date(end)
    return (
        f"Kumulierte Rendite in % · Berechnungsfenster ab {start_label}",
        f"DDₜ = Pₜ / max(P₀…Pₜ) − 1 · Berechnungsfenster ab {start_label} · 0 % = neues Hoch",
        f"Tägliche adjustierte Schlusskurse vom {start_label} bis {end_label} · "
        "Annualisierte Werte mit 252 Handelstagen (Krypto: 365 Kalendertage)",
    )


def _previous_close(item):
    series = _asset_class_series(item["ticker"]).dropna().sort_index()
    if len(series) < 2:
        return None
    return float(series.iloc[-2])


def _daily_change(item):
    series = _asset_class_series(item["ticker"]).dropna().sort_index()
    if len(series) < 2:
        return None
    return float(series.iloc[-1] / series.iloc[-2] - 1)


def _stat_card(item):
    href = item.get("href")
    series = _intraday_series(item["ticker"])
    daily = _daily_change(item)
    previous_close = _previous_close(item)
    performance_text = "–" if daily is None else f"{daily:+.2%}".replace(".", ",")
    direction = "neutral" if daily is None else ("positive" if daily >= 0 else "negative")
    chart_color = "#16865c" if direction == "positive" else "#c54848" if direction == "negative" else "#7a808b"

    card = dmc.Paper(
        [
            html.Div([
                dmc.Text(item["label"], className="overview-selector-title", fw=700),
                dmc.Text(item["sub"], className="overview-proxy"),
            ], className="overview-selector-textblock"),
            html.Div([
                recharts_sparkline(
                    f"overview-sparkline-{item['key']}", series, chart_color, height=68,
                    reference_value=previous_close,
                ) if len(series) >= 2 else html.Div(className="overview-sparkline-empty"),
                dmc.Text(performance_text, className="overview-selector-performance"),
            ], className="overview-selector-performance-row"),
        ],
        p="md", radius=2, withBorder=False,
        className=(
            f"stat-card overview-selector-card overview-selector-{direction} "
            f"{'stat-card-clickable' if href else ''}"
        ).strip(),
    )

    if href:
        return dcc.Link(card, href=href, className="stat-card-link")
    return card


ANNUAL_METRICS = [
    {"label": "CAGR", "value": "cagr"},
    {"label": "Standard Deviation", "value": "volatility"},
    {"label": "Downside Deviation", "value": "downside_deviation"},
    {"label": "Max. Drawdown", "value": "drawdown"},
    {"label": "Sharpe Ratio", "value": "sharpe"},
    {"label": "Sortino Ratio", "value": "sortino"},
    {"label": "Calmar Ratio", "value": "calmar"},
]


def _statistics(s, item):
    returns = s.pct_change(fill_method=None).dropna()
    periods = 365 if item["ticker"] == "BTC-USD" else 252
    vol = float(returns.std(ddof=1) * math.sqrt(periods))
    annual_mean = float(returns.mean() * periods)
    downside = float(returns.clip(upper=0).pow(2).mean() ** 0.5 * math.sqrt(periods))
    cg, dd = cagr(s), max_drawdown(s)
    return {
        "return": float(s.iloc[-1] / s.iloc[0] - 1),
        "cagr": cg, "volatility": vol, "downside_deviation": downside, "drawdown": dd,
        "sharpe": annual_mean / vol if vol > 0 else float("nan"),
        "sortino": annual_mean / downside if downside > 0 else float("nan"),
        "calmar": cg / abs(dd) if dd < 0 else float("nan"),
    }


def _metrics_table(years):
    columns = {"CAGR": "cagr", "Standard Deviation": "volatility",
               "Downside Deviation": "downside_deviation",
               "Max. Drawdown": "drawdown", "Sharpe Ratio": "sharpe",
               "Sortino Ratio": "sortino", "Calmar Ratio": "calmar"}
    rows = {}
    for item in ASSET_CLASSES:
        s = _filtered(_asset_class_series(item["ticker"]), years)
        if len(s) >= 2:
            stats = _statistics(s, item)
            rows[item["label"]] = {label: stats[key] for label, key in columns.items()}
    table = _colored_table(pd.DataFrame.from_dict(rows, orient="index"))
    if hasattr(table, "columnDefs"):
        for col in table.columnDefs[1:]:
            kind = "percent" if columns[col["field"]] in {
                "cagr", "volatility", "downside_deviation", "drawdown"
            } else "ratio"
            col["valueFormatter"] = ag_value_formatter(kind)
    return table


def _annual_table(metric, years="max"):
    if metric not in {option["value"] for option in ANNUAL_METRICS}:
        metric = "cagr"
    rows = {}
    for item in ASSET_CLASSES:
        s = _filtered(_asset_class_series(item["ticker"]), years).sort_index()
        values = {}
        for year in sorted(set(s.index.year)):
            part = s[s.index.year == year]
            # Previous year's closing value includes the first trading day's return.
            previous = s[s.index < part.index[0]].tail(1)
            window = pd.concat([previous, part])
            if len(window) >= 2:
                values[str(year)] = _statistics(window, item)[metric]
        rows[item["label"]] = values
    df = pd.DataFrame.from_dict(rows, orient="index")
    df = df.reindex(index=[item["label"] for item in ASSET_CLASSES])
    df = df.reindex(columns=sorted(df.columns, reverse=True))
    table = _colored_table(df)
    if hasattr(table, "columnDefs"):
        for col in table.columnDefs[1:]:
            col["valueFormatter"] = ag_value_formatter(
                "percent" if metric in {
                    "cagr", "volatility", "downside_deviation", "drawdown"
                } else "ratio"
            )
            col["width"] = 110
    return table


def _colored_table(df):
    if df.empty:
        return dmc.Text("Keine Daten vorhanden.")
    table = ag_heat_table(df)
    for row in table.rowData:
        for col in df.columns:
            row.pop(f"__bg_{col}", None)
            row.pop(f"__fg_{col}", None)
    for col in table.columnDefs[1:]:
        col.pop("cellStyle", None)
    table.columnDefs[0].update({
        "headerName": "", "minWidth": 160,
        "cellStyle": {"fontWeight": "700", "color": "#16181d"},
    })
    table.defaultColDef = {**table.defaultColDef, "minWidth": 115, "flex": 1, "wrapHeaderText": True,
                          "autoHeaderHeight": False, "sortable": True}
    table.dashGridOptions.update({"rowHeight": 42, "headerHeight": 60, "autoSizeStrategy": None})
    return table


def _card(title, subtitle, children):
    return html.Div([
        html.Div([
            card_header(title, html.Div()),
            dmc.Text(subtitle, className="overview-section-subtitle", size="xs", c="dimmed"),
        ], className="overview-heading-box"),
        *children,
    ], className="section-card")


def _chart_section(chart_id, title, drawdown, default_period="5"):
    """A single chart card: heading, its own period controls (date range +
    1J/3J/.../Max), and the chart itself - fully independent from any other
    chart's period selection."""
    initial_start, initial_end = _period_bounds(default_period)
    return_description, drawdown_description, _ = _period_descriptions(default_period)
    description = drawdown_description if drawdown else return_description
    return html.Div([
        html.Div([
            card_header(title, html.Div()),
            dmc.Text(description, id=f"{chart_id}-description",
                     className="overview-section-subtitle", size="xs", c="dimmed"),
        ], className="overview-heading-box"),
        html.Div([
            html.Div([
                html.Div([
                    dcc.DatePickerRange(
                        id=f"{chart_id}-custom-range", start_date=initial_start, end_date=initial_end,
                        display_format="DD.MM.YYYY", number_of_months_shown=2,
                        clearable=False, minimum_nights=1,
                        updatemode="bothdates",
                        start_date_placeholder_text="Startdatum",
                        end_date_placeholder_text="Enddatum",
                        className="overview-date-range",
                    ),
                ], className="overview-date-control"),
            ], className="overview-control-group"),
            html.Div([
                dmc.SegmentedControl(
                    id=f"{chart_id}-range", data=RANGE_OPTIONS, value=default_period,
                    className="overview-range-selector",
                    **{"aria-label": "Vordefinierten Zeitraum auswählen"},
                ),
            ], className="overview-control-group overview-preset-control"),
        ], className="overview-controls"),
        dcc.Store(id=f"{chart_id}-zoom-range"),
        dcc.Store(id=f"{chart_id}-zoom-base", data={"start": initial_start, "end": initial_end}),
        tv_chart(chart_id, _overview_spec(default_period, drawdown=drawdown, chart_id=chart_id)),
    ], className="section-card")


def layout(params=None):
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(_asset_class_series, [item["ticker"] for item in ASSET_CLASSES]))
    metrics_description = _period_descriptions("max")[2]
    return html.Div([
        html.Div([
            html.Div(
                [_stat_card(item) for item in ASSET_CLASSES],
                className="overview-asset-grid",
            ),
        ], className="overview-asset-panel"),
        html.Div([
            _chart_section("overview-chart", "Rendite", False, default_period="1"),
            _chart_section("overview-drawdown", "Drawdown", True, default_period="max"),
        ], className="overview-two-columns"),
        html.Div([
            _card("Periodenkennzahlen", metrics_description, [
                html.Div(children=_metrics_table("max")),
            ]),
            html.Div([
                html.Div([
                    card_header("Jahreskennzahlen", dmc.Select(
                        id="overview-annual-metric", data=ANNUAL_METRICS, value="cagr",
                        allowDeselect=False, style={"width": "180px"},
                        className="overview-annual-select",
                    )),
                    dmc.Text("Kalenderjahreswerte aus adjustierten Schlusskursen (maximaler Zeitraum) · Kennzahl rechts auswählen",
                             className="overview-section-subtitle", size="xs", c="dimmed"),
                ], className="overview-heading-box"),
                html.Div(id="overview-annual", children=_annual_table("cagr", "max")),
            ], className="section-card"),
        ], className="overview-two-columns"),
    ], className="markets-overview")


def _register_chart_callback(app, chart_id, drawdown):
    """Wires one chart's own period controls (date range + preset buttons) to
    its own chart data - fully independent of any other chart on the page."""
    custom_range_id = f"{chart_id}-custom-range"
    range_id = f"{chart_id}-range"
    zoom_range_id = f"{chart_id}-zoom-range"
    zoom_base_id = f"{chart_id}-zoom-base"
    description_id = f"{chart_id}-description"

    @app.callback(
        Output(custom_range_id, "start_date"),
        Output(custom_range_id, "end_date"),
        Output(range_id, "value"),
        Output({"type": "tv-chart-data", "index": chart_id}, "data"),
        Output(description_id, "children"),
        Output(zoom_base_id, "data"),
        Input(zoom_range_id, "data"),
        Input(range_id, "value"),
        Input(custom_range_id, "start_date"),
        Input(custom_range_id, "end_date"),
        State(zoom_base_id, "data"),
    )
    def update_chart(zoom_range, years, custom_start, custom_end, zoom_base):
        trigger = ctx.triggered_id
        base_output = no_update
        if trigger == zoom_range_id:
            if not isinstance(zoom_range, dict):
                raise PreventUpdate
            start, end = zoom_range.get("start"), zoom_range.get("end")
            range_output = None
        elif trigger == custom_range_id or not years:
            start, end = custom_start, custom_end
            range_output = None
        else:
            start, end = _period_bounds(years)
            range_output = years

        start_date = pd.to_datetime(start, errors="coerce")
        end_date = pd.to_datetime(end, errors="coerce")
        if pd.isna(start_date) or pd.isna(end_date) or start_date >= end_date:
            raise PreventUpdate
        selected_period = {"start": start_date.date().isoformat(), "end": end_date.date().isoformat()}
        if trigger == custom_range_id and zoom_base == selected_period:
            # The preset-button branch below writes its computed dates back
            # into this same date picker, which is also one of this
            # callback's Inputs - that self-triggers a second, redundant
            # firing with trigger == custom_range_id but an identical period.
            # Without this guard that second firing forces the TradingView
            # chart to fully tear down and rebuild (see tv-chart.js), which
            # briefly repaints raw/untransformed series before the %-return
            # transform reapplies - a visible flash of "wrong" data.
            raise PreventUpdate
        if trigger != zoom_range_id:
            zoom_base = selected_period
            base_output = zoom_base
        zoom_base = zoom_base or selected_period
        return_description, drawdown_description, _ = _period_descriptions(selected_period)
        description = drawdown_description if drawdown else return_description
        spec = _overview_spec(selected_period, drawdown=drawdown, reset_range=zoom_base, chart_id=chart_id)
        return (selected_period["start"], selected_period["end"], range_output, spec,
                description, base_output)


def register_callbacks(app):
    _register_chart_callback(app, "overview-chart", drawdown=False)
    _register_chart_callback(app, "overview-drawdown", drawdown=True)

    @app.callback(
        Output("overview-annual", "children"),
        Input("overview-annual-metric", "value"),
    )
    def update_annual(metric):
        return _annual_table(metric, "max")
