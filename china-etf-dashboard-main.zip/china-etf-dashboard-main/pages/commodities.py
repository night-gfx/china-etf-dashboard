from __future__ import annotations

import numpy as np
import pandas as pd
import yfinance as yf
from dash import Input, Output, dcc, html
import dash_mantine_components as dmc

from src.cache import LONG_TTL, cache
from src.theme import (
    DOWN, PALETTE, UP,
    ag_table, echart, hex_to_rgb, sparkline_figure, tv_chart, tv_series, tv_spec,
)

CLASS_COLORS = {
    "Energie": "#e0623c",
    "Metalle": "#c9a14a",
    "Getreide & Ölsaaten": "#7fb069",
    "Soft Commodities": "#a9744f",
    "Vieh": "#b0524a",
}


def _lighten(hex_color, factor):
    r, g, b = hex_to_rgb(hex_color)
    r = round(r + (255 - r) * factor)
    g = round(g + (255 - g) * factor)
    b = round(b + (255 - b) * factor)
    return f"rgb({r},{g},{b})"

COMMODITY_UNIVERSE = [
    {"class": "Energie", "name": "WTI Rohöl", "ticker": "CL=F"},
    {"class": "Energie", "name": "Brent Rohöl", "ticker": "BZ=F"},
    {"class": "Energie", "name": "Erdgas", "ticker": "NG=F"},
    {"class": "Energie", "name": "RBOB Benzin", "ticker": "RB=F"},
    {"class": "Energie", "name": "Heizöl", "ticker": "HO=F"},
    {"class": "Metalle", "name": "Gold", "ticker": "GC=F"},
    {"class": "Metalle", "name": "Silber", "ticker": "SI=F"},
    {"class": "Metalle", "name": "Kupfer", "ticker": "HG=F"},
    {"class": "Metalle", "name": "Platin", "ticker": "PL=F"},
    {"class": "Metalle", "name": "Palladium", "ticker": "PA=F"},
    {"class": "Getreide & Ölsaaten", "name": "Mais", "ticker": "ZC=F"},
    {"class": "Getreide & Ölsaaten", "name": "Weizen", "ticker": "ZW=F"},
    {"class": "Getreide & Ölsaaten", "name": "Sojabohnen", "ticker": "ZS=F"},
    {"class": "Getreide & Ölsaaten", "name": "Sojaöl", "ticker": "ZL=F"},
    {"class": "Getreide & Ölsaaten", "name": "Sojaschrot", "ticker": "ZM=F"},
    {"class": "Soft Commodities", "name": "Kaffee", "ticker": "KC=F"},
    {"class": "Soft Commodities", "name": "Zucker", "ticker": "SB=F"},
    {"class": "Soft Commodities", "name": "Kakao", "ticker": "CC=F"},
    {"class": "Soft Commodities", "name": "Baumwolle", "ticker": "CT=F"},
    {"class": "Soft Commodities", "name": "Orangensaft", "ticker": "OJ=F"},
    {"class": "Vieh", "name": "Live Cattle", "ticker": "LE=F"},
    {"class": "Vieh", "name": "Lean Hogs", "ticker": "HE=F"},
]
COMMODITY_BY_TICKER = {item["ticker"]: item for item in COMMODITY_UNIVERSE}
COMMODITY_CLASS_ORDER = list(dict.fromkeys(item["class"] for item in COMMODITY_UNIVERSE))


@cache.memoize(timeout=LONG_TTL)
def commodity_prices_usd() -> pd.DataFrame:
    tickers = [item["ticker"] for item in COMMODITY_UNIVERSE]
    try:
        data = yf.download(
            tickers=tickers, start="1990-01-01", auto_adjust=False,
            progress=False, threads=True, group_by="column",
        )
    except Exception:
        return pd.DataFrame()
    if data is None or data.empty:
        return pd.DataFrame()
    if isinstance(data.columns, pd.MultiIndex):
        level0 = data.columns.get_level_values(0)
        if "Adj Close" in level0:
            prices = data["Adj Close"].copy()
        elif "Close" in level0:
            prices = data["Close"].copy()
        else:
            return pd.DataFrame()
    else:
        field = "Adj Close" if "Adj Close" in data.columns else "Close"
        if field not in data.columns:
            return pd.DataFrame()
        prices = data[[field]].copy()
        prices.columns = [tickers[0]]
    if isinstance(prices, pd.Series):
        prices = prices.to_frame()
    prices = prices.apply(pd.to_numeric, errors="coerce")
    if isinstance(prices.index, pd.DatetimeIndex) and prices.index.tz is not None:
        prices.index = prices.index.tz_localize(None)
    prices = prices[~prices.index.duplicated(keep="last")].sort_index()
    prices = prices.loc[:, prices.notna().sum(axis=0) >= 252]
    return prices.dropna(how="all")


def _commodity_common_returns(prices):
    if prices.empty:
        return pd.DataFrame()
    returns = prices.pct_change(fill_method=None).replace([np.inf, -np.inf], np.nan)
    common = returns.dropna(how="any").sort_index()
    return common


def _equal_weight_commodity_index(index_return):
    if index_return.empty:
        return pd.Series(dtype=float)
    index = (1.0 + index_return).cumprod() * 100.0
    index.name = "Equal Weighted Commodity Index"
    return index


def _annual_rebalanced_index(common_returns):
    """Index methodology: on the first trading day of each calendar year the
    portfolio is reset so the 5 commodity classes are equal-weighted (20%
    each); within a class, weight is split equally across its constituents.
    Between rebalances weights drift with each commodity's own performance
    (buy-and-hold). Returns (portfolio daily return, per-ticker weight over
    time, per-class weight over time)."""
    if common_returns.empty:
        empty = pd.DataFrame(index=common_returns.index)
        return pd.Series(dtype=float), empty, empty

    tickers = list(common_returns.columns)
    ticker_class = {t: COMMODITY_BY_TICKER[t]["class"] for t in tickers}
    class_counts = {}
    for cls in ticker_class.values():
        class_counts[cls] = class_counts.get(cls, 0) + 1
    n_classes = len(class_counts)
    base_weight = pd.Series(
        {t: (1.0 / n_classes) / class_counts[ticker_class[t]] for t in tickers}, index=tickers,
    )

    dates = common_returns.index
    weight_rows = []
    port_returns = []
    current = base_weight.copy()
    prev_year = None
    for date in dates:
        if date.year != prev_year:
            current = base_weight.copy()
            prev_year = date.year
        weight_rows.append(current.copy())
        r = common_returns.loc[date]
        port_ret = float((current * r).sum())
        port_returns.append(port_ret)
        grown = current * (1.0 + r)
        total = grown.sum()
        current = grown / total if total > 0 else base_weight.copy()

    ticker_weights = pd.DataFrame(weight_rows, index=dates)
    portfolio_return = pd.Series(port_returns, index=dates, name="Equal Weighted Commodity Index")
    class_weights = pd.DataFrame({
        cls: ticker_weights[[t for t in tickers if ticker_class[t] == cls]].sum(axis=1)
        for cls in class_counts
    })
    return portfolio_return, ticker_weights, class_weights


def _rolling_commodity_beta(common_returns, index_return, window_days):
    if common_returns.empty or index_return.empty:
        return pd.DataFrame()
    market_var = index_return.rolling(int(window_days), min_periods=int(window_days)).var()
    beta = {}
    for ticker in common_returns.columns:
        covariance = common_returns[ticker].rolling(int(window_days), min_periods=int(window_days)).cov(index_return)
        beta[ticker] = covariance / market_var
    return pd.DataFrame(beta).replace([np.inf, -np.inf], np.nan)


def _class_weight_option(class_weights):
    if class_weights.empty:
        return None
    dates = [d.strftime("%Y-%m-%d") for d in class_weights.index]

    series = []
    for cls in COMMODITY_CLASS_ORDER:
        if cls not in class_weights.columns:
            continue
        color = CLASS_COLORS.get(cls, PALETTE[0])
        light = _lighten(color, 0.78)
        series.append({
            "name": cls, "type": "line", "stack": "weight", "symbol": "none",
            "lineStyle": {"width": 0.6, "color": color},
            "areaStyle": {"color": {
                "type": "linear", "x": 0, "y": 0, "x2": 0, "y2": 1,
                "colorStops": [{"offset": 0, "color": light}, {"offset": 1, "color": color}],
            }},
            "emphasis": {"focus": "series"},
            "data": [None if pd.isna(v) else round(float(v) * 100.0, 2) for v in class_weights[cls]],
        })

    return {
        "grid": {"left": 50, "right": 20, "top": 10, "bottom": 60},
        "xAxis": {"type": "category", "data": dates, "boundaryGap": False},
        "yAxis": {"type": "value", "name": "Gewicht in %", "min": 0, "max": 100, "axisLine": {"show": False}},
        "legend": {"bottom": 0, "type": "scroll"},
        "tooltip": {"trigger": "axis", "axisPointer": {"type": "cross"}},
        "series": series,
    }


def _class_membership_legend():
    """Shows which individual commodities make up each of the 5 equally
    weighted classes, so the weight-over-time chart below is readable
    without cross-referencing the universe table."""
    rows = []
    for cls in COMMODITY_CLASS_ORDER:
        names = ", ".join(item["name"] for item in COMMODITY_UNIVERSE if item["class"] == cls)
        color = CLASS_COLORS.get(cls, PALETTE[0])
        rows.append(
            dmc.Group(
                [
                    html.Span(style={
                        "display": "inline-block", "width": "9px", "height": "9px",
                        "borderRadius": "50%", "backgroundColor": color, "flexShrink": "0",
                    }),
                    html.Span([
                        html.B(cls, style={"marginRight": "5px"}),
                        html.Span(names, style={"color": "var(--text-muted)"}),
                    ], style={"fontSize": "12px"}),
                ],
                gap=6, wrap="nowrap", align="flex-start", mb=4,
            )
        )
    return html.Div(rows, style={"marginBottom": "14px"})


def _commodity_index_spec(index_series):
    return tv_spec([tv_series("Equal Weighted Commodity Index", index_series, PALETTE[0])], height=420)


def _commodity_beta_spec(beta_frame, selected_class, window_months):
    selected_tickers = [
        item["ticker"] for item in COMMODITY_UNIVERSE
        if item["class"] == selected_class and item["ticker"] in beta_frame.columns
    ]
    series_list = []
    for i, ticker in enumerate(selected_tickers):
        s = pd.to_numeric(beta_frame[ticker], errors="coerce").dropna()
        if s.empty:
            continue
        item = COMMODITY_BY_TICKER[ticker]
        series_list.append(tv_series(f"{item['name']} ({ticker})", s, PALETTE[i % len(PALETTE)], show_last_value=False))
    return tv_spec(series_list, height=460, value_format="ratio",
                    hlines=[{"value": 1, "label": "Beta 1"}, {"value": 0, "label": "Beta 0"}])


def _card(title, children):
    return html.Div(
        [html.Div(title, className="section-title"), *children],
        className="section-card",
    )


def _universe_rows(prices):
    header = dmc.Grid([
        dmc.GridCol(dmc.Text("ROHSTOFF", size="10px", c="dimmed", fw=700), span=3),
        dmc.GridCol(dmc.Text("SYMBOL", size="10px", c="dimmed", fw=700), span=2),
        dmc.GridCol(dmc.Text("VERLAUF (1J)", size="10px", c="dimmed", fw=700), span=3),
        dmc.GridCol(dmc.Text("LETZTER WERT", size="10px", c="dimmed", fw=700, ta="right"), span=2),
        dmc.GridCol(dmc.Text("1J", size="10px", c="dimmed", fw=700, ta="right"), span=2),
    ], mb=4)
    rows = [header]
    for item in COMMODITY_UNIVERSE:
        ticker = item["ticker"]
        if ticker not in prices.columns:
            continue
        s = pd.to_numeric(prices[ticker], errors="coerce").dropna()
        if s.empty:
            continue
        last_year = s.tail(252)
        change = float(last_year.iloc[-1] / last_year.iloc[0] - 1.0) if len(last_year) > 1 else None
        color = UP if (change or 0) >= 0 else DOWN
        rows.append(dmc.Grid([
            dmc.GridCol(dmc.Text(item["name"], size="xs"), span=3),
            dmc.GridCol(dmc.Text(ticker, size="xs", c="dimmed", className="mono"), span=2),
            dmc.GridCol(dcc.Graph(figure=sparkline_figure(last_year, color), config={"staticPlot": True},
                                   style={"height": "32px"}), span=3),
            dmc.GridCol(dmc.Text(f"{s.iloc[-1]:,.2f}", size="xs", ta="right", className="mono"), span=2),
            dmc.GridCol(dmc.Text(f"{change:+.1%}" if change is not None else "–", size="xs", ta="right",
                                  c=("teal" if (change or 0) >= 0 else "red")), span=2),
        ], align="center", className="spark-row"))
    return rows


def layout(params=None):
    params = params or {}
    prices = commodity_prices_usd()
    if prices.empty:
        return html.Div(dmc.Alert("Commodity-Daten konnten nicht geladen werden.", color="red"), className="section-card")

    available_tickers = [item["ticker"] for item in COMMODITY_UNIVERSE if item["ticker"] in prices.columns]
    prices_full = prices.reindex(columns=available_tickers)
    common_returns = _commodity_common_returns(prices_full)
    portfolio_return, _ticker_weights, class_weights = _annual_rebalanced_index(common_returns)
    index_series = _equal_weight_commodity_index(portfolio_return)

    available_classes = [
        category for category in COMMODITY_CLASS_ORDER
        if any(item["class"] == category and item["ticker"] in common_returns.columns for item in COMMODITY_UNIVERSE)
    ]
    default_class = params.get("class") if params.get("class") in available_classes else (available_classes[0] if available_classes else None)

    return html.Div(
        [
            dmc.Title("Commodities", order=3, mb="md"),
            _card("Universum", _universe_rows(prices)),
            _card("Equal Weighted Commodity Index", [
                dmc.Text(
                    "Methodik: jährliche Neugewichtung zu Jahresbeginn, sodass die 5 Oberklassen (Energie, "
                    "Metalle, Getreide & Ölsaaten, Soft Commodities, Vieh) jeweils 20 % Gewicht erhalten. "
                    "Innerhalb einer Klasse wird gleichgewichtet auf die Einzelrohstoffe verteilt. Zwischen "
                    "den Rebalancing-Terminen laufen die Gewichte frei mit der jeweiligen Wertentwicklung.",
                    size="xs", c="dimmed", mb="sm",
                ),
                tv_chart("commodity-index-chart", _commodity_index_spec(index_series)),
            ]),
            _card("Gewicht nach Rohstoffklasse", [
                dmc.Text(
                    "Zeigt, wie sich das Portfoliogewicht der 5 Oberklassen zwischen den jährlichen "
                    "Rebalancing-Terminen (jeweils 20 % Startgewicht) durch die relative Wertentwicklung "
                    "der Einzelrohstoffe verschiebt.",
                    size="xs", c="dimmed", mb="sm",
                ),
                _class_membership_legend(),
                echart("commodity-contribution-chart", _class_weight_option(class_weights) or {}, height=460),
            ]),
            _card("Rollierendes Beta zum Commodity Index", [
                dmc.Grid([
                    dmc.GridCol(dmc.Stack([
                        dmc.Text("Beta-Fenster (Monate)", size="xs", c="dimmed"),
                        dmc.Slider(id="commodity-beta-months", min=3, max=36, step=1, value=12, color="orange",
                                   marks=[{"value": v, "label": str(v)} for v in (3, 12, 24, 36)]),
                    ]), span=6),
                    dmc.GridCol(dmc.Stack([
                        dmc.Text("Oberklasse", size="xs", c="dimmed"),
                        dmc.Select(id="commodity-class-select", data=available_classes,
                                    value=default_class, allowDeselect=False),
                    ]), span=6),
                ], mb="md"),
                tv_chart("commodity-beta-chart", tv_spec([], height=460)),
                html.Div(id="commodity-beta-table"),
                dcc.Store(id="commodity-data-ready", data=True),
            ]),
        ]
    )


def register_callbacks(app):
    @app.callback(
        Output({"type": "tv-chart-data", "index": "commodity-beta-chart"}, "data"),
        Output("commodity-beta-table", "children"),
        Input("commodity-beta-months", "value"),
        Input("commodity-class-select", "value"),
    )
    def update_beta(beta_months, selected_class):
        prices = commodity_prices_usd()
        available_tickers = [item["ticker"] for item in COMMODITY_UNIVERSE if item["ticker"] in prices.columns]
        prices = prices.reindex(columns=available_tickers)
        common_returns = _commodity_common_returns(prices)
        if common_returns.empty or not selected_class:
            return tv_spec([]), None

        portfolio_return, _ticker_weights, _class_weights = _annual_rebalanced_index(common_returns)
        window_days = max(int(round(float(beta_months) * 21)), 1)
        beta_frame = _rolling_commodity_beta(common_returns, portfolio_return, window_days)
        spec = _commodity_beta_spec(beta_frame, selected_class, beta_months)

        current_rows = []
        for item in COMMODITY_UNIVERSE:
            ticker = item["ticker"]
            if item["class"] != selected_class or ticker not in beta_frame.columns:
                continue
            s = pd.to_numeric(beta_frame[ticker], errors="coerce").dropna()
            if s.empty:
                continue
            current_rows.append({"Rohstoff": item["name"], "Symbol": ticker, "Aktuelles Beta": float(s.iloc[-1])})

        table = None
        if current_rows:
            current = pd.DataFrame(current_rows)
            table = ag_table(current, formats={"Aktuelles Beta": "ratio"})
        return spec, table
