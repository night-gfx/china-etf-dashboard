from __future__ import annotations

from urllib.parse import parse_qs

import dash
import dash_ag_grid  # Register table components before the first callback runs.
import dash_mantine_components as dmc
from dash import Dash, Input, Output, State, dcc, html
from dash_iconify import DashIconify

from src.cache import init_cache
from src.theme import ACCENT_OPTIONS, BG, DEFAULT_TAX, FONT_FAMILY, TEXT_MUTED
from pages import asset_allocation, china_dashboard, commodities, equities, equities_overview, overview, sp500_sectors
from pages.simple_asset_page import AssetClassPage

dash._dash_renderer._set_react_version("18.2.0")

bonds_page = AssetClassPage(
    "bonds", "Anleihen", "Staats- und Unternehmensanleihen im Überblick.",
    [
        {"label": "US Aggregate Bond", "sub": "AGG", "ticker": "AGG"},
        {"label": "US Treasury 20+Y", "sub": "TLT", "ticker": "TLT"},
        {"label": "US High Yield Corporate", "sub": "HYG", "ticker": "HYG"},
    ],
)
real_estate_page = AssetClassPage(
    "real-estate", "Immobilien", "Börsennotierte Immobilien (REITs), USA und international.",
    [
        {"label": "US Real Estate", "sub": "VNQ", "ticker": "VNQ"},
        {"label": "Internationale Immobilien", "sub": "RWX", "ticker": "RWX"},
    ],
)
hedge_funds_page = AssetClassPage(
    "hedge-funds", "Hedge Fonds", "Liquide Hedge-Fonds-Strategien als ETF-Proxy (Multi-Strategy).",
    [
        {"label": "Multi-Strategy", "sub": "QAI", "ticker": "QAI"},
        {"label": "Managed Futures", "sub": "DBMF", "ticker": "DBMF"},
    ],
)
crypto_page = AssetClassPage(
    "crypto", "Kryptowährungen", "Die größten Kryptowährungen nach Marktkapitalisierung.",
    [
        {"label": "Bitcoin", "sub": "BTC-USD", "ticker": "BTC-USD"},
        {"label": "Ethereum", "sub": "ETH-USD", "ticker": "ETH-USD"},
    ],
)
money_market_page = AssetClassPage(
    "money-market", "Geldmarkt", "Kurzlaufende Anleihen als Cash-Ersatz / risikoarme Verzinsung.",
    [
        {"label": "1-3M US T-Bills", "sub": "BIL", "ticker": "BIL"},
        {"label": "Ultrashort Bond", "sub": "MINT", "ticker": "MINT"},
    ],
)

NAV_TREE = [
    {"label": "Market Overview", "path": "/", "icon": "tabler:home", "icon_only": True, "divider_after": True},
    {
        "label": "Aktien", "path": "/aktien", "icon": "tabler:chart-line", "group_id": "nav-group-aktien",
        "children": [
            {"label": "Länder", "icon": "tabler:world", "group_id": "nav-group-countries", "children": [
                {"label": "Länderübersicht", "path": "/laender", "icon": "tabler:world"},
                {"label": "China Markets", "path": "/china-markets", "icon": "tabler:chart-candle"},
            ]},
            {"label": "Sektoren", "icon": "tabler:building-bank", "group_id": "nav-group-sectors", "children": [
                {"label": "S&P 500 Sectors", "path": "/sp500-sectors", "icon": "tabler:building-bank"},
            ]},
        ],
    },
    {
        "label": "Anleihen", "icon": "tabler:certificate", "group_id": "nav-group-bonds",
        "children": [{"label": "Übersicht", "path": "/anleihen", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Commodities", "icon": "tabler:flask", "group_id": "nav-group-commodities",
        "children": [{"label": "Übersicht", "path": "/commodities", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Immobilien", "icon": "tabler:building-estate", "group_id": "nav-group-real-estate",
        "children": [{"label": "Übersicht", "path": "/immobilien", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Hedge Fonds", "icon": "tabler:chart-arrows", "group_id": "nav-group-hedge-funds",
        "children": [{"label": "Übersicht", "path": "/hedge-fonds", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Krypto", "icon": "tabler:currency-bitcoin", "group_id": "nav-group-crypto",
        "children": [{"label": "Übersicht", "path": "/krypto", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Geldmarkt", "icon": "tabler:cash", "group_id": "nav-group-money-market",
        "children": [{"label": "Übersicht", "path": "/geldmarkt", "icon": "tabler:chart-line"}],
    },
    {
        "label": "Backtesting", "icon": "tabler:flask-2", "group_id": "nav-group-backtesting",
        "divider_label": "TOOLS",
        "children": [{"label": "Asset Allocation", "path": "/asset-allocation", "icon": "tabler:layout-grid-add"}],
    },
]

PAGES = {
    "/": overview,
    "/aktien": equities_overview,
    "/laender": equities,
    "/china-markets": china_dashboard,
    "/sp500-sectors": sp500_sectors,
    "/anleihen": bonds_page,
    "/commodities": commodities,
    "/immobilien": real_estate_page,
    "/hedge-fonds": hedge_funds_page,
    "/krypto": crypto_page,
    "/geldmarkt": money_market_page,
    "/asset-allocation": asset_allocation,
}

app = Dash(
    __name__,
    external_stylesheets=[
    ],
    external_scripts=[
        "https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js",
        "https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js",
    ],
    suppress_callback_exceptions=True,
    title="Market Dashboard",
)
init_cache(app)


def _nav_link(item, indent=False, top=False, icon_only=False):
    classes = ["nav-link"]
    if top:
        classes.append("topnav-link")
    elif indent:
        classes.append("nav-link-sub")
    inner = [DashIconify(icon=item["icon"], width=15 if not icon_only else 18, color=TEXT_MUTED, className="nav-icon")]
    if icon_only:
        classes.append("topnav-home")
    else:
        inner.append(dmc.Text(item["label"], size="sm", className="nav-label"))
    return dcc.Link(
        dmc.Group(inner, gap=10, wrap="nowrap", className="nav-link-inner"),
        href=item["path"],
        id={"type": "nav-link", "path": item["path"]},
        className=" ".join(classes),
        **({"title": item["label"]} if icon_only else {}),
    )


def _nav_dropdown_section(item):
    """One column of a top-level item's dropdown panel: either a nested
    sub-group rendered as a small heading + its leaf links (e.g. Aktien's
    Länder/Sektoren), or a single leaf link."""
    if "children" in item:
        return html.Div(
            [
                dmc.Text(item["label"], size="9px", c="dimmed", tt="uppercase", fw=700,
                         className="topnav-dropdown-heading"),
                html.Div([_nav_link(c, indent=True) for c in item["children"]],
                         className="topnav-dropdown-column"),
            ],
            className="topnav-dropdown-section",
        )
    return _nav_link(item, indent=True)


def _nav_group(item, separated=False):
    """A top-level entry with children: a button in the top bar that toggles
    a dropdown panel listing its (possibly nested) children. Some entries
    (e.g. "Aktien") are *also* directly linkable, in which case the label
    itself navigates and only the chevron toggles the dropdown."""
    group_id = item["group_id"]
    classes = "topnav-group topnav-group-separated" if separated else "topnav-group"
    icon = DashIconify(icon=item["icon"], width=15, color=TEXT_MUTED, className="nav-icon")
    label = dmc.Text(item["label"], size="sm", className="nav-label")
    chevron = DashIconify(icon="tabler:chevron-down", width=13, className="topnav-chevron")
    toggle_id = {"type": "nav-group-toggle", "group_id": group_id}
    if item.get("path"):
        toggle = html.Div(
            [
                dcc.Link(
                    dmc.Group([icon, label], gap=6, wrap="nowrap"),
                    href=item["path"],
                    id={"type": "nav-link", "path": item["path"]},
                    className="nav-link topnav-link",
                ),
                html.Button(
                    chevron, id=toggle_id, n_clicks=0, type="button",
                    className="topnav-chevron-btn",
                    **{"aria-label": f"{item['label']} Untermenü öffnen"},
                ),
            ],
            className="topnav-group-toggle topnav-group-toggle-split",
        )
    else:
        toggle = html.Button(
            dmc.Group([icon, label, chevron], gap=6, wrap="nowrap"),
            id=toggle_id, n_clicks=0, type="button", className="topnav-group-toggle",
        )
    return html.Div(
        [
            toggle,
            html.Div(
                [_nav_dropdown_section(c) for c in item["children"]],
                className="topnav-dropdown",
            ),
        ],
        id={"type": "nav-group-wrap", "group_id": group_id},
        className=classes,
    )


NAV_GROUP_SEPARATED = {item["group_id"] for item in NAV_TREE if "children" in item and item.get("divider_label")}


def _nav_items():
    items = []
    for item in NAV_TREE:
        separated = bool(item.get("divider_label"))
        if "children" in item:
            items.append(_nav_group(item, separated=separated))
        else:
            items.append(_nav_link(item, top=True, icon_only=item.get("icon_only", False)))
        if item.get("divider_after"):
            items.append(html.Div(className="topnav-divider"))
    return items


def _settings_drawer():
    return dmc.Drawer(
        [
            dmc.Stack(
                [
                    dmc.Text("Darstellung", fw=700, size="sm", tt="uppercase", c="dimmed"),
                    dmc.SegmentedControl(
                        id="settings-theme",
                        data=[{"label": "Hell", "value": "light"}],
                        value="light", fullWidth=True,
                        persistence=True, persistence_type="local",
                    ),
                    dmc.Space(h=4),
                    dmc.Text("Akzentfarbe", size="xs", c="dimmed"),
                    dmc.SegmentedControl(
                        id="settings-accent", fullWidth=True,
                        data=[
                            {
                                "label": html.Span(style={
                                    "display": "inline-block", "width": "14px", "height": "14px",
                                    "borderRadius": "50%", "backgroundColor": opt["hex"],
                                }),
                                "value": opt["key"],
                            }
                            for opt in ACCENT_OPTIONS
                        ],
                        value="blue", persistence=True, persistence_type="local",
                    ),
                    dmc.Divider(my="sm"),
                    dmc.Text("Steuerparameter (Deutschland)", fw=700, size="sm", tt="uppercase", c="dimmed"),
                    dmc.Text(
                        "Wirkt auf alle Nach-Steuer-Berechnungen im China ETF Dashboard.",
                        size="xs", c="dimmed",
                    ),
                    dmc.NumberInput(id="settings-tax-base", label="Kapitalertragsteuer", suffix=" %",
                                    min=0, max=60, step=0.5, value=DEFAULT_TAX["base_rate"],
                                    persistence=True, persistence_type="local"),
                    dmc.NumberInput(id="settings-tax-soli", label="Solidaritätszuschlag (auf Steuer)", suffix=" %",
                                    min=0, max=20, step=0.5, value=DEFAULT_TAX["soli"],
                                    persistence=True, persistence_type="local"),
                    dmc.NumberInput(id="settings-tax-teilfreistellung", label="Teilfreistellung Aktienfonds", suffix=" %",
                                    min=0, max=100, step=1, value=DEFAULT_TAX["teilfreistellung"],
                                    persistence=True, persistence_type="local"),
                    dmc.Text(id="settings-effective-tax", size="xs", c="dimmed"),
                    dmc.Button("Auf Standard zurücksetzen", id="settings-reset", variant="subtle",
                               color="gray", size="xs", mt="sm"),
                ],
                gap="xs",
            ),
        ],
        id="settings-drawer",
        title="Einstellungen",
        position="right",
        size="340px",
        opened=False,
    )


def _cmdk_overlay():
    return html.Div(
        [
            html.Div(className="cmdk-backdrop", id="cmdk-backdrop"),
            html.Div(
                [
                    DashIconify(icon="tabler:search", width=17, className="cmdk-search-icon"),
                    dcc.Input(
                        id="cmdk-input", type="text", autoComplete="off",
                        placeholder="Seiten, Indizes, ETFs, Rohstoffe durchsuchen…",
                        className="cmdk-input",
                    ),
                    html.Kbd("Esc", className="cmdk-esc"),
                ],
                className="cmdk-input-row",
            ),
            html.Div(id="cmdk-results", className="cmdk-results"),
        ],
        id="cmdk-overlay", className="cmdk-overlay",
    )


def build_layout():
    header = dmc.AppShellHeader(
        html.Div(_nav_items(), className="topnav-bar"),
        className="app-header",
    )

    return dmc.AppShell(
        [
            header,
            dmc.AppShellMain(html.Div(id="page-content", className="page-content")),
            html.Div(id="topnav-backdrop", className="topnav-backdrop"),
            dcc.Store(id="nav-open-group", data=None),
        ],
        header={"height": 39},
        padding="lg",
        className="app-shell",
        id="app-shell",
    )


app.layout = dmc.MantineProvider(
    [
        dcc.Location(id="url", refresh=False),
        dcc.Store(id="theme-css-sync"),
        dcc.Store(id="tv-chart-sync"),
        dcc.Store(id="recharts-sync"),
        dcc.Store(id="echart-sync"),
        build_layout(),
        _settings_drawer(),
        _cmdk_overlay(),
    ],
    id="mantine-provider",
    theme={
        "fontFamily": FONT_FAMILY,
        "primaryColor": "orange",
        "colors": {
            "dark": [
                "#e6e8ee", "#c7ccd6", "#9aa1b0", "#767e91", "#565f75",
                "#3a4256", "#242b3a", "#171c28", "#12161f", BG,
            ],
        },
    },
    forceColorScheme="light",
)

for module in (
    overview, equities, china_dashboard, asset_allocation, sp500_sectors, commodities,
    bonds_page, real_estate_page, hedge_funds_page, crypto_page, money_market_page,
):
    module.register_callbacks(app)


def _parse_search(search):
    if not search:
        return {}
    return {k: v[0] for k, v in parse_qs(search.lstrip("?")).items()}


@app.callback(
    Output("nav-open-group", "data"),
    Input({"type": "nav-group-toggle", "group_id": dash.ALL}, "n_clicks"),
    Input("topnav-backdrop", "n_clicks"),
    Input("url", "pathname"),
    State("nav-open-group", "data"),
    prevent_initial_call=True,
)
def toggle_nav_dropdown(_toggle_clicks, _backdrop_clicks, _pathname, open_group):
    trigger = dash.ctx.triggered_id
    if not isinstance(trigger, dict) or trigger.get("type") != "nav-group-toggle":
        # Clicking the backdrop or navigating to a new page always closes
        # whatever dropdown is open.
        return None
    group_id = trigger["group_id"]
    return None if open_group == group_id else group_id


@app.callback(
    Output({"type": "nav-group-wrap", "group_id": dash.ALL}, "className"),
    Output("topnav-backdrop", "className"),
    Input("nav-open-group", "data"),
    Input("url", "pathname"),
)
def render_open_nav_dropdown(open_group, pathname):
    classes = []
    for item in dash.callback_context.outputs_list[0]:
        group_id = item["id"]["group_id"]
        classes_for_group = ["topnav-group"]
        if group_id in NAV_GROUP_SEPARATED:
            classes_for_group.append("topnav-group-separated")
        if pathname in NAV_GROUP_CHILD_PATHS.get(group_id, []):
            classes_for_group.append("topnav-group-active")
        if group_id == open_group:
            classes_for_group.append("open")
        classes.append(" ".join(classes_for_group))
    backdrop_class = "topnav-backdrop open" if open_group else "topnav-backdrop"
    return classes, backdrop_class


@app.callback(Output("page-content", "children"), Input("url", "pathname"), Input("url", "search"))
def render_page(pathname, search):
    module = PAGES.get(pathname, overview)
    return module.layout(_parse_search(search))


def _group_paths(items):
    groups = {}
    for item in items:
        if "children" in item:
            nested = _group_paths(item["children"])
            groups.update(nested)
            groups[item["group_id"]] = [c["path"] for c in item["children"] if "path" in c]
            for paths in nested.values():
                groups[item["group_id"]].extend(paths)
    return groups


NAV_GROUP_CHILD_PATHS = _group_paths(NAV_TREE)
TOP_LEVEL_LINK_PATHS = {item["path"] for item in NAV_TREE if item.get("path")}


@app.callback(
    Output({"type": "nav-link", "path": dash.ALL}, "className"),
    Input("url", "pathname"),
)
def highlight_active_nav(pathname):
    result = []
    for item in dash.callback_context.outputs_list:
        path = item["id"]["path"]
        active = path == pathname or (path == "/" and pathname is None)
        indented = any(path in paths for paths in NAV_GROUP_CHILD_PATHS.values())
        classes = "nav-link"
        if path in TOP_LEVEL_LINK_PATHS:
            classes += " topnav-link"
        elif indented:
            classes += " nav-link-sub"
        if active:
            classes += " nav-link-active"
        result.append(classes)
    return result


# ---------------------------------------------------------------------------
# TradingView Lightweight Charts: one generic clientside callback renders
# every chart on the page whenever its data Store changes (pattern-matched,
# so individual pages never need to wire their own clientside callback).
# ---------------------------------------------------------------------------

app.clientside_callback(
    """
    function(dataList, idsList) {
        var triggered = dash_clientside.callback_context.triggered || [];
        var renderAll = triggered.length === 0 || triggered.every(function (t) { return t.prop_id === "."; });
        var triggeredIndexes = new Set(triggered.map(function (t) {
            try { return JSON.parse(t.prop_id.slice(0, t.prop_id.lastIndexOf("."))).index; }
            catch (e) { return null; }
        }));
        (dataList || []).forEach(function (data, i) {
            var id = idsList[i];
            if (data && window.renderTVChart && id && (renderAll || triggeredIndexes.has(id.index))) {
                window.renderTVChart(id.index, data);
            }
        });
        return "";
    }
    """,
    Output("tv-chart-sync", "data"),
    Input({"type": "tv-chart-data", "index": dash.ALL}, "data"),
    State({"type": "tv-chart-data", "index": dash.ALL}, "id"),
)

app.clientside_callback(
    """
    function(dataList, idsList) {
        var triggered = dash_clientside.callback_context.triggered || [];
        var renderAll = triggered.length === 0 || triggered.every(function (t) { return t.prop_id === "."; });
        var triggeredIndexes = new Set(triggered.map(function (t) {
            try { return JSON.parse(t.prop_id.slice(0, t.prop_id.lastIndexOf("."))).index; }
            catch (e) { return null; }
        }));
        (dataList || []).forEach(function (data, i) {
            var id = idsList[i];
            if (data && window.renderRecharts && id && (renderAll || triggeredIndexes.has(id.index))) {
                window.renderRecharts(id.index, data);
            }
        });
        return "";
    }
    """,
    Output("recharts-sync", "data"),
    Input({"type": "recharts-data", "index": dash.ALL}, "data"),
    State({"type": "recharts-data", "index": dash.ALL}, "id"),
)

app.clientside_callback(
    """
    function(dataList, idsList) {
        var triggered = dash_clientside.callback_context.triggered || [];
        var renderAll = triggered.length === 0 || triggered.every(function (t) { return t.prop_id === "."; });
        var triggeredIndexes = new Set(triggered.map(function (t) {
            try { return JSON.parse(t.prop_id.slice(0, t.prop_id.lastIndexOf("."))).index; }
            catch (e) { return null; }
        }));
        (dataList || []).forEach(function (data, i) {
            var id = idsList[i];
            if (data && window.renderEChart && id && (renderAll || triggeredIndexes.has(id.index))) {
                window.renderEChart(id.index, data);
            }
        });
        return "";
    }
    """,
    Output("echart-sync", "data"),
    Input({"type": "echart-data", "index": dash.ALL}, "data"),
    State({"type": "echart-data", "index": dash.ALL}, "id"),
)

# ---------------------------------------------------------------------------
# Settings drawer: open/close, theme + accent + tax
# ---------------------------------------------------------------------------

@app.callback(
    Output("settings-drawer", "opened"),
    Input("settings-open-btn", "n_clicks"),
    State("settings-drawer", "opened"),
    prevent_initial_call=True,
)
def toggle_settings(_n, opened):
    return not opened


@app.callback(
    Output("mantine-provider", "forceColorScheme"),
    Input("settings-theme", "value"),
)
def apply_theme(theme):
    return "light"


@app.callback(
    Output("mantine-provider", "theme"),
    Input("settings-accent", "value"),
    State("mantine-provider", "theme"),
)
def apply_accent(accent, theme):
    theme = dict(theme or {})
    theme["primaryColor"] = "blue"
    return theme


app.clientside_callback(
    """
    function(theme, accent) {
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.style.setProperty('--accent', '#5b9bd5');
        return "";
    }
    """,
    Output("theme-css-sync", "data"),
    Input("settings-theme", "value"),
    Input("settings-accent", "value"),
)


@app.callback(
    Output("settings-effective-tax", "children"),
    Input("settings-tax-base", "value"),
    Input("settings-tax-soli", "value"),
    Input("settings-tax-teilfreistellung", "value"),
)
def show_effective_tax(base, soli, teilfreistellung):
    try:
        rate = (base / 100.0) * (1 + soli / 100.0) * (1 - teilfreistellung / 100.0)
        return f"Effektiver Steuersatz auf positive Gewinne: {rate:.2%}"
    except Exception:
        return ""


@app.callback(
    Output("settings-theme", "value"),
    Output("settings-accent", "value"),
    Output("settings-tax-base", "value"),
    Output("settings-tax-soli", "value"),
    Output("settings-tax-teilfreistellung", "value"),
    Input("settings-reset", "n_clicks"),
    prevent_initial_call=True,
)
def reset_settings(_n):
    return "light", "blue", DEFAULT_TAX["base_rate"], DEFAULT_TAX["soli"], DEFAULT_TAX["teilfreistellung"]


# Command palette open/close and filtering runs entirely client-side (see
# assets/cmdk.js) so the keyboard shortcut and the sidebar button never fight
# over server round-trips.




if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8050, threaded=True)
