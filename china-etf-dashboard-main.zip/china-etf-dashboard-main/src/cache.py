from __future__ import annotations

from flask_caching import Cache

cache = Cache()

INTRADAY_TTL = 5 * 60
SHORT_TTL = 60 * 60
LONG_TTL = 6 * 60 * 60
DAY_TTL = 12 * 60 * 60


def init_cache(app):
    cache.init_app(
        app.server,
        config={"CACHE_TYPE": "SimpleCache", "CACHE_DEFAULT_TIMEOUT": LONG_TTL},
    )
